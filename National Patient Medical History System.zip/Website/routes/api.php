<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::post('/userLogin', [App\Http\Controllers\Application\AuthApp::class, 'Login']);
Route::get('/cities', [App\Http\Controllers\Application\Details::class, 'Cities']);
Route::post('/userSignUp', [App\Http\Controllers\Application\AuthApp::class, 'Register']);

Route::post('/authenticate', [App\Http\Controllers\Application\AuthApp::class, 'Authenticate']);
Route::post('/IDCard', [App\Http\Controllers\Application\AuthApp::class, 'updateIdentityCard']);

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::group(['middleware' => ['auth:sanctum']], function () {


    // -------------------GET Routs --------------------------//
    Route::get('/doctors', [App\Http\Controllers\Application\Details::class, 'Doctors']);
    Route::get('/hospitals', [App\Http\Controllers\Application\Details::class, 'Hospitals']);
    // Route::get('/specialty',[App\Http\Controllers\Application\Details::class,'Specialty']);
    Route::get('/clincs', [App\Http\Controllers\Application\Details::class, 'Buildings']);

    // -------------------POST Routs --------------------------//
    Route::post('/tests', [App\Http\Controllers\Application\Details::class, 'Tests']);
    Route::post('/medicens', [App\Http\Controllers\Application\Details::class, 'Medicens']);
    Route::post('/diagnosies', [App\Http\Controllers\Application\Details::class, 'Diagnosies']);
    Route::post('/surgeries', [App\Http\Controllers\Application\Details::class, 'Surgery']);
    Route::post('/chronicDisease', [App\Http\Controllers\Application\Details::class, 'ChronicDisease']);
    Route::post('/rays', [App\Http\Controllers\Application\Details::class, 'Rays']);
    Route::post('/profile', [App\Http\Controllers\Application\AuthApp::class, 'Profile']);
    Route::post('/changePassword', [App\Http\Controllers\Application\AuthApp::class, 'ChangePassword']);
    Route::post('/changePhoneNumber', [App\Http\Controllers\Application\AuthApp::class, 'ChangePhoneNumber']);
    Route::post('/childrens', [App\Http\Controllers\Application\AuthApp::class, 'GetBreadwinner']);
    Route::post('/childrens', [App\Http\Controllers\Application\AuthApp::class, 'GetBreadwinner']);
    Route::post('/book', [App\Http\Controllers\Application\Details::class, 'Appointment']);
    Route::post('/myBookings', [App\Http\Controllers\Application\Details::class, 'Appointments']);
    Route::post('/profile/update/image', [App\Http\Controllers\Application\AuthApp::class, 'UploadImage']);
});
