<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware(['auth','ray'])->group(function () {

    //--------------- Get routes ---------------------------//
    Route::get('/',[App\Http\Controllers\Ray\IndexController::class,'Index'])->name('ray.index');
    Route::get('/add',[App\Http\Controllers\Ray\IndexController::class,'Add'])->name('ray.add');
    Route::get('/profile',[App\Http\Controllers\Ray\IndexController::class,'Profile'])->name('ray.profile');
    Route::get('/rays/{number}',[App\Http\Controllers\Ray\IndexController::class,'Rays'])->name('ray.rays');
    Route::get('/person/rays/{patient}',[App\Http\Controllers\Ray\IndexController::class,'Show'])->name('ray.person.rays');


    //--------------- POST routes ---------------------------//
    Route::post('/search',[App\Http\Controllers\Ray\IndexController::class,'Search'])->name('ray.search');
    Route::post('/store',[App\Http\Controllers\Ray\IndexController::class,'Store'])->name('ray.store');
    Route::post('/user/profile/pass',[App\Http\Controllers\Ray\IndexController::class,'UpdatePassword'])->name('ray.profile.password');


});
