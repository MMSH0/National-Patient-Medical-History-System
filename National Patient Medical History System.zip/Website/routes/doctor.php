<?php

use App\Http\Controllers\Admin\ChronicDiseaseController;
use App\Http\Controllers\Admin\SurgeryController;
use App\Http\Controllers\Doctor\IndexController;
use App\Http\Controllers\Doctor\PatientController;
use App\Http\Controllers\Doctor\ChildrenController;
use App\Http\Controllers\Doctor\PatientChronicDiseaseController;
use App\Http\Controllers\Doctor\PatientDiagnosisController;
use App\Http\Controllers\Doctor\PatientRaysController;
use App\Http\Controllers\Doctor\PatientSurgeryController;
use App\Http\Controllers\Doctor\PatientTestsController;
use App\Http\Controllers\Doctor\PrescriptionController;
use App\Http\Controllers\Doctor\ProfileController;
use App\Http\Controllers\Doctor\ReservationsController;
use App\Http\Controllers\Labray\RayController;
use App\Models\Doctor\Appointement;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware(['auth', 'doctor'])->group(function () {

    //--------------- Get routes ---------------------------//
    Route::get("/", [IndexController::class, 'Index'])->name('doctor.index');
    Route::get('/appointment', [ReservationsController::class, 'Index'])->name("doctor.appointment");
    Route::get('/patient/add', [PatientController::class, 'Add'])->name('doctor.patient.add');
    Route::get('/patient/info/{number}', [PatientController::class, 'Show'])->name("doctor.patient.info");
    Route::get('/drug/add', [PrescriptionController::class, 'Add'])->name("doctor.patient.medicen.add");
    Route::get('/test/{id}', [PatientTestsController::class, 'Index'])->name("doctor.patient.test.index");
    Route::get('/test/add/{id}', [PatientTestsController::class, 'Add'])->name("doctor.patient.test.add");
    Route::get('/children/add/{pid}', [ChildrenController::class, 'Add'])->name('doctor.patient.children.add');
    Route::get('/children/info/{pid}', [ChildrenController::class, 'Info'])->name('doctor.patient.children.info');
    Route::get('/ray/{id}', [PatientRaysController::class, 'Index'])->name('doctor.patient.ray');
    Route::get('/disease/{id}', [PatientChronicDiseaseController::class, 'Index'])->name('doctor.patient.disease.index');
    Route::get('/ray/show', [PatientRaysController::class, 'Rays'])->name("doctor.patient.ray.show");
    Route::get('/patient/verfication/{id}', [PatientController::class, 'Verfication'])->name("doctor.patient.verfication");
    Route::get('/diagnose/view/{id}', [PatientDiagnosisController::class, 'Show'])->name("doctor.patient.diagnose");
    Route::get('/medicens/{id}', [PrescriptionController::class, 'Index'])->name("doctor.patient.medicen");
    Route::get('/profile', [IndexController::class, 'Profile'])->name("doctor.profile");
    Route::get('/surgeries/{id}', [PatientSurgeryController::class, 'Index'])->name("doctor.patient.surgery.index");
    // Route::get('/surgeries/Show/{id}', [PatientSurgeryController::class, 'Show'])->name("doctor.patient.surgery.show");
    // main


    // Route::get('/child/add', [PatientController::class, 'AddChild'])->name('doctor.patient.children');




    //--------------- post routes  ---------------------------//
    Route::POST('/patient/store', [PatientController::class, 'Store'])->name("doctor.patient.store");
    Route::POST('/medicen/store', [PrescriptionController::class, 'Store'])->name("doctor.patient.medicen.store");
    Route::POST('/diagnose/store', [PatientDiagnosisController::class, 'Store'])->name("doctor.patient.diagnose.store");
    Route::POST('/child/store', [ChildrenController::class, 'Store'])->name("doctor.patient.children.store");
    Route::POST('/test/store', [PatientTestsController::class, 'Store'])->name("doctor.patient.test.store");
    Route::POST('/Rays/store', [PatientRaysController::class, 'Store'])->name("doctor.patient.ray.store");
    Route::POST('/disease/store', [PatientChronicDiseaseController::class, 'Store'])->name('doctor.patient.disease.store');
    Route::POST('/patient/searchs', [PatientController::class, 'Searches'])->name("doctor.patients.search");
    Route::POST('/patient/verify', [PatientController::class, 'Verify'])->name("doctor.patient.verify");
    Route::POST('/profile/image', [ProfileController::class, 'UploadImage'])->name("doctor.profile.image");
    Route::POST('/profile/password', [ProfileController::class, 'UpdatePassword'])->name("doctor.profile.password");
    Route::POST('/profile/user', [ProfileController::class, 'Update'])->name("doctor.profile.update");
    Route::POST('/profile/time', [ProfileController::class, 'UpdateTime'])->name("doctor.profile.time.update");
    Route::POST('/surgeries/add', [PatientSurgeryController::class, 'store'])->name("doctor.patient.surgery.store");
    Route::POST('/appointment/update', [ReservationsController::class, 'update'])->name("doctor.appointment.updateStatus");

    // ========== Reports ===========//

    Route::GET('/report/test/{id}', [PatientTestsController::class, 'Report'])->name("doctor.patient.report.test");
    Route::GET('/report/diagnoes/{id}', [PatientDiagnosisController::class, 'Report'])->name("doctor.patient.report.diagnoes");
    Route::GET('/report/medicen/{id}', [PrescriptionController::class, 'Report'])->name("doctor.patient.report.medicen");
    Route::GET('/report/surgery/{id}', [PatientSurgeryController::class, 'Report'])->name("doctor.patient.report.surgery");
    Route::GET('/report/rays/{id}', [PatientRaysController::class, 'Report'])->name("doctor.patient.report.rays");
    Route::GET('/report/chronicDieases/{id}', [PatientChronicDiseaseController::class, 'Report'])->name("doctor.patient.report.chronicDieases");
    Route::GET('/report/full/{id}', [PatientController::class, 'Report'])->name("doctor.patient.report.full");


    //--------------- Get routes search ---------------------------//


    Route::get('/patient_list', [PatientController::class, 'Index'])->name("doctor.patinet.index");
    Route::get('/patient/search', [PatientController::class, 'Search'])->name("doctor.patient.search");
    Route::get('/children/{pid}', [ChildrenController::class, 'Index'])->name("doctor.patient.children.index");
    Route::get('/appointment/detailes', [ReservationsController::class, 'Show'])->name("doctor.patient.appointment");
    Route::get('/test/show', [PatientTestsController::class, 'Show'])->name("doctor.patient.tests.show");
    Route::get('/Rays/show', [PatientRaysController::class, 'Show'])->name("doctor.patient.rays.show");
    Route::get('/test/search/tests', [PatientTestsController::class, 'Tests'])->name('doctor.lab.tests');
    Route::get('/test/search/rays', [PatientTestsController::class, 'Rays'])->name('doctor.raycenter.rays');






    //--------------- put routes  ---------------------------//
    Route::put('/drug/update', [PrescriptionController::class, 'Update'])->name('doctor.patient.medicen.update');
    Route::put('/diagnose/update', [PatientDiagnosisController::class, 'Update'])->name('doctor.patient.diagnose.update');
    Route::put('/test/update', [PatientTestsController::class, 'Update'])->name('doctor.patient.test.update');
    Route::put('/Ray/update', [PatientRaysController::class, 'Update'])->name('doctor.patient.ray.update');
    Route::put('/surgery/update', [PatientSurgeryController::class, 'Update'])->name('doctor.patient.surgery.update');
    Route::put('/status/update', [PatientController::class, 'UpdateStatus'])->name('doctor.patient.status.update');
    Route::put('/phone/update', [ChildrenController::class, 'UpdatePhone'])->name('doctor.patient.phone.update');
    Route::put('/heightandweight/update', [PatientController::class, 'UpdateHeightAndWeight'])->name("doctor.patient.heightandweight.update");
    Route::put('/bloodtype/update', [PatientController::class, 'UpdateBloodType'])->name("doctor.patient.bloodtype.update");

});
