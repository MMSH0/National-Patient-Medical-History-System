<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware(['auth','lab'])->group(function () {

    //--------------- Get routes ---------------------------//
    Route::get('/',[App\Http\Controllers\Lab\IndexController::class,'Index'])->name('lab.index');
    Route::get('/add',[App\Http\Controllers\Lab\IndexController::class,'Add'])->name('lab.add');
    Route::get('/profile',[App\Http\Controllers\Lab\IndexController::class,'Profile'])->name('lab.profile');
    Route::get('/tests/{number}',[App\Http\Controllers\Lab\IndexController::class,'Tests'])->name('lab.tests');
    Route::get('/person/tests/{patient}',[App\Http\Controllers\Lab\IndexController::class,'Show'])->name('lab.person.tests');


    //--------------- POST routes ---------------------------//
    Route::post('/search',[App\Http\Controllers\Lab\IndexController::class,'Search'])->name('lab.search');
    Route::post('/store',[App\Http\Controllers\Lab\IndexController::class,'Store'])->name('lab.store');
    Route::post('/user/profile/pass',[App\Http\Controllers\Lab\IndexController::class,'UpdatePassword'])->name('lab.profile.password');



});
