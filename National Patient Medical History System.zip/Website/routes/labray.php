<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware(['auth','labray'])->group(function () {

    //--------------- Get routes ---------------------------//
    Route::get('/',[App\Http\Controllers\labray\IndexController::class,'Index'])->name('labray.index');
    Route::get('/test/add',[App\Http\Controllers\labray\IndexController::class,'Add'])->name('labray.test.add');
    Route::get('/profile',[App\Http\Controllers\labray\IndexController::class,'Profile'])->name('labray.profile');
    Route::get('/tests/{number}',[App\Http\Controllers\labray\IndexController::class,'Tests'])->name('labray.tests');
    Route::get('/person/tests/{patient}',[App\Http\Controllers\labray\IndexController::class,'Show'])->name('labray.person.tests');

    Route::get('/rays',[App\Http\Controllers\Labray\RayController::class,'Index'])->name('labray.ray.index');
    Route::get('/ray/add',[App\Http\Controllers\Labray\RAyController::class,'Add'])->name('labray.ray.add');
    Route::get('/rays/{number}',[App\Http\Controllers\Labray\RayController::class,'Rays'])->name('labray.rays');
    Route::get('/person/rays/{patient}',[App\Http\Controllers\Labray\RayController::class,'Show'])->name('labray.person.rays');


    //--------------- POST routes ---------------------------//
    Route::post('/test/search',[App\Http\Controllers\labray\IndexController::class,'Search'])->name('labray.test.search');
    Route::post('/test/store',[App\Http\Controllers\labray\IndexController::class,'Store'])->name('labray.test.store');

    Route::post('/ray/search',[App\Http\Controllers\labray\RayController::class,'Search'])->name('labray.ray.search');
    Route::post('/ray/store',[App\Http\Controllers\labray\RayController::class,'Store'])->name('labray.ray.store');

    Route::post('/user/profile/pass',[App\Http\Controllers\labray\IndexController::class,'UpdatePassword'])->name('labray.profile.password');

});
