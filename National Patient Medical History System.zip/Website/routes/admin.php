<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware(['auth','admin'])->group(function () {

    //--------------- Get routes ---------------------------//
    Route::get('/',[App\Http\Controllers\Admin\IndexController::class,'Index'])->name('admin.index');
    Route::get('/specialty',[App\Http\Controllers\Admin\SpecialtyController::class,'Index'])->name('admin.specialty.index');
    Route::get('/hospital',[App\Http\Controllers\Admin\HospitalController::class,'Index'])->name('admin.hospital.index');
    Route::get('/clinc',[App\Http\Controllers\Admin\ClincController::class,'Index'])->name('admin.clinc.index');
    Route::get('/lab',[App\Http\Controllers\Admin\LabController::class,'Index'])->name('admin.lab.index');
    Route::get('/raycenter',[App\Http\Controllers\Admin\RayCenterController::class,'Index'])->name('admin.raycenter.index');
    Route::get('/doctor/add',[App\Http\Controllers\Admin\DoctorController::class,'Add'])->name('admin.doctor.create');
    Route::get('/doctor',[App\Http\Controllers\Admin\DoctorController::class,'Index'])->name('admin.doctor.index');
    Route::get('/patient',[App\Http\Controllers\Admin\PatientController::class,'Index'])->name('admin.patient.index');
    Route::get('/patient/accounts',[App\Http\Controllers\Admin\PatientController::class,'Auth'])->name('admin.patient.auth');
    Route::get('/medicen',[App\Http\Controllers\Admin\MedicenController::class,'Index'])->name('admin.medicen.index');
    Route::get('/test/add',[App\Http\Controllers\Admin\TestController::class,'Add'])->name('admin.test.create');
    Route::get('/test',[App\Http\Controllers\Admin\TestController::class,'Index'])->name('admin.test.index');
    Route::get('/type',[App\Http\Controllers\Admin\TestController::class,'TypeIndex'])->name('admin.test.type.index');
    Route::get('/radiology/add',[App\Http\Controllers\Admin\RadiologyController::class,'Add'])->name('admin.radiology.create');
    Route::get('/radiology',[App\Http\Controllers\Admin\RadiologyController::class,'Index'])->name('admin.radiology.index');
    Route::get('/chronicdisease',[App\Http\Controllers\Admin\ChronicDiseaseController::class,'Index'])->name('admin.chronicdisease.index');
    Route::get('/diagnosis',[App\Http\Controllers\Admin\DiagnoseController::class,'Index'])->name('admin.diagnosis.index');
    Route::get('/surgery',[App\Http\Controllers\Admin\SurgeryController::class,'Index'])->name('admin.surgery.index');
    Route::get('/profile',[App\Http\Controllers\Admin\IndexController::class,'Profile'])->name('admin.profile');
    Route::get('/user/add',[App\Http\Controllers\Admin\UserController::class,'Index'])->name('admin.user.index');
    Route::get('/users',[App\Http\Controllers\Admin\UserController::class,'All'])->name('admin.users.index');
    Route::get('/backup/all',[App\Http\Controllers\Admin\BackupController::class,'showRestoreForm'])->name('admin.backup.index');

    Route::get('/logs', [App\Http\Controllers\Manage\LogController::class,'readLogFile'])->name('admin.log.index');


    // ------------ Search routes ------------------------//
    Route::get('/specialtySearch',[App\Http\Controllers\Admin\SpecialtyController::class,'Search'])->name('admin.specialty.search');
    Route::get('/hospitalSearch',[App\Http\Controllers\Admin\HospitalController::class,'Search'])->name('admin.hospital.search');
    Route::get('/labSearch',[App\Http\Controllers\Admin\LabController::class,'Search'])->name('admin.lab.search');
    Route::get('/clincSearch',[App\Http\Controllers\Admin\ClincController::class,'Search'])->name('admin.clinc.search');
    Route::get('/raycenterSearch',[App\Http\Controllers\Admin\RayCenterController::class,'Search'])->name('admin.raycenter.search');
    Route::get('/medicenSearch',[App\Http\Controllers\Admin\MedicenController::class,'Search'])->name('admin.medicen.search');
    Route::get('/testSearch',[App\Http\Controllers\Admin\TestController::class,'TestSearch'])->name('admin.test.search');
    Route::get('/typetestSearch',[App\Http\Controllers\Admin\TestController::class,'TypeTestSearch'])->name('admin.typetest.search');
    Route::get('/raySearch',[App\Http\Controllers\Admin\RadiologyController::class,'Search'])->name('admin.ray.search');
    Route::get('/chronicdiseaseSearch',[App\Http\Controllers\Admin\ChronicDiseaseController::class,'Search'])->name('admin.chronicdisease.search');
    Route::get('/diagnosisSearch',[App\Http\Controllers\Admin\DiagnoseController::class,'Search'])->name('admin.diagnosis.search');
    Route::get('/surgerySearch',[App\Http\Controllers\Admin\SurgeryController::class,'Search'])->name('admin.surgery.search');

    //--------------- Post routes ---------------------------//
    Route::post('/specialty',[App\Http\Controllers\Admin\SpecialtyController::class,'Store'])->name('admin.specialty.store');
    Route::post('/doctor',[App\Http\Controllers\Admin\DoctorController::class,'Store'])->name('admin.doctor.store');
    Route::post('/hospital',[App\Http\Controllers\Admin\HospitalController::class,'Store'])->name('admin.hospital.store');
    Route::post('/medicen',[App\Http\Controllers\Admin\MedicenController::class,'Store'])->name('admin.medicen.store');
    Route::post('/typetest',[App\Http\Controllers\Admin\TestController::class,'TypeStore'])->name('admin.typetest.store');
    Route::post('/test',[App\Http\Controllers\Admin\TestController::class,'TestStore'])->name('admin.test.store');
    Route::post('/chronicdisease',[App\Http\Controllers\Admin\ChronicDiseaseController::class,'Store'])->name('admin.chronicdisease.store');
    Route::post('/diagnosis',[App\Http\Controllers\Admin\DiagnoseController::class,'Store'])->name('admin.diagnosis.store');
    Route::post('/surgery',[App\Http\Controllers\Admin\SurgeryController::class,'Store'])->name('admin.surgery.store');
    Route::post('/clinc',[App\Http\Controllers\Admin\ClincController::class,'Store'])->name('admin.clinc.store');
    Route::post('/lab',[App\Http\Controllers\Admin\LabController::class,'Store'])->name('admin.lab.store');
    Route::post('/raycenter',[App\Http\Controllers\Admin\RayCenterController::class,'Store'])->name('admin.raycenter.store');
    Route::post('/radiology',[App\Http\Controllers\Admin\RadiologyController::class,'Store'])->name('admin.radiology.store');
    Route::post('/user',[App\Http\Controllers\Admin\UserController::class,'Store'])->name('admin.user.store');
    Route::post('/user/profile',[App\Http\Controllers\Admin\UserController::class,'Update'])->name('admin.profile.update');
    Route::post('/patient/verify',[App\Http\Controllers\Admin\PatientController::class,'Verify'])->name('admin.patient.verify');
    Route::post('/patient/decline',[App\Http\Controllers\Admin\PatientController::class,'Decline'])->name('admin.patient.decline');
    Route::post('/user/profile/pass',[App\Http\Controllers\Admin\UserController::class,'UpdatePassword'])->name('admin.profile.password');
    Route::post('/user/profile/image',[App\Http\Controllers\Admin\UserController::class,'UpdateImage'])->name('admin.profile.image');
    Route::post('/user/backup/restore',[App\Http\Controllers\Admin\BackupController::class,'restore'])->name('admin.backup.restore');
    Route::post('/admin/backup/backup', [App\Http\Controllers\Admin\BackupController::class, 'backup'])->name('admin.backup.backup');
    Route::post('/patient/editData',[App\Http\Controllers\Admin\PatientController::class,'EditData'])->name('admin.patient.editData');


    // -------------------     POST CSV   ---------------------------//
    Route::post('/specialty/store/csv',[App\Http\Controllers\Admin\SpecialtyController::class,'ImportCsv'])->name('admin.specialty.csv.store');
    Route::post('/chronicdisease/store/csv',[App\Http\Controllers\Admin\ChronicDiseaseController::class,'ImportCsv'])->name('admin.chronicdisease.csv.store');
    Route::post('/surgery/store/csv',[App\Http\Controllers\Admin\SurgeryController::class,'ImportCsv'])->name('admin.surgery.csv.store');
    Route::post('/diagnosis/store/csv',[App\Http\Controllers\Admin\DiagnoseController::class,'ImportCsv'])->name('admin.diagnosis.csv.store');
    Route::post('/medicen/store/csv',[App\Http\Controllers\Admin\MedicenController::class,'ImportCsv'])->name('admin.medicen.csv.store');


    //--------------- Put routes ---------------------------//
    Route::put('/hospital', [App\Http\Controllers\Admin\HospitalController::class, 'Update'])->name('admin.hospital.update');
    Route::put('/specialty', [App\Http\Controllers\Admin\SpecialtyController::class, 'Update'])->name('admin.specialty.update');
    Route::put('/clinc', [App\Http\Controllers\Admin\ClincController::class, 'Update'])->name('admin.clinc.update');
    Route::put('/raycenter', [App\Http\Controllers\Admin\RayCenterController::class, 'Update'])->name('admin.raycenter.update');
    Route::put('/lab', [App\Http\Controllers\Admin\LabController::class, 'Update'])->name('admin.lab.update');
    Route::put('/medicen', [App\Http\Controllers\Admin\MedicenController::class, 'Update'])->name('admin.medicen.update');
    Route::put('/chronicdisease', [App\Http\Controllers\Admin\ChronicDiseaseController::class, 'Update'])->name('admin.chronicdisease.update');
    Route::put('/diagnosis', [App\Http\Controllers\Admin\DiagnoseController::class, 'Update'])->name('admin.diagnosis.update');
    Route::put('/Surgery', [App\Http\Controllers\Admin\SurgeryController::class, 'Update'])->name('admin.surgery.update');
    Route::put('/raydiology', [App\Http\Controllers\Admin\RadiologyController::class, 'Update'])->name('admin.raydiology.update');
    Route::put('/test', [App\Http\Controllers\Admin\TestController::class, 'TestUpdate'])->name('admin.test.update');
    Route::put('/doctor', [App\Http\Controllers\Admin\DoctorController::class, 'Block'])->name('admin.doctor.block');
    Route::put('/lab/block', [App\Http\Controllers\Admin\LabController::class, 'Block'])->name('admin.lab.block');
    Route::put('/raycenter/block', [App\Http\Controllers\Admin\RayCenterController::class, 'Block'])->name('admin.raycenter.block');
    Route::put('/users/block', [App\Http\Controllers\Admin\UserController::class, 'Block'])->name('admin.users.block');
    Route::put('/type/update',[App\Http\Controllers\Admin\TestController::class,'TypeUpdate'])->name('admin.test.type.update');

});
