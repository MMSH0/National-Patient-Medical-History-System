<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\Rule;
use Illuminate\Support\Facades\DB;

class checkPhoneNumber implements Rule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */

protected $users;
protected $phone_number;

public function __construct($users,$phone_number)
{
    $this->users = $users;
    $this->phone_number = $phone_number;
}
public function passes ($attribute,$value)
{
    return !DB::table($this->users)->where($this->phone_number,$value)->exists();
}

public function message()
{
    return 'رقم الهاتف موجود مسبقاً';
}


}
