<?php

namespace App\Models\Ray;

use App\Models\Admin\Building;
use App\Models\Doctor\Patient;
use App\Models\Admin\Radiology;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PatientRay extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [
        'ray_id', 'result','report', 'raycenter_id', 'date','time','atient_id'
    ];
    public function building(){
        return $this->belongsTo(Building::class);
    }
    public function ray(){
        return $this->belongsTo(Radiology::class);
    }

    public function patient(){
        return $this->belongsTo(Patient::class);

    }
}
