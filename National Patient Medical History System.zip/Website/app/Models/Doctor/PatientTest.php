<?php

namespace App\Models\Doctor;

use App\Models\Admin\Building;
use App\Models\Admin\Doctor;
use App\Models\Admin\Test;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PatientTest extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [
        'doctor_id',
        'lab_id',
        'patient_id',
        'test_id',
        'result',
        'test_date',
    ] ;


    public function patient(){
        return $this->belongsTo(Patient::class);
    }
    public function doctor(){
        return $this->belongsTo(Doctor::class);
    }

    public function lab(){
        return $this->belongsTo(Building::class,'lab_id');
    }

    public function test(){
        return $this->belongsTo(Test::class);
    }

}
