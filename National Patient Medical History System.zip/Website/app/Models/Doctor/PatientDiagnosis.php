<?php

namespace App\Models\Doctor;

use App\Models\Admin\Doctor;
use App\Models\Doctor\Patient;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PatientDiagnosis extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [
        'doctor_id',
        'patient_id',
        'diagnosis_id',
        'diagnosis_date',
        'notes',
    ] ;
    public function doctor(){
        return $this->belongsTo(Doctor::class);
    }
    public function patient(){
        return $this->belongsTo(Patient::class);
    }
    public function diagnosis(){
        return $this->belongsTo(Diagnose::class);
    }


}
