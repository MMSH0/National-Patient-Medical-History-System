<?php

namespace App\Models\Doctor;

use App\Models\Admin\Building;
use App\Models\Admin\Doctor;
use App\Models\Admin\Hospital;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Workinghour extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [ 'working_day', 'start_time', 'end_time', 'clinic_id', 'doctor_id', 'hospital_id'];

    public function doctor(){
        return $this->belongsTo(Doctor::class);
    }
    public function hospital(){
        return $this->belongsTo(Hospital::class);
    }

    public function building(){
        return $this->belongsTo(Building::class,'clinic_id');
    }
}
