<?php

namespace App\Models\Doctor;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PatientFamily extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = ['breadwinner_id', 'child_id', 'relationship','person_id', 'created_at', 'updated_at'];

    public function patientbreadwinner(){
        return $this->belongsTo(Patient::class,'breadwinner_id');
    }

    public function patientchild(){
        return $this->belongsTo(Patient::class,'child_id');
    }

    public function person(){
        return $this->belongsTo(Person::class,'person_id');
    }



}
