<?php

namespace App\Models\Doctor;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Person extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
            'name',
            'birthDate',
            'birthCity',
            'address',
            'gender',
            'indentityCardNumber',
            'prsonalImage',
            'idinityCardImage',
            'deathDate',
            'user_Id',
   ] ;


   public function patient(){
    return $this->hasOne(Patient::class);

}

public function user(){
    return $this->hasOne(User::class);
}
public function patientdiagnose(){
    return $this->hasOne(PatientDiagnosis::class);
    }
    public function patientfamilies()
    {
        return $this->hasOne(PatientFamily::class);
    }

}
