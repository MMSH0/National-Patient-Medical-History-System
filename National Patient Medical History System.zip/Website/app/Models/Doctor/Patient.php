<?php

namespace App\Models\Doctor;

use App\Models\Admin\Surgery;
use App\Models\Doctor\Patient as AdminPatient;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Patient extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
         'blood_type',
          'hight',
          'weight',
          'user_id',
          'status',
    ] ;



    public function user(){
        return $this->belongsTo(User::class);
    }
    public function patientdiagnose(){
        return $this->hasOne(PatientDiagnosis::class);

    }

    public function patienttest(){
        return $this->hasMany(PatientTest::class);
    }

    public function patient(){
        return $this->hasMany(Patient::class);
    }

    public function visitation(){
        return $this->hasMany(Visitation::class);
    }
    public function patientray(){
        return $this->hasMany(PatientRay::class);
    }
    public function patientchronicdisease(){
        return $this->hasMany(PatientChronicDisease::class);
    }
    public function surgeries(){
        return $this->hasMany(Surgery::class);
    }

    public function family(){
        return $this->hasMany(PatientFamily::class,'child_id');

    }

}
