<?php

namespace App\Models\Doctor;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Medicen extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable = [
    'company_name',
     'scientific_name',
      'name',
       'description'
    ];
}
