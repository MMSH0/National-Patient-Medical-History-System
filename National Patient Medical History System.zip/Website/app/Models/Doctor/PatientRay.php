<?php

namespace App\Models\Doctor;

use App\Models\Admin\Building;
use App\Models\Admin\Doctor;
use App\Models\Admin\Radiology;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PatientRay extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [
        'doctor_id',
        'patient_id',
        'ray_id',
        'raycenter_id',
        'date',
        'time',
        'note',
        'result',
        'report',
    ] ;

    public function doctor(){
        return $this->belongsTo(Doctor::class);
    }
    public function patient(){
        return $this->belongsTo(Patient::class);
    }
    public function ray(){
        return $this->belongsTo(Radiology::class);
    }
    public function rayCenter(){
        return $this->belongsTo(Building::class,'raycenter_id');
    }
}
