<?php

namespace App\Models\Doctor;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Diagnose extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [

        'name', 'description'
    ];
    public function patientdiagnose(){
        return $this->hasOne(PatientDiagnosis::class);

    }
}
