<?php

namespace App\Models\Doctor;

use App\Models\Admin\ChronicDisease;
use App\Models\Admin\Doctor;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PatientChronicDisease extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = ['patient_id', 'disease_id', 'note', 'doctor_id'];

    public function patient(){
        return $this->belongsTo(Patient::class);
    }

    public function disease(){
        return $this->belongsTo(ChronicDisease::class,'disease_id');
    }

    public function doctor(){
        return $this->belongsTo(Doctor::class);
    }
    
}
