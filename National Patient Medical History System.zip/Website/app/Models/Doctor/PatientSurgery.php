<?php

namespace App\Models\Doctor;

use App\Models\Admin\Doctor;
use App\Models\Admin\Surgery;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class PatientSurgery extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable =[
        'doctor_id',
         'patient_id',
         'surgery_id',
         'surgery_date_time',
          'note',
          'status',

    ];
    public function doctor(){
        return $this->belongsTo(Doctor::class);
    }
    public function patient(){
        return $this->belongsTo(Patient::class);
    }
    public function surgery(){
        return $this->belongsTo(Surgery::class);
    }
    public function PatientSurgery()
    {
        return $this->belongsToMany(patient::class,Surgery::class);
    }

}
