<?php

namespace App\Models\Doctor;

use App\Models\Admin\Doctor;
use App\Models\Admin\Medicen;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Prescription extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
        'doctor_id',
        'medicen_id',
        'patient_id',
        'how_many_times',
        'usage_times',
        'note',
    ] ;
    public function doctor(){
        return $this->belongsTo(Doctor::class);
    }

    public function patient(){
        return $this->belongsTo(Patient::class);
    }
    public function medicen(){
        return $this->belongsTo(Medicen::class);
    }
}
