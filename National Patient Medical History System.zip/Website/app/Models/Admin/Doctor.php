<?php

namespace App\Models\Admin;

use App\Models\Doctor\PatientChronicDisease;
use App\Models\Doctor\PatientRay;
use App\Models\Doctor\PatientTest;
use App\Models\Doctor\Workinghour;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Doctor extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable=['user_id','experience','degree'];



    public function user(){
        return $this->belongsTo(User::class);
    }
    public function resume(){
        return $this->hasMany(Resume::class);
    }
    public function workinghour(){
        return $this->hasMany(Workinghour::class);
    }
    public function patientray(){
        return $this->hasMany(PatientRay::class);
    }

    public function patientchronicdisease(){
        return $this->hasMany(PatientChronicDisease::class);
    }
    public function patienttest(){
        return $this->hasMany(PatientTest::class);
    }
}
