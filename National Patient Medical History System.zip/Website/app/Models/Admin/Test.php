<?php

namespace App\Models\Admin;

use App\Models\Lab\PatientTest;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Test extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable =['name', 'normal', 'high', 'low', 'test_type_id', 'description'];

    public function test_type(){
        return $this->belongsTo(Test_type::class);
    }
    public function patienttest(){
        return $this->hasMany(PatientTest::class);
    }
}
