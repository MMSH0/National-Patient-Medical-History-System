<?php

namespace App\Models\Admin;

use App\Models\Doctor\Patient;
use App\Models\Doctor\PatientSurgery;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Surgery extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable=['name','description'];

    // to get patient surgeries ↡
    public function patient()
    {
        return $this->hasMany(Patient::class );
    }
}


