<?php

namespace App\Models\Admin;

use App\Models\Doctor\PatientChronicDisease;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ChronicDisease extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable =['name','description'];

    public function patientchronicdisease(){
        return $this->hasMany(PatientChronicDisease::class);
    }
}
