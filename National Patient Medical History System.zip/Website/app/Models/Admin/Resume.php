<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Resume extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = ['specialty_id', 'doctor_id'];


    public function doctor(){
        return $this->belongsTo(Doctor::class);
    }

    public function specialty(){
        return $this->belongsTo(Specialty::class);
    }
}
