<?php

namespace App\Models\Admin;

use App\Models\Doctor\PatientRay;
use App\Models\Doctor\Workinghour;
use App\Models\Lab\PatientTest;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Building extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [ 'name', 'city', 'address', 'building_type', 'hospital_id','logo'];

    public function hospital(){
        return $this->belongsTo(Hospital::class);
    }

    public function user(){
        return $this->hasOne(User::class,'building_id');
    }

    public function patienttest(){
        return $this->hasOne(PatientTest::class);
    }
    public function patientray(){
        return $this->hasOne(PatientRay::class,'raycenter_id');
    }
    public function workinghour(){
        return $this->hasOne(Workinghour::class);
    }

}

