<?php

namespace App\Models\Admin;

use App\Models\Ray\PatientRay;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Radiology extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [ 'name', 'type', 'Description'];
    public function patientray(){
        return $this->hasMany(PatientRay::class);
    }

}
