<?php

namespace App\Models\Admin;

use App\Models\Doctor\Workinghour;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Hospital extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable =['name','city','address','logo'];

    public function lab(){
        return $this->hasOne(Hospital::class);
    }
    public function workinghour(){
        return $this->hasOne(Workinghour::class);
    }
}
