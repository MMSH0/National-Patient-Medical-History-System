<?php

namespace App\Models\Lab;

use App\Models\Admin\Building;
use App\Models\Doctor\Patient;
use App\Models\Admin\Test;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PatientTest extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [
        'test_id', 'result', 'lab_id', 'test_date','test_time'
    ];
    public function building(){
        return $this->belongsTo(Building::class);
    }
    public function test(){
        return $this->belongsTo(Test::class);
    }

    public function patient(){
        return $this->belongsTo(Patient::class);
    }

}
