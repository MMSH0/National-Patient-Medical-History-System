<?php

namespace App\Listeners;

use App\Events\OperationOccurred;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;

class LogOperation
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(OperationOccurred $event): void
    {
       Log::channel('user_logs')->info('{ "name" : "'.$event->userId.'", "operation" : "'.$event->operation.'", "oldValue" : "'.$event->oldValue.'", "newValue" : "'.$event->newValue.'", "date" : "'.Carbon::now(). '"}');

    }
}
