<?php

namespace App\Http\Requests\Doctor;

use Illuminate\Foundation\Http\FormRequest;

class ChildrenRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name'=>'required|string',
            'last_name'=>'required|string',
            'birthday'=>'required',
            'Gender'=>'required',
            // 'phone'=> 'required|numeric|max:999999999|min:700000000|unique:users,phone_number',
            'City'=> 'required',
            'address'=>'required',
            'blood_type'=>'required',
            'hight'=>'required',
            'weight'=>'required',
            'relationship'=>'required',
        ];
    }

    public function messages() :array
    {
        return [

            'name.required' => 'الرجاء ادخال الاسم الاول',
            'last_name.required' => 'الرجاء ادخال اللقب',
            'birthday.required' => 'الرجاء ادخال تاريخ الميلاد ',
            'Gender.required' => 'الرجاء ادخال الجنس ',
            'weight.required' => 'الرجاء ادخال الوزن ',
            'hight.required' => 'الرجاء ادخال الطول ',
            // 'phone.numeric'=> 'الرجاء ادخال رقم الهاتف بشكل الصحيح',
            // 'phone.max'=> ' يجب ان لا يتجاوز رقم الهاتف عن 9 ارقام',
            // 'phone.min'=> ' يجب ان لا يقل رقم الهاتف عن 9 ارقام',
            // 'phone.required' => ' الرجاء ادخال رقم الهاتف  ',
            'address.required' => ' الرجاء ادخال  عنوان السكن  ',
            'City.required' => ' الرجاء ادخال المدينه  ',
            'relationship.required'=>'يجب اختيار صلة القرابة',
            // 'phone.unique'=> ' تم هذا استخدام رقم الهاتف من قبل ',

        ];

    }
}
