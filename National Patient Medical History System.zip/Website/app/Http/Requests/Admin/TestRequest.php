<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class TestRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name'=>'string|required',
            'normal'=>'string|required',
            'high'=>'string|required',
            'low'=>'string|required',
            'test_type_id'=>'required',
            'description'=>'string|required'
        ];
    }
    public function messages() :array
    {
        return [
            'name.required' => 'الرجاء ادخال اسم الفحص',
            'normal.required' => 'الرجاء ادخال النسبه الطبيعيه ',
            'high.required' => 'الرجاء ادخال النسبة المرتفعه ',
            'low.required' => 'الرجاء ادخال النسبة المنخفضة ',
            'test_type_id.required' => 'الرجاء اختيار نوع الفحص ',
            'description.required' => 'الرجاء ادخال الوصف ',

        ];
    }
}
