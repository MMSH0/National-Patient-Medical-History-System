<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class DoctorRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'first_name'=>'required|string',
            'last_name'=>'required|string',
            'birthday'=>'required|string',
            'geneder'=>'required|string',
            'identity_card'=>'required|numeric|unique:people,indentityCardNumber',
            'email'=>'required|email|unique:users,email',
            'phone'=> 'required|numeric|max:999999999|min:700000000|unique:users,phone_number',
            'city'=> 'required|string',
            'image'=>'required|image|mimes:jpeg,png,jpg|max:2048',
            'exprience'=>'required',
            'degree'=>'required',
            'address'=>'required',
            // 'indentityCardImage_F'=>'required|image|mimes:jpeg,png,jpg|max:2048',
            // 'indentityCardImage_B'=>'required|image|mimes:jpeg,png,jpg|max:2048',

        ];
    }

    public function messages() :array
    {
        return [
            'first_name.required' => 'الرجاء ادخال الاسم الاول',
            'last_name.required' => 'الرجاء ادخال اللقب',
            'birthday.required' => 'الرجاء ادخال تاريخ الميلاد ',
            'geneder.required' => 'الرجاء ادخال الجنس ',
            'identity_card.required' => 'الرجاء اختيار رقم الهويه ',
            'email.required' => ' الرجاء ادخال الايميل  ',
            'phone.numeric'=> 'الرجاء ادخال رقم الهاتف بشكل الصحيح',
            'phone.unique'=> ' تم استخدام هذا رقم الهاتف من قبل ',
            'identity_card.unique'=> ' تاكد من رقم الهوية مسجل لدينا من قبل ',
            'email.unique'=> ' تم استخدام هذا البريد الالكتروني  من قبل ',
            'phone.max'=> ' يجب ان لا يتجاوز رقم الهاتف عن 9 ارقام',
            'phone.min'=> ' يجب ان لا يقل رقم الهاتف عن 9 ارقام',
            'phone.required' => ' الرجاء ادخال رقم الهاتف  ',
            'address.required' => ' الرجاء ادخال  عنوان السكن  ',
            'city.required' => ' الرجاء ادخال المدينه  ',
            'exprience.required' => ' الرجاء اختيار ملف السيرة الذاتية  ',
            'degree.required' => ' الرجاء اختيار   الدرجة الطبية  ',
            'image.required' => ' الرجاء ادخال الصوره الشخصيه  ',
            'image.image' => ' الرجاء اختيار صوره من نوع jpg,png,jpeg  ',
            'indentityCardImage_F.image' => ' الرجاء اختيار صوره من نوع jpg,png,jpeg  ',
            'indentityCardImage_B.image' => ' الرجاء اختيار صوره من نوع jpg,png,jpeg  ',
            'indentityCardImage_F.required' => ' الرجاء اختيار صورة البطاقه الامامية  ',
            'indentityCardImage_B.required' => ' الرجاء اختيار صورة البطاقة الخلفيه  ',

        ];
    }
}
