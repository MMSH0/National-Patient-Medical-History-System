<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class LabRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $userId = $this->input('unumber');

        return [
            'name'=>'required|string',
            'city'=>'required|string',
            'email'=>'required|email|unique:users,email,'. $userId,
            'phone'=> 'required|numeric|max:999999999|min:000000000|unique:users,phone_number,'. $userId,
            'address'=>'required|string',
            'hospital'=>'required',
        ];
    }

    public function messages() :array
    {
        return [
            'name.required' => 'الرجاء ادخال اسم العيادة',
            'city.required' => 'الرجاء اختيار اسم المدينه ',
            'address.required' => 'الرجاء ادخال عنوان العيادة ',
            'hospital.required' => 'الرجاء اختيار اسم المستشفى/خارجية    ',
            'email.unique'=> ' تم استخدام هذا البريد الالكتروني  من قبل ',
            'phone.unique'=> ' تم هذا استخدام رقم الهاتف من قبل ',
        ];
    }
}
