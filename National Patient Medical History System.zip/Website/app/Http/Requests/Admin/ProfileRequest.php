<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class ProfileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $userId = $this->input('number');
        return [
            'name'=>'required|string',
            'birthDate'=>'required|string',
            'email'=>'required|email|unique:users,email,'.$userId,
            'phoneNumber'=> 'required|numeric|max:999999999|min:700000000|unique:users,phone_number,'.$userId,
            'birthCity'=> 'required|string',
            'address'=>'required',
        ];
    }
    public function messages() :array
    {
        return [
            'name.required' => 'الرجاء ادخال الاسم ',
            'birthDate.required' => 'الرجاء ادخال تاريخ الميلاد ',
            'email.required' => ' الرجاء ادخال الايميل  ',
            'phoneNumber.numeric'=> 'الرجاء ادخال رقم الهاتف بشكل الصحيح',
            'phoneNumber.max'=> ' يجب ان لا يتجاوز رقم الهاتف عن 9 ارقام',
            'phoneNumber.min'=> ' يجب ان لا يقل رقم الهاتف عن 9 ارقام',
            'phoneNumber.required' => ' الرجاء ادخال رقم الهاتف  ',
            'address.required' => ' الرجاء ادخال  عنوان السكن  ',
            'birthCity.required' => ' الرجاء ادخال المدينه  ',
            'email.unique'=> ' تم استخدام هذا البريد الالكتروني  من قبل ',
            'phoneNumber.unique'=> ' تم هذا استخدام رقم الهاتف من قبل ',
        ];
    }
}
