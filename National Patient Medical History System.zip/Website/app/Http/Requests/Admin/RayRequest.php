<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class RayRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $userId = $this->input('unumber');


        return [
            'name'=>'required|string',
            'email'=>'required|email|unique:users,email,'.$userId ,
            'phone'=> 'required|numeric|max:999999999|min:000000000|unique:users,phone_number,'.$userId ,
            'city'=>'required|string',
            'address'=>'required|string',
            'hospital'=>'required','string',
        ];
    }

    public function messages() :array
    {
        return [
            'name.required' => 'الرجاء ادخال اسم مركز الأشعة',
            'email.required' => ' الرجاء ادخال الايميل  ',
            'phone.numeric'=> 'الرجاء ادخال رقم الهاتف بشكل الصحيح',
            'phone.max'=> ' يجب ان لا يتجاوز رقم الهاتف عن 9 ارقام',
            'email.unique'=> ' تم استخدام هذا البريد الالكتروني  من قبل ',
            'phone.unique'=> ' تم هذا استخدام رقم الهاتف من قبل ',
            'phone.min'=> ' يجب ان لا يقل رقم الهاتف عن 9 ارقام',
            'phone.required' => ' الرجاء ادخال رقم الهاتف  ',
            'city.required' => 'الرجاء اختيار اسم المدينه ',
            'address.required' => 'الرجاء ادخال عنوان مركز الأشعة ',
            'hospital.required' => 'الرجاء اختيار اسم المستشفى/ خارجي',
        ];
    }
}
