<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'first_name'=>'required|string',
            'last_name'=>'required|string',
            'birthday'=>'required|string',
            'geneder'=>'required|string',
            'identity_card'=>'required|numeric|unique:people,indentityCardNumber',
            'email'=>'required|email|unique:users,email',
            'phone'=> 'required|numeric|max:999999999|min:700000000|unique:users,phone_number',
            'city'=> 'required|string',
            'address'=>'required',
        ];
    }

    public function messages() :array
    {
        return [
            'first_name.required' => 'الرجاء ادخال الاسم الاول',
            'last_name.required' => 'الرجاء ادخال اللقب',
            'birthday.required' => 'الرجاء ادخال تاريخ الميلاد ',
            'geneder.required' => 'الرجاء ادخال الجنس ',
            'identity_card.required' => 'الرجاء ادخال رقم الهويه ',
            'identity_card.unique' => 'الرجاء تاكد من رقم الهويه تم استخدامها من قبل ',
            'email.required' => ' الرجاء ادخال الايميل  ',
            'phone.numeric'=> 'الرجاء ادخال رقم الهاتف بشكل الصحيح',
            'phone.max'=> ' يجب ان لا يتجاوز رقم الهاتف عن 9 ارقام',
            'phone.min'=> ' يجب ان لا يقل رقم الهاتف عن 9 ارقام',
            'phone.required' => ' الرجاء ادخال رقم الهاتف  ',
            'address.required' => ' الرجاء ادخال  عنوان السكن  ',
            'city.required' => ' الرجاء ادخال المدينه  ',
            'email.unique'=> ' تم استخدام هذا البريد الالكتروني  من قبل ',
            'phone.unique'=> ' تم هذا استخدام رقم الهاتف من قبل ',

        ];
    }

}
