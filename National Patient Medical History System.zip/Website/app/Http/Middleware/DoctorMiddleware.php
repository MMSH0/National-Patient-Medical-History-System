<?php

namespace App\Http\Middleware;

use App\Models\Admin\Primation;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class DoctorMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $primation = Primation::where('user_id',Auth::user()->id)->with('role')->get();
        foreach($primation as $pre){

            if ($pre->role->user_type === 'admin'  || $pre->role->user_type  === 'superadmin') {
                $usertype = $pre->role->user_type;
                break;
            } else if ($pre->role->user_type === 'lab') {
                $usertype = $pre->role->user_type;
                break;
            }else if ($pre->role->user_type === 'ray') {
                $usertype = $pre->role->user_type;
                break;
            }
            else if ($pre->role->user_type === 'doctor') {
                $usertype = $pre->role->user_type;
                break;
            }
            else if ($pre->role->user_type === 'labray') {
                $usertype = $pre->role->user_type;
                break;
            }
            else {
                $usertype = $pre->role->user_type;
            }
        }
        if((auth()->check() && $usertype  == 'doctor' && auth()->user()->status == 1) ){

            return $next($request);

        }

        return redirect('/');
    }
}
