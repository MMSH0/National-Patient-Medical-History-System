<?php

namespace App\Http\Middleware;

use App\Models\Admin\Primation;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class RedirectIfAuthenticated
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, string ...$guards): Response
    {
        $guards = empty($guards) ? [null] : $guards;

        foreach ($guards as $guard) {
            if (Auth::guard($guard)->check()) {
                // Redirect based on user type

                $primation = Primation::where('user_id', Auth::user()->id)->with('role')->get();

                foreach ($primation as $pre) {


                    if ($pre->role->user_type === 'admin'  || $pre->role->user_type  === 'superadmin') {
                        $usertype = $pre->role->user_type;
                        break;
                    } else if ($pre->role->user_type === 'lab') {
                        $usertype = $pre->role->user_type;
                        break;
                    }else if ($pre->role->user_type === 'ray') {
                        $usertype = $pre->role->user_type;
                        break;
                    }
                    else if ($pre->role->user_type === 'doctor') {
                        $usertype = $pre->role->user_type;
                        break;
                    }
                    else if ($pre->role->user_type === 'labray') {
                        $usertype = $pre->role->user_type;
                        break;
                    }
                    else {
                        $usertype = $pre->role->user_type;
                    }
                }


                if ($usertype  === 'admin' || $usertype  === 'superadmin') {
                    return redirect()->route('admin.index');
                } elseif ($usertype  === 'lab') {
                    return redirect()->route('lab.index');
                } elseif ($usertype  === 'ray') {
                    return redirect()->route('ray.index');
                } elseif ($usertype  === 'doctor') {
                    return redirect()->route('doctor.index');
                } elseif ($usertype  === 'labray') {
                    return redirect()->route('labray.index');
                } else {
                    // Handle other user types or redirect to a default route
                    return redirect('/home');
                }
            }
        }


        return $next($request);
    }
}
