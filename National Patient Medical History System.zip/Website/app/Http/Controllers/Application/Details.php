<?php

namespace App\Http\Controllers\Application;

use App\Http\Controllers\Controller;
use App\Models\Admin\Building;
use App\Models\Admin\ChronicDisease;
use App\Models\Admin\Diagnose;
use App\Models\Admin\Doctor;
use App\Models\Admin\Hospital;
use App\Models\Admin\Medicen;
use App\Models\Admin\Radiology;
use App\Models\Admin\Specialty;
use App\Models\Admin\Test;
use App\Models\Doctor\Appointement;
use App\Models\Doctor\Patient;
use App\Models\Doctor\PatientChronicDisease;
use App\Models\Doctor\PatientDiagnosis;
use App\Models\Doctor\PatientRay;
use App\Models\Doctor\PatientSurgery;
use App\Models\Doctor\PatientTest;
use App\Models\Doctor\Prescription;
use Illuminate\Http\Request;

class Details extends Controller
{
    public function Tests(Request $request)
    {
        return PatientTest::where('patient_id', $request->pid)
        ->with([ 'lab.user','test.test_type','doctor.user.person'])
        ->orderBy('id', 'DESC')->get();

    }

    public function Medicens(Request $request)
    {
        return Prescription::where('patient_id', $request->pid)
        ->with([ 'medicen','doctor.user.person'])
        ->orderBy('id', 'DESC')->get();
    }


    public function Diagnosies(Request $request)
    {
        return PatientDiagnosis::where('patient_id', $request->pid)
        ->with(['doctor.user.person', 'diagnosis'])
        ->orderBy('id', 'DESC')->get();
    }
    public function ChronicDisease(Request $request)
    {
        return PatientChronicDisease::where('patient_id', $request->pid)
        ->with(['doctor.user.person', 'disease'])
        ->orderBy('id', 'DESC')->get();
    }
    public function Rays(Request $request)
    {
        return PatientRay::where('patient_id', $request->pid)
        ->with([ 'ray','doctor.user.person','rayCenter'])
        ->orderBy('id', 'DESC')->get();
    }
    public function Surgery(Request $request)
    {
        return PatientSurgery::where('patient_id', $request->pid)
        ->with([ 'surgery','doctor.user.person'])
        ->orderBy('id', 'DESC')->get();
    }
    public function Doctors()
    {

        return Doctor::join('users', 'doctors.user_id', '=', 'users.id')
            ->join('people', 'users.id', '=', 'people.user_id')
            ->with(['workinghour' => function($query) {
                $query->whereNotNull('working_day');
            }, 'workinghour.hospital', 'workinghour.building', 'resume.specialty'])
            ->whereHas('workinghour', function ($query) {
                $query->whereNotNull('working_day');
            })
            ->select('doctors.*',
                     'people.name AS DoctorName',
                     'people.prsonalImage AS doctorImage',
                     'users.status')
            ->orderBy('id', 'DESC')->get();
    }
    public function Hospitals()
    {
        return Hospital::all();
    }

    public function Cities()
    {
        return Hospital::all()->pluck('city');
    }


    public function Buildings()
    {
        return Building::where('building_type', 'عيادة')->orderBy('id', 'DESC')->get();
    }
    public function Appointment(Request $request)
    {
        $appointement=Appointement::where('doctor_id', $request->doctor_id)->where('patient_id', $request->patient_id)->where('date' , $request->date)->where( 'time' , $request->time)->orderBy('id', 'DESC')->get()->first();

        if (empty($appointement)) {
            Appointement::create([
                'doctor_id' => $request->doctor_id,
                'patient_id' => $request->patient_id,
                'date' => $request->date,
                'time' => $request->time,
                'status' => '2'
            ]);
            return response()->json(['message' => 'تم الحجز بنجاح','statusCode'=>200], 200);

        }else{
            return response()->json(['error' =>'لديك حجز سابق ','statusCode'=>400], 400);

        }
    }

    public function Appointments(Request $request)
    {
        $appointement = Patient::join('appointements', 'patients.id', '=', 'appointements.patient_id')
        ->join('doctors', 'appointements.doctor_id', '=', 'doctors.id')
        ->join('people', 'patients.user_id', '=', 'people.user_id')
        ->join('people AS doctorsName', 'doctors.user_id', '=', 'doctorsName.user_id')
        ->select('appointements.*', 'people.name AS patientName', 'doctorsName.name AS doctorName')
        ->where('patient_id', $request->patient_id)
        ->get()
        ->unique(function ($item) {
            return $item['id'] . $item['updated_at']; // Example of custom logic
        });

        return response()->json(['appointements' => $appointement,'statusCode'=>200], 200);

    }
}
