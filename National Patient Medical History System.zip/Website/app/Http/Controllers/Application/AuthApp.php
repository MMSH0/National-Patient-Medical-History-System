<?php

namespace App\Http\Controllers\Application;

use App\Http\Controllers\Controller;
use App\Models\Admin\Person;
use App\Models\Admin\Primation;
use App\Models\Doctor\Patient;
use App\Models\Doctor\PatientFamily;
use App\Models\User;
use App\Notifications\SendPushNotification;
use App\Rules\checkPhoneNumber;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Notification;
use Kutia\Larafirebase\Facades\Larafirebase;

class AuthApp extends Controller
{


    public function notification($userId, $title, $message)
    {



        try {
            $fcmTokens = User::where('id', $userId)->whereNotNull('fcm_token')->pluck('fcm_token')->first();

            $url = 'https://fcm.googleapis.com/fcm/send';


            $serverKey = "AAAAbor-lLo:APA91bFnN-I3OUh7XCwa6JprxUlbGQnu_W8Gif7IJROdPaXXdQuHvheAT3IAGG_Ss7QBshdI7BP4ttWzP2yoJuRldzse_3-YBnmE_7EhUjHewsP-gdSDVLrtYNonRalWOYvf7OmRmd6N";

            $dataArr = [
                "click_action" => "FLUTTER_NOTIFICATION_CLICK",
                "status" => "done"
            ];


            $data = [
                "registration_ids" => [$fcmTokens],
                "notification" => [
                    "title" => str($title),
                    "body" => str($message),
                    "sound" => "default",
                ],
                "data" => $dataArr,
                "priority" => "high",
            ];

            $encodedData = json_encode($data);

            $headers = [
                "Authorization:key=" . $serverKey,
                "Content-Type: application/json"
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedData);
            $result = curl_exec($ch);
        } catch (\Exception $e) {
            dd($e);
        }
    }

    public function UploadImage(Request $request)
    {
        $image = $request->img;  // your base64 encoded
        $image = str_replace('data:image/png;base64,', '', $image);
        $image = str_replace(' ', '+', $image);
        $imageName = Carbon::now()->format('YmdHis') . '.' . 'jpg';
        File::put(public_path() . '/patient/profile/' . $imageName, base64_decode($image));
        $user = User::where('id', $request->uid)->get()->first();
        $user->person->update(['prsonalImage' =>  $imageName]);
        return response()->json(['message' => 'تم تحديث الصورة الشخصية بنجاح', 'statusCode' => 200], 200);
    }

    public function UploadPDF($img_1, $img_2, $img_3, $title)
    {

        $image_1 = $img_1;  // your base64 encoded
        $image_1 = str_replace('data:image/png;base64,', '', $image_1);
        $image_1 = str_replace(' ', '+', $image_1);
        $imageName_1 = '1' . '.' . 'jpg';
        File::put(public_path() . '/patient/identityCards/' . $imageName_1, base64_decode($image_1));


        $image_2 = $img_2;  // your base64 encoded
        $image_2 = str_replace('data:image/png;base64,', '', $image_2);
        $image_2 = str_replace(' ', '+', $image_2);
        $imageName_2 = '2' . '.' . 'jpg';
        File::put(public_path() . '/patient/identityCards/' . $imageName_2, base64_decode($image_2));

        $image_3 = $img_3;  // your base64 encoded
        $image_3 = str_replace('data:image/png;base64,', '', $image_3);
        $image_3 = str_replace(' ', '+', $image_3);
        $imageName_3 = '3' . '.' . 'jpg';
        File::put(public_path() . '/patient/identityCards/' . $imageName_3, base64_decode($image_3));

        $image1 = public_path('/patient/identityCards/' . $imageName_1);
        $image2 = public_path('/patient/identityCards/' . $imageName_2);
        $image3 = public_path('/patient/identityCards/' . $imageName_3);
        $name = Carbon::now()->format('YmdHis') . '.pdf';
        $pdf = Pdf::loadView('pdf/image', compact('image1', 'image2', 'image3', 'title'))->setPaper('a4', 'landscape')->save('files/patients/IDCards/' .  $name);
        $pdf->setOption('enable-local-file-access', true);

        unlink($image1);
        unlink($image2);
        unlink($image3);


        return $name;
    }



    public function Authenticate(Request $request)
    {

        $valditor = Validator::make($request->all(), [

            'phone_number' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:9',
            'password' => 'required|string',

        ]);
        $valditor->setAttributeNames([
            'phone_number' => ' رقم الهاتف ',
            'password' => ' كلمة السر ',
        ]);

        $valditor->setCustomMessages([
            'required' => ' يجب ادخال :attribute ',
            'regex' => ' يجب ان يكون :attribute من ارقام فقط',
            'min' => ' يجب ان يكون :attribute من 9 ارقام ',

        ]);
        if ($valditor->fails()) {
            return response()->json(['error' => $valditor->errors()], 422);
        } else {

            $credentials = request(['phone_number', 'password']);

            if (Auth::attempt($credentials)) {
                $user = Auth::user();
                $usertype = '';
                $primation = Primation::where('user_id', $user->id)->with('role')->get();
                foreach ($primation as $pre) {
                    if ($pre->role->user_type === 'patient') {
                        $usertype = $pre->role->user_type;
                        break;
                    }
                }
                if ($usertype === 'patient') {
                    // if ($user->status == 1) {


                    if ($user instanceof \App\Models\User) {

                        $user->fcm_token = $request->fcm_token;
                        $user->save();
                        return response()->json(['userStatus' => true, 'statusCode' => 200], 200);
                    } else {
                        return response()->json(['userStatus' => false, 'error' => 'رقم الهاتف او كلمة السر غير صحيحة', 'statusCode' => 401], 401);
                    }
                    // }
                    // else {
                    //     return response()->json(['userStatus' => false, 'error' => 'الحساب غير فعال', 'statusCode' => 403], 403);
                    // }
                } else {
                    return response()->json(['userStatus' => false, 'error' => ' لا يوجد حساب بهذا الرقم ', 'statusCode' => 401], 401);
                }
            } else {
                return response()->json(['userStatus' => false, 'error' => 'رقم الهاتف او كلمة السر غير صحيحة', 'statusCode' => 401], 401);
            }
        }
    }


    public function Login(Request $request)
    {

        $valditor = Validator::make($request->all(), [

            'phone_number' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:9',
            'password' => 'required|string',

        ]);
        $valditor->setAttributeNames([
            'phone_number' => ' رقم الهاتف ',
            'password' => ' كلمة السر ',
        ]);

        $valditor->setCustomMessages([
            'required' => ' يجب ادخال :attribute ',
            'regex' => ' يجب ان يكون :attribute من ارقام فقط',
            'min' => ' يجب ان يكون :attribute من 9 ارقام ',

        ]);
        if ($valditor->fails()) {
            return response()->json(['error' => $valditor->errors()], 422);
        } else {

            $credentials = request(['phone_number', 'password']);
            if (Auth::attempt($credentials)) {
                $user = Auth::user();
                $usertype = '';

                $primation = Primation::where('user_id', $user->id)->with('role')->get();
                foreach ($primation as $pre) {
                    if ($pre->role->user_type === 'patient') {
                        $usertype = $pre->role->user_type;
                        break;
                    }
                }
                if ($usertype === 'patient') {
                    // if ($user->status == 1) {
                    if ($request['verify'] == 'false') {
                        $code = rand(pow(10, 4 - 1), pow(10, 4) - 1);
                        if ($user instanceof \App\Models\User) {
                            $user->verfication_code = $code;
                            $user->save();

                            AuthApp::notification($user->id, "كود التحقق", str($code));
                        }
                        return response()->json(['verifyCode' => str($code), 'statusCode' => 402], 402);
                    } else if ($request['verify'] == 'true') {
                        if (empty($user->person->indentityCardNumber) || empty($user->person->idinityCardImage)) {

                            return response()->json(['uid' => $user->id, 'personId' => $user->person->id, 'statusCode' => 300], 300);
                        } else {
                            if ($user instanceof \App\Models\User) {
                                $user->fcm_token = $request->fcm_token;
                                $user->save();
                                $token = $user->createToken('authToken')->plainTextToken;
                                $patient = Patient::where('user_id', $user->id)->first();

                                return response()->json(['token' => $token, 'uid' => $user->id, 'pid' => $patient->id, 'statusCode' => 200], 200);
                            } else {
                                return response()->json(['error' => 'رقم الهاتف او كلمة السر غير صحيحة', 'statusCode' => 401], 401);
                            }
                        }
                    }
                    // } else {
                    //     return response()->json(['error' => 'الحساب غير فعال', 'statusCode' => 403], 403);
                    // }
                } else {
                    return response()->json(['error' => ' لا يوجد حساب بهذا الرقم ', 'statusCode' => 401], 401);
                }
            } else {
                return response()->json(['error' => 'رقم الهاتف او كلمة السر غير صحيحة', 'statusCode' => 401], 401);
            }
        }
    }


    public function Register(Request $request)
    {


        $valditor = Validator::make($request->all(), [
            'name' => 'required|string',
            'birthCity' => 'required|string',
            'address' => 'required|string',
            'birthDate' => 'required|string',
            'gender'=>'required',
            'hight' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/',
            'weight' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/',
            'phone_number' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:9',
            'password' => 'required|string',

        ]);
        $valditor->setAttributeNames([
            'phone_number' => ' رقم الهاتف ',
            'name' => ' الاسم الرباعي ',
            'password' => ' كلمة السر ',
            'birthCity' => 'المدينة',
            'hight' => 'الطول',
            'weight' => 'وزن',
            'gender'=>'الجنس',
            'birthDate' => 'تاريخ الميلاد',
            'address' => 'العنوان',
        ]);

        $valditor->setCustomMessages([
            'required' => ' يجب ادخال :attribute ',
            'regex' => ' يجب ان يكون :attribute من ارقام فقط',
            'min' => ' يجب ان يكون :attribute من 9 ارقام ',

        ]);
        if ($valditor->fails()) {
            return response()->json(['error' => $valditor->errors(), 'statusCode' => 422], 422);
        } else {
            $user = User::where('phone_number', $request->input('phone_number'))->get()->first();


            if (isset($user)) {
                $patient = Primation::where('user_id',  $user->id)->where("role_id", 6)->get()->first();


                if (!isset($patient)) {
                    if (Carbon::parse($request->input('birthDate'))->age >= 18) {

                        // $validatedDate  = $this->validate($request, [
                        //     'phone_number' => ['required', new  checkPhoneNumber('users', 'phone_number')]
                        // ]);

                        // User::create([
                        //     'phone_number' => $request->input('phone_number'),

                        //     'password' => Hash::make($request->input('password')), 'build_id' => 0,
                        // ]);

                        $userId = User::where('phone_number', $request->input('phone_number'))->first();

                        Primation::create([
                            'user_id' => $userId->id,
                            'role_id' => 6,
                        ]);

                        Person::create([
                            'name' => $request->input('name'),
                            'birthDate' => $request->input('birthDate'),
                            'birthCity' => $request->input('birthCity'),
                            'address' => $request->input('address'),
                            'gender' => $request->input('gender'),
                            'user_Id' => $userId->id,
                        ]);


                        Patient::create([
                            'blood_type' => $request->input('blood_type'),
                            'hight' => $request->input('hight'),
                            'weight' => $request->input('weight'),
                            'user_id' => $userId->id,

                        ]);

                        return response()->json(['message' => 'تم إنشاء السجل الطبي بنجاح', 'statusCode' => 200], 200);
                    } else {
                        return response()->json(['userStatus' => false, 'error' => 'لا يمكنك إنشاء حساب الا يقل عمرك عن 18 سنة', 'statusCode' => 401], 401);
                    }
                } else {

                    return response()->json(['userStatus' => false, 'error' => 'يوجد حساب يهذا الرقم ', 'statusCode' => 401], 401);
                }
            } else {
                if (Carbon::parse($request->input('birthDate'))->age >= 18) {

                    $validatedDate  = $this->validate($request, [
                        'phone_number' => ['required', new  checkPhoneNumber('users', 'phone_number')]
                    ]);

                    User::create([
                        'phone_number' => $request->input('phone_number'),
                        'status'=>'2',
                        'password' => Hash::make($request->input('password')), 'build_id' => 0,
                    ]);

                    $userId = User::where('phone_number', $request->input('phone_number'))->first();

                    Primation::create([
                        'user_id' => $userId->id,
                        'role_id' => 6,
                    ]);

                    Person::create([
                        'name' => $request->input('name'),
                        'birthDate' => $request->input('birthDate'),
                        'birthCity' => $request->input('birthCity'),
                        'address' => $request->input('address'),
                        'gender' => $request->input('gender'),
                        'user_Id' => $userId->id,
                    ]);


                    Patient::create([
                        'blood_type' => $request->input('blood_type'),
                        'hight' => $request->input('hight'),
                        'weight' => $request->input('weight'),
                        'user_id' => $userId->id,

                    ]);

                    return response()->json(['message' => 'تم إنشاء السجل الطبي بنجاح', 'statusCode' => 200], 200);
                } else {
                    return response()->json(['userStatus' => false, 'error' => 'لا يمكنك إنشاء حساب الا يقل عمرك عن 18 سنة', 'statusCode' => 401], 401);
                }
            }
        }
    }

    public function Profile(Request $request)
    {


        return User::join('people', 'users.id', '=', 'people.user_id')->join('patients', 'patients.user_id', '=', 'users.id')->where('users.id', $request->uid)->select('users.status AS accountStatus', 'patients.*', 'users.*', 'people.*')->get()->first();
    }

    public function GetBreadwinner(Request $request)
    {

        return PatientFamily::join('patients', 'patient_families.child_id', 'patients.id')->join('people', 'patient_families.person_id', 'people.id')->where('breadwinner_id', $request->pid)->whereNull("patients.user_id")->get();
    }

    public function ChangePassword(Request $request)
    {
        $newPass = bcrypt($request->newPass);
        $user = User::find($request->id);
        if (!empty($user)) {
            if (Hash::check($request->oldPass, $user->password)) {
                $user->password = $newPass;
                $user->save();
                // $user->tokens->delete();

                return response()->json(['message' => 'تم تغيير كلمة السر بنجاح', 'statusCode' => 200], 200);
            } else {
                return response()->json(['message' => '  كلمة السر غير صحيحة', 'statusCode' => 400], 400);
                // return response()->json(['message' =>str(Hash::check( $oldPass,$user->password)), 'statusCode' => 400], 400);

            }
        } else {
            // $user->tokens->delete();
            return response()->json(['message' => '  حدث خطا في الخادم اثناء تغيير كلمة السر   ', 'statusCode' => 403], 403);
        }
    }

    public function ChangePhoneNumber(Request $request)
    {
        $user = User::find((int)$request->id);
        if (!empty($user)) {
            if (Hash::check($request->password, $user->password)) {

                if (!empty($user->where('phone_number', $request->input('phoneNumber'))->first())) {
                    return response()->json(['message' => 'تم استخدام هذا رقم الهاتف من قبل ',  'statusCode' => 400], 400);
                } else {
                    if ($request['status'] == 'false') {
                        $code = rand(pow(10, 4 - 1), pow(10, 4) - 1);
                        AuthApp::notification($user->id, "كود التحقق", str($code));
                        return response()->json(['verifyCode' => str($code), 'statusCode' => 402], 402);
                    } else
                     if ($request['status'] == 'true') {
                        $user->phone_number = $request->phoneNumber;
                        $user->save();
                        AuthApp::notification($user->id, "تنبيه ", 'تم تغيير رقم الهاتف');
                        return response()->json(['message' => 'تم تغيير رقم الهاتف',  'statusCode' => 200], 200);
                    }
                }
            } else {
                return response()->json(['message' => 'كلمة السر غير صحيحة',  'statusCode' => 400], 400);
            }
        } else {
            return response()->json(['message' => 'حدث خطاء ما اثناء تغيير رقم الهاتف',  'statusCode' => 400], 400);
        }
    }

    public function updateIdentityCard(Request $request)
    {

        $user = User::findOrFail($request->id);
        $user->person->indentityCardNumber =null;
        $user->person->idinityCardImage =null;
        if (!isset($user->person->indentityCardNumber) || !isset($user->person->idinityCardImage)) {

            $user->status='2';
            $user->person->indentityCardNumber = $request->IDCardNum;
            $user->person->idinityCardImage = AuthApp::UploadPDF($request->image_1, $request->image_2, $request->image_3, $user->person->name);
            $user->person->save();
            $user->save();
            if ($user instanceof \App\Models\User) {
                $token = $user->createToken('authToken')->plainTextToken;
                $patient = Patient::where('user_id', $user->id)->first();
                return response()->json(['token' => $token, 'uid' => $user->id, 'pid' => $patient->id, 'statusCode' => 200], 200);
            }
            return response()->json(['message' => ' حدث خطا اثناء تحديث البيانات الهوية الشخصية', 'statusCode' => 400], 400);
        }
    }
}
