<?php

namespace App\Http\Controllers\Manage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class LogController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function convertLogMessageToJson($logMessage) {
        // Extract JSON data from log message
        $jsonData = substr($logMessage, strpos($logMessage, '{'));

        // Decode JSON data
        $decodedData = json_decode($jsonData, true);

        // Convert decoded data back to JSON string
        $jsonString = json_encode($decodedData);

        // Return JSON string
        return $jsonString;
    }

    public function readLogFile()
    {
        // Read the log file
        $filePath = storage_path('logs/user.log');

        $contents = file_get_contents($filePath);

        // Split the file contents into lines
        $lines = explode("\n", $contents);

        $logs = [];

        // Parse each line as JSON and extract key-value pairs
        foreach ($lines as $line) {
            // Skip empty lines
            if (empty($line)) {
                continue;
            }

            // Attempt to decode the JSON
            $logData = json_decode($this->convertLogMessageToJson($line), true);


            // Check if decoding was successful
            if ($logData === null && json_last_error() !== JSON_ERROR_NONE) {
                // Log an error or return an error response
                return 'Error decoding JSON: ' . json_last_error_msg();
            }

            // If JSON decoding was successful, add data to logs array
            if ($logData) {
                $logs[] = $logData;
            }

    }
    $index=0;

        // Pass the data to the view
        return view('A.log', compact('logs','index'));
    }
}
