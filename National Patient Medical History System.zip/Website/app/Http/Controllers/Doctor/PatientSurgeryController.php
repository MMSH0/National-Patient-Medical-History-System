<?php

namespace App\Http\Controllers\Doctor;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Doctor\PatientSurgeryRequest;
use App\Models\Admin\Surgery;
use App\Models\Doctor\Patient;
use App\Models\Doctor\PatientFamily;
use App\Models\Doctor\PatientSurgery;
use App\Models\Doctor\Person;
use Illuminate\Support\Facades\Auth;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Models\Admin\Doctor;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Crypt;

class PatientSurgeryController extends Controller
{

    public function notification($userId, $title, $message)
    {



        try {
            $fcmTokens = User::where('id', $userId)->whereNotNull('fcm_token')->pluck('fcm_token')->first();

            $url = 'https://fcm.googleapis.com/fcm/send';


              $serverKey ="AAAAbor-lLo:APA91bFnN-I3OUh7XCwa6JprxUlbGQnu_W8Gif7IJROdPaXXdQuHvheAT3IAGG_Ss7QBshdI7BP4ttWzP2yoJuRldzse_3-YBnmE_7EhUjHewsP-gdSDVLrtYNonRalWOYvf7OmRmd6N";

            $dataArr = [
                "click_action" => "FLUTTER_NOTIFICATION_CLICK",
                "status" => "done"
            ];


            $data = [
                "registration_ids" => [$fcmTokens],
                "notification" => [
                    "title" => str($title),
                    "body" => str($message),
                    "sound" => "default",
                ],
                "data" => $dataArr,
                "priority" => "high",
            ];

            $encodedData = json_encode($data);

            $headers = [
                "Authorization:key=" . $serverKey,
                "Content-Type: application/json"
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedData);
            $result = curl_exec($ch);
        } catch (\Exception $e) {
            dd($e);
        }
    }


    //make a new var calling the patient information to make inside the event in elses
    public function Index($id)
    {
        try {
            $id = Crypt::decryptString($id);

            $all_surgeries = Surgery::all();
            $index = 0;
            $surgery = PatientSurgery::with('surgery', 'patient')->get()->where('patient_id', $id);
            // dd($surgery);
            if (!$surgery) {
                // return 'error message';
            } else {
                return view('D.Patient_surgery', compact('all_surgeries', 'id', 'surgery', 'index'));
            }
        }catch (DecryptException $e) {

            return redirect()->route('doctor.patinet.surgery.index');
        }
    }

    public function Store(PatientSurgeryRequest $request)
    {

        if ($request->validated()) {

            try {
                $id = Crypt::decryptString($request['number']);
                $patient = Patient::findOrFail($id);
                foreach ($request->input('surgeries') as $surg) {
                    $surgery = Surgery::findOrFail($surg);
                    if (isset($patient->user)) {
                        PatientSurgeryController::notification($patient->user->id, '  تم اضافة عملية جراحية   : ' .   $surgery->name, ' من قبل الدكتور  ' . Auth::user()->person->name . ' بتاريخ ' . Carbon::now());
                        } else {

                            $barrwinner = Patient::findOrFail($patient->family[0]->breadwinner_id);

                            PatientSurgeryController::notification($barrwinner->user->id, '  تم اضافة  عملية جراحية    : ' .   $surgery->name, ' من قبل الدكتور  ' . Auth::user()->person->name . ' بتاريخ ' . Carbon::now());
                        }

                    PatientSurgery::create([
                        'doctor_id' => $request['Doctor_Id'],
                        'patient_id' =>    $id,
                        'surgery_id' => $surgery->id,
                        'surgery_date_time' =>$request['surgery_date_time'],
                        'status' => $request['Surgery_statues'],
                        'created_at' => Carbon::now(),
                        'note' => $request->input('notes'),
                    ]);


                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم اضافة العملية ( ' . $surgery->name . ' ) للمريض ( ' . $patient->name . ' )', null,   $request->input('notes')));
                }

                return redirect()->route('doctor.patient.surgery.index', ['id' => Crypt::encryptString($id)])->with('success', '   تم اضافة العملية بنجاح    ');
            }catch (DecryptException $e) {
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطأ في تعديل التشخيص   للمريض ( ' . isset($patient->user)? $patient->user->person->name :$patient->person->name. ' ) ', $e, null));

                return redirect()->route('doctor.patinet.index');
            }
        }
    }

    // public function Show($id)
    // {
    //     try {
    //         $id = Crypt::decryptString($id);
    //         $patientSurgeries = PatientSurgery::where('patient_id', $id)->get();
    //         $Surgeries = Surgery::all();
    //         $index = 0;
    //         return view('D.patient_Surgery', compact('patientSurgeries', 'index', 'Surgeries', 'id'));
    //     }catch (DecryptException $e) {
            // event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطأ في تعديل التشخيص   للمريض ( ' . $newPatient->user->person->name . ' ) ', $e, null));

    //         return redirect()->route('doctor.patinet.index');
    //     }
    // }

    public function Update(Request $request)
    {
        try {


            $id = Crypt::decryptString($request['number']);
            foreach ($request->input('surgeries') as $surg) {
                // in the log there is no name for the old surgery so, how can i get the specific surgery name
                //check this "not working ... working on it"
                $surgs = PatientSurgery::where('doctor_id', $request['Doctor_Id'])->where('patient_id', $id)->firstOrFail();

                $oldsurgs = Surgery::findOrFail($surgs->surgery_id);
                $newPatient = Patient::findOrFail($id);
                $personid = PatientFamily::where('child_id', $id)->first();
                $parientdetail = Person::with('patientfamilies')->find($personid->person_id);
                if ($surgs->doctor_id != $request['Doctor_Id']) {
                    $oldDoctor = Doctor::findOrFail($surgs->doctor_id);
                    $newDoctor = Doctor::findOrFail($request['Doctor_Id']);

                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل العملية ( ' . $oldsurgs->name . ' ) للمريض ( ' . $parientdetail->name . ' )',  $oldDoctor->user->person->name,  $newDoctor->user->person->name));
                    $surgs->doctor_id = $request['Doctor_Id'];
                }
                if ($surgs->patient_id != $id) {
                    $oldPatient = Patient::findOrFail($surgs->patient_id);

                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل العملية ( ' . $oldsurgs->name . ' ) للمريض ( ' . $parientdetail->name . ' )', $oldPatient->user->person->name,  $newPatient->user->person->name));

                    $surgs->patient_id = $id;
                }
                if ($surgs->surgery !=  $surg) {
                    $oldsurgs = Surgery::findOrFail($surgs->surgery_id);
                    $newsurgs = surgery::findOrFail($surg);
                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل العملية ( ' . $oldsurgs->name . ' ) للمريض ( ' . $parientdetail->name . ' )', $oldsurgs->name,  $newsurgs->name));


                    $surgs->surgery_id =  $surg;
                }

                if ($surgs->notes != $request->input('notes')) {
                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل ملاحظات العملية ( ' . $oldsurgs->name . ' ) للمريض ( ' . $parientdetail->name . ' )', $surgs->notes, $request->input('notes')));

                    $surgs->note = $request->input('notes');
                }
                $surgs->updated_at  =  Carbon::now();

                $surgs->save();
            }

            return redirect()->route('doctor.patient.surgery.index', ['id' => Crypt::encryptString($id)])->with('success', '   تم تعديل العملية  بنجاح    ');;
        }catch (DecryptException $e) {
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطأ في تعديل التشخيص   للمريض ( ' . $newPatient->user->person->name . ' ) ', $e, null));

            return redirect()->route('doctor.patinet.index');
        }
    }

    public function Report($id)
    {


        try {
            $id = Crypt::decryptString($id);
            $patient = PatientFamily::where('child_id', $id)->first();
            if (!isset($patient)) {
                $patient = Patient::findOrFail($id);
            }


            $surgery = PatientSurgery::with('surgery', 'patient')->get()->where('patient_id', $id);


            $index = 0;
            // dd($patient);
            // return view('pdf.reports.tests', compact('patient','tests','index'));

            $pdf = Pdf::loadView('pdf/reports/surgey', compact('patient','index', 'surgery',  'id'))->setPaper('a4', 'landscape')->download('report.pdf');
            return $pdf;
        }catch (DecryptException $e) {
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطأ في تعديل التشخيص   للمريض ( ' . $patient->user->person->name . ' ) ', $e, null));

            return redirect()->route('doctor.patinet.index');
        }
    }

}
