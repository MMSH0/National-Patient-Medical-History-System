<?php

namespace App\Http\Controllers\Doctor;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Doctor\ChildrenRequest;
use App\Models\Admin\Person;
use App\Models\Admin\Primation;
use App\Models\Doctor\Patient;
use App\Models\Doctor\PatientChronicDisease;
use App\Models\Doctor\PatientDiagnose;
use App\Models\Doctor\PatientFamily;
use App\Models\Doctor\PatientRay;
use App\Models\Doctor\PatientSurgery;
use App\Models\Doctor\PatientTest;
use App\Models\Doctor\Prescription;
use App\Models\Doctor\Visitation;
use App\Models\User;
use App\Rules\checkPhoneNumber;
use Carbon\Carbon;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use RealRashid\SweetAlert\Facades\Alert;

class ChildrenController extends Controller
{


    public function Index(Request $request)
    {
        try {
            $pid = Crypt::decryptString($request->pid);


            $children = PatientFamily::where('breadwinner_id', $pid)->whereHas('patientchild', function ($query) {
                $query->whereNull('user_id');
            })->get();
            $index = 0;
            return view('D.Children', compact('pid', 'children', 'index'));
        } catch (DecryptException $e) {
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطأ في تعديل التشخيص   للمريض ( ' . $children->person->name . ' ) ', $e, null));

            return redirect()->route('doctor.patinet.index');
        }
    }

    public function Add($pid)
    {
        return view('D.Add_children', compact('pid'));
    }


    public function Store(ChildrenRequest $request)
    {
        if ($request->validated()) {
            // dd($request->validated());


            try {
                $pid = Crypt::decryptString($request['number']);


                $name = $request->input('name') . '  ' . $request->input('last_name');

                if (Carbon::parse($request->input('birthday'))->age < 18) {

                    $patient = Patient::findOrFail($pid);

                    Person::create([
                        'name' => $name,
                        'birthDate' => $request->input('birthday'),
                        'birthCity' => $request->input('City'),
                        'address' => $request->input('address'),
                        'gender' => $request->input('Gender'),
                    ]);

                    $person_id = Person::where('name', $name)->where('birthDate', $request->input('birthday'))->where('birthCity', $request->input('City'))->where('address', $request->input('address'))->where('gender', $request->input('Gender'))->firstOrFail();

                    Patient::create([
                        'blood_type' => $request->input('blood_type'),
                        'hight' => $request->input('hight'),
                        'weight' => $request->input('weight'),
                    ]);

                    $patient_id = Patient::where('weight', $request->input('weight'))->where('hight', $request->input('hight'))->where('blood_type', $request->input('blood_type'))->firstOrFail();


                    PatientFamily::create([
                        'breadwinner_id' => $pid,
                        'child_id' => $patient_id->id,
                        'person_id' => $person_id->id,
                        'relationship' => $request->input('relationship'),
                    ]);
                    event(new OperationOccurred('د/ ' . Auth::user()->person->name, ' تم اضافة طفل للعائل ( ' . $patient->user->person->name . ' ) بعلاقة ( ' . $request->input('relationship') . ' ) ', null,  $name));
                    Alert::toast(' تمت اضافة الطفل   ' . $name . '  بنجاح ', 'success');

                    return redirect()->route('doctor.patient.children.index', ['pid' => $request['number']])->with('success', ' تمت اضافة الطفل   ' . $name . '  بنجاح ');
                }
                event(new OperationOccurred(Auth::user()->person->name, 'لم يتم انشاء سجل طبي بسبب ان عمره اكبر من  18 سنة ', null,   $name));
                Alert::error(' لايمكنك اضافة المريض   ' . $name . '  بسبب ان العمر اكبر من 18 سنة ');

                return redirect()->route('doctor.patient.children.index', ['pid' => $request['number']])->with('error', ' لايمكنك اضافة المريض   ' . $name . '  بسبب ان العمر اكبر من 18 سنة ');
            } catch (DecryptException $e) {
                event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطأ في تعديل التشخيص   للمريض ( ' .  $name . ' ) ', $e, null));


                return redirect()->route('doctor.patient.children.index', ['pid' => $request['number']]);
            }
        }
    }
    public function Info($id)
    {
        try {

            $id = Crypt::decryptString($id);


            return ChildrenController::Show($id);
        } catch (DecryptException $e) {

            return redirect()->route('doctor.patient.children.index');
        }
    }
    public function Show($number)
    {
        $child = PatientFamily::where('child_id', $number)->firstOrFail();
        $patient = Patient::where('id', $number)->firstOrFail();
        $diagnoses = PatientDiagnose::where('patient_id', $number)->count();
        $medicens = Prescription::where('patient_id', $number)->count();
        $rays = PatientRay::where('patient_id', $number)->count();
        $tests = PatientTest::where('patient_id', $number)->count();
        $diseases = PatientChronicDisease::where('patient_id', $number)->count();
        $children = PatientFamily::where('breadwinner_id', $number)->count();
        $surgeries = PatientSurgery::where('patient_id', $number)->count();
        event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم الوصول السجل الطبي الخاص بـ  ( ' . $child->person->name . ' ) ', null,   null));



        return view('D.Child_info', compact('patient', 'rays', 'medicens', 'tests', 'diagnoses', 'diseases', 'children', 'child', 'surgeries'));
    }

    public function UpdatePhone(Request $request)
    {
        $childs = PatientFamily::where('child_id', $request->number)->firstOrFail();
        $person = Person::findOrFail($childs->person_id);
        $child = Patient::findOrFail($request->number);
        $validatedDate  = $this->validate($request, [
            'phone_number' => ['required', new  checkPhoneNumber('users', 'phone_number')]
        ]);
        User::create([
            'phone_number' => $request->phone_number,
            "password" => bcrypt("123456789"),
        ]);
        $user = User::where('phone_number', $request->phone_number)->firstOrFail();

        $child->update([
            'user_id' => $user->id,
        ]);
        $person->update([
            'user_Id' => $user->id,
        ]);
        Primation::create([
            'user_id' => $user->id,
            'role_id' => 6,
        ]);

        event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل رقم الهاتف للمريض ( ' . $person->name . ' ) ', null,   null));
        alert()->toast('تم تعديل رقم الهاتف بنجاح', "success");

        return redirect()->route('doctor.patient.children.info', ['pid' => Crypt::encryptString($request->number)])->with('success', ' تم تعديل رقم الهاتف بنجاح ');
    }
}
