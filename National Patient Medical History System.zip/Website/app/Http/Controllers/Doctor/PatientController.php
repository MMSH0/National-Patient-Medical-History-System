<?php



namespace App\Http\Controllers\Doctor;

use App\Custom;
use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Doctor\AddpatientRequest;
use App\Models\Admin\Diagnose;
use App\Models\Admin\Primation;
use App\Models\Doctor\Patient;
use App\Models\Doctor\PatientChronicDisease;
use App\Models\Doctor\PatientDiagnose;
use App\Models\Doctor\PatientDiagnosis;
use App\Models\Doctor\PatientFamily;
use App\Models\Doctor\PatientSurgery;
use App\Models\Doctor\Person;
use App\Models\Doctor\Prescription;
use App\Models\Doctor\Visitation;
use App\Models\Lab\PatientTest;
use App\Models\Ray\PatientRay;
use App\Models\User;
use App\Rules\checkPhoneNumber;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;

class PatientController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    protected  $verification_code;

    public function Add()
    {
        return view('D.Add_patient');
    }


    public function notification($userId, $title, $message)
    {



        try {
            $fcmTokens = User::where('id', $userId)->whereNotNull('fcm_token')->pluck('fcm_token')->first();

            $url = 'https://fcm.googleapis.com/fcm/send';


            $serverKey = "AAAAbor-lLo:APA91bFnN-I3OUh7XCwa6JprxUlbGQnu_W8Gif7IJROdPaXXdQuHvheAT3IAGG_Ss7QBshdI7BP4ttWzP2yoJuRldzse_3-YBnmE_7EhUjHewsP-gdSDVLrtYNonRalWOYvf7OmRmd6N";

            $dataArr = [
                "click_action" => "FLUTTER_NOTIFICATION_CLICK",
                "status" => "done"
            ];


            $data = [
                "registration_ids" => [$fcmTokens],
                "notification" => [
                    "title" => str($title),
                    "body" => str($message),
                    "sound" => "default",
                ],
                "data" => $dataArr,
                "priority" => "high",
            ];

            $encodedData = json_encode($data);

            $headers = [
                "Authorization:key=" . $serverKey,
                "Content-Type: application/json"
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedData);
            $result = curl_exec($ch);
            // dd($result );
        } catch (\Exception $e) {
            // dd($e);
        }
    }


    public function Store(AddpatientRequest $request)
    {
        $user = User::where('phone_number', $request->input('phone'))->get()->first();

        if (isset($user)) {
            $name = $request->input('name') . '  ' . $request->input('last_name');


            if (Carbon::parse($request->input('birthday'))->age >= 18) {




                $userId = User::where('phone_number', $request->input('phone'))->first();

                Primation::create([
                    'user_id' => $userId->id,
                    'role_id' => 6,
                ]);

                Person::create([
                    'name' => $name,
                    'birthDate' => $request->input('birthday'),
                    'birthCity' => $request->input('birthCity'),
                    'address' => $request->input('address'),
                    'gender' => $request->input('gender'),
                    'user_Id' => $userId->id,
                ]);


                Patient::create([
                    'blood_type' => $request->input('blood_type'),
                    'hight' => $request->input('hight'),
                    'weight' => $request->input('weight'),
                    'user_id' => $userId->id,
                    'status' => $request->status,
                ]);

                $paitent = Patient::where('user_id', $userId->id)->firstOrFail();

                Visitation::create([
                    'doctor_id' => Auth::user()->doctor->id,
                    'patient_id' => $paitent->id,
                    'visiting_date' => Carbon::now(),
                    'access' => '1'
                ]);
                Alert::toast(' تم ان انشاء سجل طبي باسم  ' . $name . ' ', 'success');

                event(new OperationOccurred(' د/ ' . Auth::user()->person->name, 'تم ان انشاء سجل طبي جديد  ', null,  $name));

                return redirect()->route('doctor.patinet.index')->with('success', ' تم ان انشاء سجل طبي باسم  ' . $name . ' ');
            }
            Alert::error('لم يتم انشاء سجل طبي بسبب ان  ' . $name . '  عمره اقل من   18 سنة');

            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, 'لم يتم انشاء سجل طبي بسبب ان عمره اقل من   18 سنة ', null,   $name));
            return redirect()->route('doctor.patinet.index')->with('error', ' لم يتم انشاء سجل طبي بسبب ان  ' . $name . '  عمره اقل من   18 سنة');
        } else {

            if ($request->validated()) {

                $name = $request->input('name') . '  ' . $request->input('last_name');


                if (Carbon::parse($request->input('birthday'))->age >= 18) {

                    $validatedDate  = $this->validate($request, [
                        'phone' => ['required', new  checkPhoneNumber('users', 'phone_number')]
                    ]);

                    User::create([
                        'phone_number' => $request->input('phone'),
                        // 'phone_number' =>  $validatedDate,
                        'password' => Hash::make("123456789"), 'build_id' => 0,
                    ]);

                    $userId = User::where('phone_number', $request->input('phone'))->first();

                    Primation::create([
                        'user_id' => $userId->id,
                        'role_id' => 6,
                    ]);

                    Person::create([
                        'name' => $name,
                        'birthDate' => $request->input('birthday'),
                        'birthCity' => $request->input('birthCity'),
                        'address' => $request->input('address'),
                        'gender' => $request->input('gender'),
                        'user_Id' => $userId->id,
                    ]);


                    Patient::create([
                        'blood_type' => $request->input('blood_type'),
                        'hight' => $request->input('hight'),
                        'weight' => $request->input('weight'),
                        'user_id' => $userId->id,
                        'status' => $request->status,
                    ]);

                    $paitent = Patient::where('user_id', $userId->id)->firstOrFail();

                    Visitation::create([
                        'doctor_id' => Auth::user()->doctor->id,
                        'patient_id' => $paitent->id,
                        'visiting_date' => Carbon::now(),
                        'access' => '1'
                    ]);
                    Alert::toast(' تم ان انشاء سجل طبي باسم  ' . $name . ' ', 'success');

                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, 'تم ان انشاء سجل طبي جديد  ', null,  $name));

                    return redirect()->route('doctor.patinet.index')->with('success', ' تم ان انشاء سجل طبي باسم  ' . $name . ' ');
                }
                Alert::error('لم يتم انشاء سجل طبي بسبب ان  ' . $name . '  عمره اقل من   18 سنة');

                event(new OperationOccurred(' د/ ' . Auth::user()->person->name, 'لم يتم انشاء سجل طبي بسبب ان عمره اقل من   18 سنة ', null,   $name));
                return redirect()->route('doctor.patinet.index')->with('error', ' لم يتم انشاء سجل طبي بسبب ان  ' . $name . '  عمره اقل من   18 سنة');
            }
        }
    }
    public function Index()
    {
        $patients = Visitation::select('patient_id')
            ->where('doctor_id', Auth::user()->doctor->id)
            ->groupBy('patient_id')
            ->get();

        $index = 0;

        return view('D.Patient_list', compact('patients', 'index'));
    }

    public function Search()
    {
        $patients = Patient::all();
        $index = 0;
        return view('D.Search_patient', compact('patients', 'index'));
    }

    public function Searches(Request $request)
    {

        if ($request['numberPhone'] != null) {
            $users  =  User::join('people', 'users.id', '=', 'people.user_id')->join('patients', 'users.id', '=', 'patients.user_id')
                ->select('users.phone_number', 'people.name', 'people.birthDate', 'people.gender', 'people.prsonalImage AS img', 'people.indentityCardNumber', 'patients.id AS patientId')
                ->where('users.phone_number', $request['numberPhone'])->distinct()->get();
        } else if ($request['identityCard'] != null) {
            $all_patient  = User::join('people', 'users.id', '=', 'people.user_id')->join('patients', 'users.id', '=', 'patients.user_id')
                ->select('users.phone_number', 'people.name', 'people.birthDate', 'people.gender', 'people.prsonalImage AS img', 'people.indentityCardNumber', 'patients.id AS patientId')
                ->where('indentityCardNumber', $request->input('identityCard'))->distinct("users.phone_number")->get();
        } else if ($request['personalName'] != null) {
            $all_patient  = User::join('people', 'users.id', '=', 'people.user_id')->join('patients', 'users.id', '=', 'patients.user_id')
                ->select('users.phone_number', 'people.name', 'people.birthDate', 'people.gender', 'people.prsonalImage AS img', 'people.indentityCardNumber', 'patients.id AS patientId')
                ->where('name', 'like', "%" . $request->input('personalName') . "%")->distinct("users.phone_number")->get();
        }


        if (isset($users) && $users->count() > 0) {
            $index = 0;
            return view('D.Search_patient', compact('users', 'index'));
        } else if (isset($all_patient) && $all_patient->count() > 0) {
            $index = 0;
            return view('D.Search_patient', compact('all_patient', 'index'));
        } else if ($request['numberPhone'] == null && $request['identityCard'] == null && $request['personalName'] == null) {
            Alert::error(' يجب البحث بالاسم او رقم الهاتف او رقم الهوية');
            return  redirect()->route('doctor.patient.search')->with('error', ' يجب البحث بالاسم او رقم الهاتف او رقم الهوية');
        } else {
            Alert::error('لا يوجد اي سجل طبي');
            return  redirect()->route('doctor.patient.search')->with('error', 'لا يوجد اي سجل طبي');
        }
    }


    public function Verify(Request $request)
    {
        $patient = Patient::findOrFail($request->input('number'));

        $user = User::findOrFail($patient->user->id);

        if ($request['code'] == $user->verfication_code) {
            Visitation::create([
                'patient_id' => $request->input('number'),
                'doctor_id' => Auth::user()->doctor->id,
                'visiting_date' => Carbon::now(),
                'access' => '1'
            ]);
            return PatientController::Verfication(Crypt::encryptString($request->input('number')));
        } else {
            $patient = Patient::findOrFail($request->input('number'));
            $erorr = 'الكود غير صحيح';
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, 'لم يتم الوصول السجل الطبي الخاص بـ ( ' . $patient->user->person->name . ')  بسبب ان الكود غير صحيح ', null,   null));
            Alert::error($erorr);
            return view('D.verfecation_patient', ['id' => $request->input('number')], compact('erorr'));
        }
    }

    public function Verfication($id)
    {

        try {

            $id = Crypt::decryptString($id);

            $patient = Patient::findOrFail($id);
            $user = User::findOrFail($patient->user->id);
            $access = Visitation::where('patient_id', ($id))->where('doctor_id', Auth::user()->doctor->id)->whereDate('visiting_date', Carbon::now()->toDateString())->latest()->first();


            if (isset($access)) {
                if ($access->access == 1) {
                    PatientController::notification($patient->user->id, 'تم الوصول للسجل الطبي الخاص بك', ' الدكتور ' . Auth::user()->person->name . ' بتاريخ ' . Carbon::now());

                    return redirect()->action([PatientController::class, 'Show'], ['number' => Crypt::encryptString($id)])->withInput();
                } else {

                    $this->verification_code = rand(pow(10, 4 - 1), pow(10, 4) - 1);
                    $user->verfication_code = $this->verification_code;
                    $user->save();
                    PatientController::notification($patient->user->id, ' كود التحقق : ' . $this->verification_code, 'طلب الوصول الى السجل الطبي الخاص بك من قبل الدكتور  ' . Auth::user()->person->name . ' بتاريخ ' . Carbon::now());
                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, '   طلب الوصول الى السجل الطبي الخاص بـ  ( ' . $patient->user->person->name . ' ) ', null,   null));

                    return view('D.verfecation_patient', ['id' => $id]);
                }
            } else {

                $this->verification_code = rand(pow(10, 4 - 1), pow(10, 4) - 1);
                $user->verfication_code = $this->verification_code;
                $user->save();
                PatientController::notification($patient->user->id, ' كود التحقق : ' . $this->verification_code, 'طلب الوصول الى السجل الطبي الخاص بك من قبل الدكتور  ' . Auth::user()->person->name . ' بتاريخ ' . Carbon::now());

                event(new OperationOccurred(' د/ ' . Auth::user()->person->name, '   طلب الوصول الى السجل الطبي الخاص بـ  ( ' . $patient->user->person->name . ' ) ', null,   null));


                return view('D.verfecation_patient', ['id' => $id]);
            }
        } catch (DecryptException $e) {

            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطا ( ' . $e . ' ) عند الوصول السجل الطبي الخاص بـ  ( ' . $patient->user->person->name . ' ) ', null,   null));
            Alert::error(' حدث خطا ( ' . $e . ' ) عند الوصول السجل الطبي الخاص بـ  ( ' . $patient->user->person->name);
            return redirect()->route('doctor.patinet.index');
        }
    }
    public function Show($number)
    {
        $patient = Patient::where('id', Crypt::decryptString($number))->firstOrFail();
        $diagnoses = PatientDiagnose::where('patient_id', Crypt::decryptString($number))->count();
        $medicens = Prescription::where('patient_id', Crypt::decryptString($number))->count();
        $rays = PatientRay::where('patient_id', Crypt::decryptString($number))->count();
        $tests = PatientTest::where('patient_id', Crypt::decryptString($number))->count();
        $diseases = PatientChronicDisease::where('patient_id', Crypt::decryptString($number))->count();
        $children = PatientFamily::where('breadwinner_id', Crypt::decryptString($number))->whereHas('patientchild', function ($query) {
            $query->whereNull('user_id');
        })->count();
        $surgeries = PatientSurgery::where('Patient_id', Crypt::decryptString($number))->count();

        event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم الوصول السجل الطبي الخاص بـ  ( ' . $patient->user->person->name . ' ) ', null,   null));

        return view('D.patient_info', compact('patient', 'rays', 'medicens', 'tests', 'diagnoses', 'diseases', 'children', 'surgeries'));
    }
    public function UpdateStatus(Request $request)
    {

        $patient = Patient::findOrFail($request->input('number'));
        $patient->status = $request->input('status');


        event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل حالة الاجتماعية السجل الطبي الخاص بـ  ( ' . $patient->user->person->name . ' ) ', $patient->status,   $request->input('status') == 1 ? 'متزوج' : 'اعزب'));
        ALert::toast('تم تعديل حالة الاجتماعية', 'success');
        $patient->save();
        // return redirect()->route('doctor.patinet.index')->with('success', 'تم تعديل حالة الاجتماعية');
        return redirect()->action([PatientController::class, 'Show'], ['number' => Crypt::encryptString($request->input('number'))])->withInput();
    }

    public function UpdateHeightAndWeight(Request $request)
    {
        $patient = Patient::findOrFail($request->input('number'));
        if ($patient->hight != $request->input('hight')) {
            $patient->hight = $request->input('hight');
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل (الطول) السجل الطبي الخاص بـ  ( ' . $patient->user->person->name . ' ) ',  $patient->hight,  $request->input('hight')));
            PatientController::notification($patient->user->id, 'تم تعديل (الطول)', ' من قبل الدكتور ' . Auth::user()->person->name . '  من  ' . $patient->hight . ' الى ' . $request->input('hight') . ' وقت التعديل ' . Carbon::now() . ' ');
            ALert::toast('تم تعديل الطول ', 'success');
        }
        if ($patient->weight != $request->input('weight')) {
            $patient->weight = $request->input('weight');
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل (الوزن) السجل الطبي الخاص بـ  ( ' . $patient->user->person->name . ' ) ',  $patient->weight, $request->input('weight')));
            PatientController::notification($patient->user->id, 'تم تعديل (الوزن)', ' من قبل الدكتور ' . Auth::user()->person->name . '  من  ' . $patient->weight . ' الى ' . $request->input('weight') . ' وقت التعديل ' . Carbon::now() . ' ');

            ALert::toast('تم تعديل الوزن', 'success');
        }



        $patient->save();

        return redirect()->action([PatientController::class, 'Show'], ['number' => Crypt::encryptString($request->input('number'))])->withInput();
    }
    public function UpdateBloodType(Request $request)
    {
        $patient = Patient::findOrFail($request->input('number'));
        $patient->blood_type = $request->input('blood_type');
        event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل (فصيلة الدم) السجل الطبي الخاص بـ  ( ' . $patient->user->person->name . ' ) ',  $patient->blood_type, $request->input('blood_type')));
        PatientController::notification($patient->user->id, 'تم تعديل (فصيلة الدم)', ' من قبل الدكتور ' . Auth::user()->person->name . '  من  ' . $patient->blood_type . ' الى ' . $request->input('blood_type') . ' وقت التعديل ' . Carbon::now() . ' ');

        $patient->save();
        ALert::toast('تم تعديل فصيلة الدم', 'success');


        return redirect()->action([PatientController::class, 'Show'], ['number' => Crypt::encryptString($request->input('number'))])->withInput();
    }

    public function Report($id)
    {
        try {
            $id = Crypt::decryptString($id);
            $patient = PatientFamily::where('child_id', $id)->first();
            if (!isset($patient)) {
                $patient = Patient::findOrFail($id);
            }

            $patientDiagnoses = PatientDiagnosis::where('patient_id', $id)->get();
            $diagnoses = Diagnose::all();

            $rays = PatientRay::where('patient_id', $id)->get();


            $diseases = PatientChronicDisease::where('patient_id', $id)->get();




            $surgery = PatientSurgery::with('surgery', 'patient')->get()->where('patient_id', $id);



            $tests = PatientTest::where('patient_id', $id)->get();



            $prescriptions = Prescription::where('patient_id',  $id)->get();


            $pIndex = 0;
            $tIndex = 0;
            $sIndex = 0;
            $disIndex = 0;
            $dIndex = 0;
            $rIndex = 0;

            $pdf = Pdf::loadView('pdf/reports/fullReport', compact('patientDiagnoses', 'patient', 'pIndex','tIndex','sIndex' ,'disIndex','dIndex', 'rIndex', 'diagnoses', 'rays', 'diseases', 'tests', 'prescriptions', 'surgery', 'id'))->setPaper('a4', 'portrait')->download('report.pdf');
            return $pdf;
        } catch (DecryptException $e) {
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطأ في تعديل التشخيص   للمريض ( ' . isset($patient->user) ? $patient->user->person->name : $patient->person->name . ' ) ', $e, null));

            return redirect()->route('doctor.patinet.index');
        }
    }
}
