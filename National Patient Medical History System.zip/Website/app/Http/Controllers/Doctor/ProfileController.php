<?php

namespace App\Http\Controllers\Doctor;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Models\Admin\Hospital;
use App\Models\Admin\Person;
use App\Models\Doctor\Workinghour;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;

class ProfileController extends Controller
{
    public function FileUpload($request)
    {
        $imageName = Carbon::now()->format('YmdHis') . '.' . $request->getClientOriginalExtension();
        $request->move(public_path('images/Doctors/profiles/'),  $imageName);
        return $imageName;
    }

    public function Update(Request $request)
    {
        $user = User::where('id', $request['number'])->get()->firstOrFail();

        if (isset($user)) {
            $person = Person::where('user_Id', $user['id'])->get()->firstOrFail();
            if ($user->email != $request->input('email')) {
                event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل البريد الالكتروني الخاص بـ ( ' . $request->input('name') . ' ) ', $user->email,   $request->input('email')));

                $user->email = $request->input('email');
            }
            if ($user->phone_number != $request->input('phoneNumber')) {
                event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل رقم الهاتف الخاص بـ ( ' . $request->input('name') . ' ) ', $user->phone_number,   $request->input('phoneNumber')));

                $user->phone_number = $request->input('phoneNumber');
            }


            if ($person->name != $request->input('name')) {
                event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل اسم الدكتور ', $person->name,  $request->input('name')));

                $person->name = $request->input('name');
            }
            if ($person->birthDate != $request->input('birthDate')) {
                event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل تاريخ الميلاد الدكتور ( ' . $request->input('name') . ' ) ', $person->birthDate,  $request->input('birthDate')));

                $person->birthDate = $request->input('birthDate');
            }
            if ($person->birthCity != $request->input('birthCity')) {
                event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل مكان الميلاد الدكتور ( ' . $request->input('name') . ' ) ', $person->birthCity,  $request->input('birthCity')));

                $person->birthCity = $request->input('birthCity');
            }
            if ($person->address != $request->input('address')) {
                event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل عنوان السكن الدكتور ( ' . $request->input('name') . ' ) ', $person->address,  $request->input('address')));

                $person->address = $request->input('address');
            }

            $user->save();
            $person->save();
            Alert::toast(' تم تحديث بيانات حساب  ' . $request->input('name') . '  بنجاح  ','success');

            return redirect()->route('doctor.profile')->with('success', ' تم تحديث بيانات حساب  ' . $request->input('name') . '  بنجاح  ');
        }
        Alert::error(' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');
        return redirect()->route('doctor.profile')->with('error', ' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');
    }


    public function UpdatePassword(Request $request)
    {
        $user = User::where('id', $request['number'])->get()->firstOrFail();

        if (isset($user) && Hash::check($request->input('oldPassword'), $user->password)) {
            $user->update([
                'password' => bcrypt($request->input('newPassword')),
            ]);
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, 'تم تغيير كلمة السر ', null,  null));
            Alert::toast(  ' تم تغيير كلمة السر  ' . $request->input('name') . ' بنجاح ','success');

            return redirect()->route('doctor.profile')->with('success', ' تم تغيير كلمة السر  ' . $request->input('name') . ' بنجاح ');
        } else if ($request->input('newPassword') != $request->input('newPassword2')) {
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, 'لم يتم تغيير كلمة السر بسبب انها غير متطابقة  ', null,  null));
Alert::error(' كلمة السر  غير متطابقة  ');
            return redirect()->route('doctor.profile')->with('error', ' كلمة السر  غير متطابقة  ');
        } else {
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, 'حدث خطا اثناء تغيير كلمة السر', null,  null));
            Alert::error(' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');

            return redirect()->route('doctor.profile')->with('error', ' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');
        }
    }

    public function UploadImage(Request $request)
    {
        $user = User::where('id', $request['number'])->get()->firstOrFail();
        if (isset($user) && isset($request['image'])) {
            Person::where('user_Id', $user['id'])->update([
                'prsonalImage' => ProfileController::FileUpload($request['image'])
            ]);
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تحديث الصورة الشخصية ', null,  null));
            Alert::toast(' تم تحديث الصورة الشخصية ','success');

            return redirect()->route('doctor.profile')->with('success', ' تم تحديث الصورة الشخصية ');
        }
        event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطا اثناء تحديث الصورة الشخصية ', null,  null));
        Alert::error(' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');

        return redirect()->route('doctor.profile')->with('error', ' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');
    }

    public function UpdateTime(Request $request)
    {
        $daysOfWeek = ['السبت', 'الاحد', 'الاثنين', 'الثلاثاء', 'الاربعاء', 'الخميس'];



        if (isset($request['hospital'])) {
            $locationId =  $request['hospital'];
            $locationType =  'hospital_id';
            $hospital = Hospital::findOrFail($request['hospital']);
            foreach ($daysOfWeek as $day) {
                $startTimeKey = 'startTime' . $day;
                $endTimeKey = 'endTime' . $day;

                if ($request[$startTimeKey] !== null && $request[$endTimeKey] !== null) {
                    Workinghour::updateOrCreate(
                        [
                            'working_day' => $day,
                            'doctor_id' => Auth::user()->doctor->id,
                            $locationType => $locationId,
                        ],
                        [
                            'start_time' => $request[$startTimeKey],
                            'end_time' => $request[$endTimeKey],
                        ]
                    );
                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل موعد الدوام يوم ( ' . $day . ' )  من الساعة ( ' . $request[$startTimeKey] . ' ) الى الساعة ( ' . $request[$endTimeKey] . ' ) الخاص بـالمستشفى ( ' . $hospital->name . ' ) ', null,  null));
                }
            }
        }

        if (isset($request['clinc'])) {
            $locationId = $request['clinc'];
            $locationType = 'clinic_id';
            $hospital = Hospital::findOrFail($request['clinc']);

            foreach ($daysOfWeek as $day) {
                $startTimeKey = 'startTime' . $day;
                $endTimeKey = 'endTime' . $day;

                if ($request[$startTimeKey] !== null && $request[$endTimeKey] !== null) {
                    Workinghour::updateOrCreate(
                        [
                            'working_day' => $day,
                            'doctor_id' => Auth::user()->doctor->id,
                            $locationType => $locationId,
                        ],
                        [
                            'start_time' => $request[$startTimeKey],
                            'end_time' => $request[$endTimeKey],
                        ]
                    );
                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل موعد الدوام يوم ( ' . $day . ' )  من الساعة ( ' . $request[$startTimeKey] . ' ) الى الساعة ( ' . $request[$endTimeKey] . ' ) الخاص بـالعيادة ( ' . $hospital->name . ' ) ', null,  null));
                }
            }
        }
        Alert::toast("تم تحديث مواعيد الدوام  ",'success');

        return redirect()->route('doctor.profile')->with('success', "تم تحديث مواعيد الدوام  ");
    }
}
