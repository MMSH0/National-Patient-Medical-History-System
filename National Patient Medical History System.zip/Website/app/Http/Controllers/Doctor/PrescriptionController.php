<?php

namespace App\Http\Controllers\Doctor;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Doctor\PatientPrescriptionRequest;
use App\Models\Admin\Medicen;
use App\Models\Doctor\Patient;
use App\Models\Doctor\PatientFamily;
use App\Models\Doctor\Prescription;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use RealRashid\SweetAlert\Facades\Alert;

class PrescriptionController extends Controller
{
    public function notification( $userId, $title,$message)
    {



        try {
            $fcmTokens = User::where('id', $userId)->whereNotNull('fcm_token')->pluck('fcm_token')->first();

            $url = 'https://fcm.googleapis.com/fcm/send';


              $serverKey ="AAAAbor-lLo:APA91bFnN-I3OUh7XCwa6JprxUlbGQnu_W8Gif7IJROdPaXXdQuHvheAT3IAGG_Ss7QBshdI7BP4ttWzP2yoJuRldzse_3-YBnmE_7EhUjHewsP-gdSDVLrtYNonRalWOYvf7OmRmd6N";

            $dataArr = [
                "click_action" => "FLUTTER_NOTIFICATION_CLICK",
                "status" => "done"
            ];


            $data = [
                "registration_ids" => [$fcmTokens],
                "notification" => [
                    "title" => str($title),
                    "body" => str($message),
                    "sound" => "default",
                ],
                "data" => $dataArr,
                "priority" => "high",
            ];

            $encodedData = json_encode($data);

            $headers = [
                "Authorization:key=" . $serverKey,
                "Content-Type: application/json"
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedData);
            $result = curl_exec($ch);


        } catch (\Exception $e) {
            dd($e);
        }
    }

    public function Store(PatientPrescriptionRequest $request)
    {
        if ($request->validated()) {
        $patient=Patient::findOrFail(Crypt::decryptString($request->input('patient_id')));
        foreach ($request['selectedMed'] as $med) {
            $meds=Medicen::findOrFail( $med);
            if(isset( $patient->user)){
            PrescriptionController::notification($patient->user->id,'  تم اضافة العلاج   : '.$meds->name,' من قبل الدكتور  '.Auth::user()->person->name.' بتاريخ '.Carbon::now());
        }else{
            $barrwinner= Patient::findOrFail( $patient->family[0]->breadwinner_id);


            PrescriptionController::notification($barrwinner->user->id,'  تم اضافة العلاج   : '.$meds->name,' من قبل الدكتور  '.Auth::user()->person->name.' بتاريخ '.Carbon::now());
        }
        // dd($request->input('notes'));
            Prescription::create([
                'doctor_id' => Auth::user()->doctor->id,
                'patient_id' => Crypt::decryptString($request->input('patient_id')),
                'medicen_id' => $med,
                'how_many_times' => $request->input('how_many_times'),
                'usage_times' => $request->input('usage_times'),
                'note' => $request->input('notes')

            ]);
            if(isset( $patient->user)){
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, 'تم اضافة علاج للمريض  ( ' . $patient->user->person->name.' ) ', null,    $meds->name));
        }else{
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, 'تم اضافة علاج للمريض  ( ' . $patient->family[0]->person->name.' ) ', null,    $meds->name));


        }
        }

        Alert::toast(   'تمت اضافه  العلاج  بنجاح   ','success');

        return redirect()->route('doctor.patient.medicen', ['id' => $request['patient_id']])->with('success', 'تمت اضافه  العلاج  بنجاح   ');
    }
    }


    public function Index($id)
    {
        try {
            $id = Crypt::decryptString($id);
            $types = Medicen::all();
            $prescriptions = Prescription::where('patient_id',  $id)->get();

            $index = 0;
            return view('D.medicen', compact('index', 'prescriptions', 'types', 'id'));
        }catch (DecryptException $e) {

            return redirect()->route('doctor.patinet.index');
        }
    }
    public function Update(Request $request)
    {
        foreach ($request['selectedMed'] as $med) {
           $presc= Prescription::findOrFail($request['number']);
           $meds=Medicen::findOrFail( $med);

            PrescriptionController::notification($presc->patient->user->id,'  تم تعديل العلاج   : '.$meds->name,' من قبل الدكتور  '.Auth::user()->person->name.' بتاريخ '.Carbon::now());

            Prescription::where('doctor_id', Auth::user()->doctor->id)->where('id', $request['number'])->update([
                'doctor_id' => Auth::user()->doctor->id,
                'medicen_id' => $med,
                'how_many_times' => $request->input('how_many_times'),
                'usage_times' => $request->input('usage_times'),
                'note' => $request->input('note')
            ]);

        }


        Alert::toast(  '   تم تعديل بيانات  العلاج  بنجاح    ','success');

        return redirect()->route('doctor.patient.medicen', ['id' => $request['patient_id']])->with('success', '   تم تعديل بيانات  العلاج  بنجاح    ');
    }

    public function Report($id)
    {


        try {
            $id = Crypt::decryptString($id);
            $patient = PatientFamily::where('child_id', $id)->first();
            if (!isset($patient)) {
                $patient = Patient::findOrFail($id);
            }

            $prescriptions = Prescription::where('patient_id',  $id)->get();


            $index = 0;
            // dd($patient);
            // return view('pdf.reports.tests', compact('patient','tests','index'));

            $pdf = Pdf::loadView('pdf/reports/medicens', compact('patient','index', 'prescriptions',  'id'))->setPaper('a4', 'landscape')->download('report.pdf');
            return $pdf;
        }catch (DecryptException $e) {

            return redirect()->route('doctor.patinet.index');
        }
    }
}
