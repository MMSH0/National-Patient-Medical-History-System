<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Models\Admin\Hospital;
use App\Models\Doctor\Appointement;
use App\Models\Doctor\Patient;
use App\Models\Doctor\Visitation;
use App\Models\Doctor\Workinghour;
use Illuminate\Support\Facades\Auth;

class IndexController extends Controller
{
    public function Index()
    {
        $patients = Visitation::where('doctor_id',Auth::user()->doctor->id)->distinct('patient_id')->count();

        // dd($patients);
        $appointments = Appointement::where('doctor_id',Auth::user()->doctor->id)->count();
        return view('D.Index', compact('patients', 'appointments'));
    }
    public function profile()
    {
        $hospitalWorkingHours = Workinghour::where('doctor_id', Auth::user()->doctor->id)
        ->whereNot('hospital_id',0)
        ->get();

        $clinicWorkingHours = Workinghour::where('doctor_id', Auth::user()->doctor->id)
        ->whereNot('clinic_id',0)
        ->get();

        $daysOfWeek = ['السبت', 'الاحد', 'الاثنين', 'الثلاثاء', 'الاربعاء', 'الخميس'];

        $hospitals = Workinghour::selectRaw('MAX(id) as id, MAX(doctor_id) as doctor_id, hospital_id')
        ->where('doctor_id', Auth::user()->doctor->id)
        ->where('hospital_id', '!=', 0)
        ->groupBy('hospital_id')
        ->get();


        $clincs = Workinghour::selectRaw('MAX(id) as id, MAX(doctor_id) as doctor_id, clinic_id')
        ->where('doctor_id', Auth::user()->doctor->id)
        ->where('clinic_id', '!=', 0)
        ->groupBy('clinic_id')
        ->get();

        return view('D.Profile', compact('hospitals', 'clincs','hospitalWorkingHours','clinicWorkingHours','daysOfWeek'));
    }


}
