<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;


class PatientsController extends Controller
{




    public function Add(){
        return view('D.add_patients');

    }


    public function Show(){
        return view('D.all-tests');

    }


}
