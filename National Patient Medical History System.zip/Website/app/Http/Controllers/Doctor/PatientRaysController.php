<?php

namespace App\Http\Controllers\Doctor;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Doctor\PatientRayRequest;
use App\Models\Admin\Doctor;
use App\Models\Doctor\Patient;
use App\Models\Admin\Radiology;
use App\Models\Doctor\PatientFamily;
use App\Models\Doctor\PatientRay;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;

class PatientRaysController extends Controller
{

    public function notification($userId, $title, $message)
    {



        try {
            $fcmTokens = User::where('id', $userId)->whereNotNull('fcm_token')->pluck('fcm_token')->first();

            $url = 'https://fcm.googleapis.com/fcm/send';


              $serverKey ="AAAAbor-lLo:APA91bFnN-I3OUh7XCwa6JprxUlbGQnu_W8Gif7IJROdPaXXdQuHvheAT3IAGG_Ss7QBshdI7BP4ttWzP2yoJuRldzse_3-YBnmE_7EhUjHewsP-gdSDVLrtYNonRalWOYvf7OmRmd6N";

            $dataArr = [
                "click_action" => "FLUTTER_NOTIFICATION_CLICK",
                "status" => "done"
            ];


            $data = [
                "registration_ids" => [$fcmTokens],
                "notification" => [
                    "title" => str($title),
                    "body" => str($message),
                    "sound" => "default",
                ],
                "data" => $dataArr,
                "priority" => "high",
            ];

            $encodedData = json_encode($data);

            $headers = [
                "Authorization:key=" . $serverKey,
                "Content-Type: application/json"
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedData);
            $result = curl_exec($ch);
        } catch (\Exception $e) {
            dd($e);
        }
    }

    public function Index($id)
    {
        try {
            $id = Crypt::decryptString($id);
            $rays = PatientRay::where('patient_id', $id)->get();
            $index = 0;
            return view("D.Ray", compact('id', 'rays', 'index'));
        }catch (DecryptException $e) {

            return redirect()->route('doctor.patinet.index');
        }
    }

    public function Add($id)
    {
        try {
            $id = Crypt::decryptString($id);

            return view("D.Add_ray", compact('id'));
        }catch (DecryptException $e) {

            return redirect()->route('doctor.patinet.index');
        }
    }

    public function Store(PatientRayRequest $request)
    {
        if ($request->validated()) {
            $doctor_id = Doctor::where('id', $request['Doctor_Id'])->first();
            $patient_id = Patient::where('id', $request['Patient_Id'])->first();
            $index = 0;
            foreach ($request['rayName'] as $name) {
                $ray = Radiology::findOrFail($name);
                PatientRaysController::notification($patient_id->user->id, '  تم اضافة الاشعة   : ' . $ray->name, ' من قبل الدكتور  ' . Auth::user()->person->name . ' بتاريخ ' . Carbon::now());

                PatientRay::create([
                    'doctor_id' => $doctor_id->id,
                    'patient_id' => $patient_id->id,
                    'ray_id' => $name,
                    'note' => $request['result'][$index],
                ]);
                event(new OperationOccurred(' د/ ' . Auth::user()->person->name, 'تم اضافة الاشعة للمريض  ( ' . $patient_id->user->person->name . ' ) ', null,    $ray->name));
                ++$index;
            }

            return redirect()->route('doctor.patient.ray', ['id' => Crypt::encryptString($request['Patient_Id'])])->with('success', 'تم اضافة الاشعة بنجاح ');
        }
    }
    public function Rays()
    {

        $posts = Radiology::all();

        return response()->json($posts);
    }

    public function Show()
    {
        $patientRays = PatientRay::all();
        $index = 0;
        return view('D.add_ray', compact('patientRays', 'index'));
    }

    public function Report($id)
    {


        try {
            $id = Crypt::decryptString($id);
            $patient = PatientFamily::where('child_id', $id)->first();


            if (!isset($patient)) {
                $patient = Patient::findOrFail($id);
            }




            $rays = PatientRay::where('patient_id', $id)->get();
            $index = 0;
            // dd($patient);
            // return view('pdf.reports.tests', compact('patient','tests','index'));

            $pdf = Pdf::loadView('pdf/reports/rays', compact('patient', 'index', 'rays',  'id'))->setPaper('a4', 'landscape')->download('report.pdf');
            return $pdf;
        }catch (DecryptException $e) {

            return redirect()->route('doctor.patinet.index');
        }
    }
}
