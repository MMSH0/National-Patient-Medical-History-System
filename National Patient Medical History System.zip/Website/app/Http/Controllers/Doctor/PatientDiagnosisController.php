<?php

namespace App\Http\Controllers\Doctor;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Doctor\PatientDiagnosisRequest;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Admin\Diagnose;
use App\Models\Admin\Doctor;
use App\Models\Admin\Person;
use App\Models\Doctor\Patient;
use App\Models\Doctor\PatientDiagnosis;
use App\Models\Doctor\PatientFamily;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use RealRashid\SweetAlert\Facades\Alert;

class PatientDiagnosisController extends Controller
{


    public function notification($userId, $title, $message)
    {



        try {
            $fcmTokens = User::where('id', $userId)->whereNotNull('fcm_token')->pluck('fcm_token')->first();

            $url = 'https://fcm.googleapis.com/fcm/send';


              $serverKey ="AAAAbor-lLo:APA91bFnN-I3OUh7XCwa6JprxUlbGQnu_W8Gif7IJROdPaXXdQuHvheAT3IAGG_Ss7QBshdI7BP4ttWzP2yoJuRldzse_3-YBnmE_7EhUjHewsP-gdSDVLrtYNonRalWOYvf7OmRmd6N";

            $dataArr = [
                "click_action" => "FLUTTER_NOTIFICATION_CLICK",
                "status" => "done"
            ];


            $data = [
                "registration_ids" => [$fcmTokens],
                "notification" => [
                    "title" => str($title),
                    "body" => str($message),
                    "sound" => "default",
                ],
                "data" => $dataArr,
                "priority" => "high",
            ];

            $encodedData = json_encode($data);

            $headers = [
                "Authorization:key=" . $serverKey,
                "Content-Type: application/json"
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedData);
            $result = curl_exec($ch);
        } catch (\Exception $e) {
            dd($e);
        }
    }

    public function Index()
    {
        return view('D.patient_diagnosi');
    }



    public function Store(PatientDiagnosisRequest $request)
    {
        if ($request->validated()) {
            try {
                $id = Crypt::decryptString($request['number']);
                $patient = Patient::findOrFail($id);
                foreach ($request->input('diagnosis') as $diag) {
                    $daigs = Diagnose::findOrFail($diag);

                    if (isset($patient->user)) {
                        PatientDiagnosisController::notification($patient->user->id, '  تم اضافة التشخيص   : ' . $daigs->name, ' من قبل الدكتور  ' . Auth::user()->person->name . ' بتاريخ ' . Carbon::now());
                    } else {

                        $barrwinner = Patient::findOrFail($patient->family[0]->breadwinner_id);

                        PatientDiagnosisController::notification($barrwinner->user->id, '  تم اضافة التشخيص   : ' . $daigs->name, ' من قبل الدكتور  ' . Auth::user()->person->name . ' بتاريخ ' . Carbon::now());
                    }
                    PatientDiagnosis::create([
                        'doctor_id' => $request['Doctor_Id'],
                        'patient_id' =>    $id,
                        'diagnosis_id' => $diag,
                        'diagnosis_date' => Carbon::now(),
                        'notes' => $request->input('notes'),
                    ]);

                    if (isset($patient->user)) {
                        event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم اضافة التشخيص ( ' . $daigs->name . ' ) للمريض ( ' . $patient->user->person->name . ' )', null,   $request->input('notes')));
                    } else {
                        // dd();

                        event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم اضافة التشخيص ( ' . $daigs->name . ' ) للمريض ( ' . $patient->family[0]->person->name . ' )', null,   $request->input('notes')));
                    }
                }
                Alert::toast( '   تم اضافة التشخيص بنجاح    ','success');

                return redirect()->route('doctor.patient.diagnose', ['id' => Crypt::encryptString($id)])->with('success', '   تم اضافة التشخيص بنجاح    ');
            }catch (DecryptException $e) {
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطأ في تعديل التشخيص   للمريض ( ' . $patient->user->person->name . ' ) ', $e, null));

                return redirect()->route('doctor.patinet.index');
            }
        }
    }

    public function Show($id)
    {
        try {
            $id = Crypt::decryptString($id);
            $patientDiagnoses = PatientDiagnosis::where('patient_id', $id)->get();
            $diagnoses = Diagnose::all();
            $index = 0;
            return view('D.patient_diagnosi', compact('patientDiagnoses', 'index', 'diagnoses', 'id'));
        }catch (DecryptException $e) {

            return redirect()->route('doctor.patinet.index');
        }
    }

    public function Update(Request $request)
    {
        try {


            $id = Crypt::decryptString($request['number']);

            foreach ($request->input('diagnosis') as $diag) {
                $daigs = PatientDiagnosis::where('doctor_id', $request['SId'])->where('id', $request['id'])->firstOrFail();
                $newPatient = Patient::findOrFail($id);
                if ($daigs->doctor_id != $request['Doctor_Id']) {
                    $oldDoctor = Doctor::findOrFail($daigs->doctor_id);
                    $newDoctor = Doctor::findOrFail($request['Doctor_Id']);
                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل التشخيص ( ' . $daigs->name . ' ) للمريض ( ' . $newPatient->user->person->name . ' )',  $oldDoctor->user->person->name,  $newDoctor->user->person->name));

                    $daigs->doctor_id = $request['Doctor_Id'];
                }
                if ($daigs->patient_id != $id) {
                    $oldPatient = Patient::findOrFail($daigs->patient_id);

                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل التشخيص ( ' . $daigs->name . ' ) للمريض ( ' . $newPatient->user->person->name . ' )', $oldPatient->user->person->name,  $newPatient->user->person->name));

                    $daigs->patient_id = $id;
                }
                if ($daigs->diagnosis_id !=  $diag) {
                    $oldDaigs = Diagnose::findOrFail($daigs->diagnosis_id);
                    $newDaigs = Diagnose::findOrFail($diag);
                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل التشخيص ( ' . $daigs->name . ' ) للمريض ( ' . $newPatient->user->person->name . ' )', $oldDaigs->name,  $newDaigs->name));


                    $daigs->diagnosis_id =  $diag;
                }

                if ($daigs->notes != $request->input('notes')) {
                    event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' تم تعديل ملاحظات التشخيص ( ' . $daigs->name . ' ) للمريض ( ' . $newPatient->user->person->name . ' )', $daigs->notes, $request->input('notes')));

                    $daigs->notes = $request->input('notes');
                }
                PatientDiagnosisController::notification($newPatient->user->id, '  تم تعجيل التشخيص   : ' . $daigs->name, '  من قبل الدكتور  ' . Auth::user()->person->name . ' بتاريخ ' . Carbon::now());

                $daigs->diagnosis_date =  Carbon::now();

                $daigs->save();
            }

            Alert::toast(  '   تم تعديل التشخيص  بنجاح    ','success');

            return redirect()->route('doctor.patient.diagnose', ['id' => Crypt::encryptString($id)])->with('success', '   تم تعديل التشخيص  بنجاح    ');;
        }catch (DecryptException $e) {

            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطأ في تعديل التشخيص   للمريض ( ' . $newPatient->user->person->name . ' ) ', $e, null));
            return redirect()->route('doctor.patinet.index');
        }
    }

    public function Report($id)
    {


        try {
            $id = Crypt::decryptString($id);
            $patient = PatientFamily::where('child_id', $id)->first();
            if (!isset($patient)) {
                $patient = Patient::findOrFail($id);
            }

            $patientDiagnoses = PatientDiagnosis::where('patient_id', $id)->get();
            $diagnoses = Diagnose::all();
            $index = 0;
            // dd($patient);
            // return view('pdf.reports.daignosis',  compact('patientDiagnoses', 'patient', 'index', 'diagnoses', 'id'));

            $pdf = Pdf::loadView('pdf/reports/daignosis', compact('patientDiagnoses', 'patient', 'index', 'diagnoses', 'id'))->setPaper('a4', 'portrait')->download('report.pdf');
            return $pdf;
        }catch (DecryptException $e) {
            event(new OperationOccurred(' د/ ' . Auth::user()->person->name, ' حدث خطأ في تعديل التشخيص   للمريض ( ' . isset($patient->user)? $patient->user->person->name:$patient->person->name . ' ) ', $e, null));

            return redirect()->route('doctor.patinet.index');
        }
    }
}
