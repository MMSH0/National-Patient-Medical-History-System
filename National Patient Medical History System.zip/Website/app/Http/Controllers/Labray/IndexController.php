<?php

namespace App\Http\Controllers\Labray;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Models\Admin\Person;
use App\Models\Admin\Test;
use App\Models\Doctor\Patient;
use App\Models\Lab\PatientTest;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;

class IndexController extends Controller
{

    public function notification($userId, $title, $message)
    {



        try {
            $fcmTokens = User::where('id', $userId)->whereNotNull('fcm_token')->pluck('fcm_token')->first();

            $url = 'https://fcm.googleapis.com/fcm/send';


              $serverKey ="AAAAbor-lLo:APA91bFnN-I3OUh7XCwa6JprxUlbGQnu_W8Gif7IJROdPaXXdQuHvheAT3IAGG_Ss7QBshdI7BP4ttWzP2yoJuRldzse_3-YBnmE_7EhUjHewsP-gdSDVLrtYNonRalWOYvf7OmRmd6N";

            $dataArr = [
                "click_action" => "FLUTTER_NOTIFICATION_CLICK",
                "status" => "done"
            ];


            $data = [
                "registration_ids" => [$fcmTokens],
                "notification" => [
                    "title" => str($title),
                    "body" => str($message),
                    "sound" => "default",
                ],
                "data" => $dataArr,
                "priority" => "high",
            ];

            $encodedData = json_encode($data);

            $headers = [
                "Authorization:key=" . $serverKey,
                "Content-Type: application/json"
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedData);
            $result = curl_exec($ch);
        } catch (\Exception $e) {
            dd($e);
        }
    }


    public function Index()
    {
        $index = 0;
        $all_test = PatientTest::join('patients', 'patient_tests.patient_id', '=', 'patients.id')
            ->join('users', 'patients.user_id', '=', 'users.id')
            ->join('people', 'people.user_id', '=', 'users.id')
            ->where('patient_tests.lab_id', Auth::user()->building->id)
            ->whereNotNull('patient_tests.RESULT')
            ->select('people.name as Name', 'patients.user_id', 'patient_tests.patient_id', DB::raw('MAX(patient_tests.id) as id'))
            ->groupBy('Name', 'patients.user_id', 'patients.user_id', 'patient_tests.patient_id')
            ->get();


        return view('LR.index', compact('all_test', 'index'));
    }

    public function Add()
    {
        return view('LR.Add_test');
    }

    public function Tests($number)
    {
        $posts = Test::join('patient_tests', 'tests.id', '=', 'patient_tests.test_id')
            ->select('tests.name', 'patient_tests.*')
            ->where('patient_id', $number)
            ->where('result', Null)->get();

        return response()->json($posts);
    }

    public function Profile()
    {
        return view('LR.profile');
    }


    public function Store(Request $request)
    {


        if ($request->input('testName')[0] != Null || $request->input('result')[0] != Null) {
            $index = 0;
            $patient = Patient::findOrFail($request['number']);

            foreach ($request['result'] as $result) {
                $test = Test::findOrFail($request['testName'][$index]);
                IndexController::notification($patient->user->id, '  تم اضافة نتائج الفحص   : ' . $test->name, ' من قبل المختبر  ' . Auth::user()->building->name . ' بتاريخ ' . Carbon::now());

                PatientTest::where('patient_id', $request['number'])->where('test_id', $request['testName'][$index])->update([
                    'result' => $result,
                    'lab_id' => Auth::user()->building->id,
                    'test_date' => Carbon::now()->format('Y-m-d'),
                    'test_time' => Carbon::now()->format('H:i:s'),
                ]);

                event(new OperationOccurred(Auth::user()->building->name, 'تم اضافة   نتائج  فحص (' . $test->name . ') للمريض  (' . $patient->name . ')', null, $result));

                $index++;
            }
            Alert::toast('تمت اضافة نتائج فحصوات المريض   ' . $request->input('name') . '  بنجاح  ', 'success');

            return redirect()->route('labray.test.add')->with('success', 'تمت اضافة نتائج فحصوات المريض   ' . $request->input('name') . '  بنجاح  ');
        } else {
            ALert::error(' تاكد من تعبئة نتائج فحصوات المريض بشكل صحيح ');
            return redirect()->route('labray.test.add')->with('error', ' تاكد من تعبئة نتائج فحصوات المريض بشكل صحيح ');
        }
    }


    public function Search(Request $request)
    {

        if ($request['numberPhone'] != null) {
            $users  =  User::where('phone_number', $request['numberPhone'])->get();
        } else if ($request['identityCard'] != null) {
            $all_patient  = User::join('people', 'users.id', '=', 'people.user_id')->join('patients', 'users.id', '=', 'patients.user_id')
                ->select('users.phone_number', 'people.name', 'people.birthDate', 'people.gender', 'people.prsonalImage AS img', 'people.indentityCardNumber', 'patients.id AS patientId')
                ->where('indentityCardNumber', $request->input('identityCard'))->get();
        } else if ($request['personalName'] != null) {
            $all_patient  = User::join('people', 'users.id', '=', 'people.user_id')->join('patients', 'users.id', '=', 'patients.user_id')
                ->select('users.phone_number', 'people.name', 'people.birthDate', 'people.gender', 'people.prsonalImage AS img', 'people.indentityCardNumber', 'patients.id AS patientId')
                ->where('name', 'like', "%" . $request->input('personalName') . "%")->get();
        }


        if (isset($users) && $users->count() > 0) {
            $index = 0;
            return view('LR.Add_test', compact('users', 'index'));
        } else if (isset($all_patient) && $all_patient->count() > 0) {
            $index = 0;
            return view('LR.Add_test', compact('all_patient', 'index'));
        } else if ($request['numberPhone'] == null && $request['identityCard'] == null && $request['personalName'] == null) {
            ALert::error(' يجب البحث بالاسم او رقم الهاتف او رقم الهوية');
            return  redirect()->route('labray.test.add')->with('error', ' يجب البحث بالاسم او رقم الهاتف او رقم الهوية');
        } else {
            ALert::error('لا يوجد اي سجل طبي');

            return  redirect()->route('labray.test.add')->with('error', 'لا يوجد اي سجل طبي');
        }
    }


    public function Show($patient)
    {
        $tests = PatientTest::where('lab_id', Auth::user()->building->id)
            ->where('patient_id', $patient)
            ->whereNotNull('RESULT')
            ->get();
        $date =  PatientTest::select('test_date')->where('patient_id', $patient)->where('lab_id', Auth::user()->building->id)->whereNotNull('RESULT')->distinct()->get();



        $index = 0;
        return view('LR.tests', compact('tests', 'date', 'index'));
    }

    public function UpdatePassword(Request $request)
    {
        $user = User::where('id', $request->input('number'))->firstOrFail();

        if (isset($user) && Hash::check($request->input('oldPassword'), $user->password)) {
            $user->update([
                'password' => bcrypt($request->input('newPassword')),
            ]);
            event(new OperationOccurred(Auth::user()->building->name, 'تم تحديث  كلمة السر  الخاص بالمستخدم (' . $request->input('name') . ')', null, null));
            ALert::toast(' تم تغيير كلمة السر  ' . $request->input('name') . ' بنجاح ', 'success');
            return redirect()->route('lab.profile')->with('success', ' تم تغيير كلمة السر  ' . $request->input('name') . ' بنجاح ');
        } else if ($request->input('newPassword') != $request->input('newPassword2')) {
            event(new OperationOccurred(Auth::user()->building->name, ' حدث خطاء عند تحديث  كلمة السر  الخاص بالمستخدم بسبب ان كلمة السر غير متطابقة (' .  $user->person->name . ')', null, null));
            Alert::error(' كلمة السر  غير متطابقة  ');
            return redirect()->route('lab.profile')->with('error', ' كلمة السر  غير متطابقة  ');
        } else {
            Alert::error(' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');

            return redirect()->route('lab.profile')->with('error', ' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');
        }
    }
}
