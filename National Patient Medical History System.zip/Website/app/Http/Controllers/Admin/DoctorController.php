<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\DoctorRequest;
use App\Models\Admin\Building;
use App\Models\Admin\Doctor;
use App\Models\Admin\Hospital;
use App\Models\Admin\Person;
use App\Models\Admin\Primation;
use App\Models\Admin\Specialty;
use App\Models\Admin\Resume;
use App\Models\Doctor\Workinghour;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;

class DoctorController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }



    public function FileUpload($request, $path)
    {
        $imageName = Carbon::now()->format('YmdHis') . '.' . $request->getClientOriginalExtension();
        $request->move(public_path('images/Doctors/' . $path . '/'),  $imageName);
        return $imageName;
    }

    public function UploadPDF($img_1, $img_2, $title)
    {

        $img_1->move(public_path('images/Doctors/IDs/'),  '1.' . $img_1->getClientOriginalExtension());
        $img_2->move(public_path('images/Doctors/IDs/'),  '2.' . $img_1->getClientOriginalExtension());

        $image1 = public_path('images/Doctors/IDs/') . '1.' . $img_1->getClientOriginalExtension();
        $image2 = public_path('images/Doctors/IDs/') . '2.' . $img_1->getClientOriginalExtension();


        $name = Carbon::now()->format('YmdHis') . '.pdf';
        $pdf = Pdf::loadView('pdf/image', compact('image1', 'image2', 'title'))->setPaper('a4', 'landscape')->save('files/Doctors/ID/' .  $name);
        $pdf->setOption('enable-local-file-access', true);
        unlink($image1);
        unlink($image2);
        return $name;
    }





    public function Add()
    {
        $all_specialty = Specialty::all();
        $all_hospital = Hospital::all();
        $all_clinc =  Building::where('building_type', 'عيادة')->get();
        return view('A.Add_doctor', compact('all_specialty', 'all_hospital', 'all_clinc'));
    }

    public function Store(DoctorRequest $request)
    {


        if ($request->validated() && (isset($request['clincs']) || isset($request['hospitals']))) {

            $name = $request->input('first_name') . ' ' . $request->input('last_name');

            User::create([

                'phone_number' => $request->input('phone'), 'email' => $request->input('email'), 'password' => Hash::make("123456789"), 'building_id' => 1, 'role_id' => 1

            ]);

            $userId = User::where('email', $request->input('email'))->first();

            Doctor::create([
                'user_id' => $userId->id,
                'degree' => $request->input('degree'), 'experience' => DoctorController::FileUpload($request["exprience"], 'CVs'),
            ]);

            Primation::create([
                'user_id' => $userId->id,
                'role_id' => 3
            ]);

            $doctorId = Doctor::where('user_id', $userId->id)->first();

            Resume::create([
                'specialty_id' => $request->input('specialty_1'),
                'doctor_id' => $doctorId->id
            ]);

            if ($request->input('specialty_2') != 0) {
                Resume::create([
                    'specialty_id' => $request->input('specialty_2'),
                    'doctor_id' => $doctorId->id
                ]);
            }


            Person::create([
                'name' => $name,
                'birthDate' => $request->input("birthday"),
                'gender' => $request->input("geneder"),
                'birthCity' => $request->input("city"),
                'indentityCardNumber' => $request->input("identity_card"),
                'prsonalImage' => DoctorController::FileUpload($request["image"], 'profiles'),
                'idinityCardImage' => DoctorController::UploadPDF($request['indentityCardImage_F'], $request['indentityCardImage_B'], $name),
                'address' => $request->input("address"),
                'user_Id' => $userId->id,
            ]);

            if (isset($request['hospitals'])) {
                foreach ($request->input('hospitals') as $hospital) {
                    Workinghour::create([
                        'hospital_id' => $hospital,
                        'doctor_id' =>$doctorId->id,
                    ]);
                }
            }


            if (isset($request['clincs'])) {
                foreach ($request->input('clincs') as $clinc) {
                    Workinghour::create([
                        'clinic_id' => $clinc,
                        'doctor_id' => $doctorId->id,
                    ]);
                }
            }
            event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة دكتور  جديد  ' ,null, $name));
            Alert::toast(  'تم اضافة دكتور  ' . $name . '  بنجاح  ','success');

            return redirect()->route('admin.doctor.index')->with('success', 'تم اضافة دكتور  ' . $name . '  بنجاح  ');
        }
        Alert::error('  حدث خطاء غير متوقع تاكد من تعبئة البيانات بشك صحيح !   ');
        return redirect()->route('admin.doctor.index')->with('error', '  حدث خطاء غير متوقع تاكد من تعبئة البيانات بشك صحيح !   ');
    }

    public function Index()
    {
        $all_doctor = Doctor::all();
        $index = 0;
       
        return view('A.Doctor_list', compact('all_doctor', 'index'));
    }

    public function Block(Request $request)
    {
        if ($request->input('block') == 0) {

            $block = '1';
            $msg = 'تم اعادة تفعيل حساب الدكتور  ';


        } else {

            $block = '0';
            $msg = 'تم ايقاف حساب الدكتور  ';
        }

       $user= User::findOrFail( $request->input('number'));
       event(new OperationOccurred(Auth::user()->person->name,  $msg.' ('. $user->person->name.')' ,$user->status, $block));

       $user->status=$block;
       $user->save();
       Alert::toast( $msg,'success');

        return redirect()->route('admin.doctor.index')->with('success', $msg);
    }
}
