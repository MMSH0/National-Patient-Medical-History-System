<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\HospitalRequest;
use App\Models\Admin\Hospital;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class HospitalController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function FileUpload($request)
    {
        $imageName = Carbon::now()->format('YmdHis') . '.' . $request->getClientOriginalExtension();
        $request->move(public_path('images/hospitals/logos/'),  $imageName);
        return $imageName;
    }

    public function Index()
    {
        $all_hospital = Hospital::all();
        $index = 0;
        return view('A.Hospital', compact('all_hospital', 'index'));
    }



    public function Store(HospitalRequest $request)
    {

        if ($request->validated()) {
            Hospital::create([
                'name' => $request->input('name'),
                'city' => $request->input('city'),
                'address' => $request->input('address'),
                'logo' => HospitalController::FileUpload($request['logo']),
            ]);
            event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة مستشفى  جديد  ', null, $request->input('name')));
            Alert::toast( '   تم اضافة مستشفى    ' . $request['name'] . ' بنجاح    ','success');

            return redirect()->route('admin.hospital.index')->with('success', '   تم اضافة مستشفى    ' . $request['name'] . ' بنجاح    ');
        }
    }

    public function Update(HospitalRequest $request)
    {
        if ($request->validated()) {

            $hospital = Hospital::findOrFail($request->input('number'));
            if (isset($request['logo'])) {
                $logo = HospitalController::FileUpload($request['logo']);
                if ($hospital->logo != $request->input('logo')) {
                    event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل شعار المستشفى ('.$request->input('name').')', $hospital->logo , $request->input('logo')));
                }
                $hospital->logo = $logo;
            }

            if ($hospital->name != $request->input('name')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم المستشفى ', $hospital->name , $request->input('name')));
                $hospital->name = $request->input('name');

            }
            if ($hospital->city != $request->input('city')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل مدينة المستشفى ('.$request->input('name').')', $hospital->city , $request->input('city')));
                $hospital->city = $request->input('city');

            }
            if ($hospital->address != $request->input('address')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل عنوان المستشفى ('.$request->input('name').')', $hospital->address , $request->input('address')));
                $hospital->address = $request->input('address');

            }



            $hospital->save();

            Alert::toast( '   تم تعديل بيانات مستشفى    ' . $request['name'] . ' بنجاح    ','success');

            return redirect()->route('admin.hospital.index')->with('success', '   تم تعديل بيانات مستشفى    ' . $request['name'] . ' بنجاح    ');
        }
    }



    public function Search(Request $request)
    {
        $query = $request->get('query');
        $posts = Hospital::where('name', 'like', "%$query%")->pluck('name');


        return response()->json($posts);
    }
}
