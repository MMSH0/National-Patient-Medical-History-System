<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\RayRequest;
use App\Models\Admin\Building;
use App\Models\Admin\Hospital;
use App\Models\Admin\Primation;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;

class RayCenterController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }



    public function FileUpload($request)
    {
        $imageName = Carbon::now()->format('YmdHis') . '.' . $request->getClientOriginalExtension();
        $request->move(public_path('images/buildings/logos/'),  $imageName);
        return $imageName;
    }

    public function Index()
    {
        $all_building =  Building::where('building_type', 'أشعة')->orWhere('building_type', 'مختبروأشعة')->get();
        $all_hospitall = Hospital::all();

        $index = 0;

        return view('A.Ray_center', compact('all_hospitall', 'all_building', 'index'));
    }

    public function Store(RayRequest $request)
    {

        if ($request->validated()) {

            if ($request->input('buid_type') == 0) {
                $role = 5;
                $buidling_type = "أشعة";
            } else if ($request->input('buid_type') == 1) {
                $role = 7;
                $buidling_type = "مختبروأشعة";
            }

            if (isset($request['logo'])) {

                Building::create(
                    [
                        'name' => $request->input('name'),
                        'city' => $request->input('city'),
                        'address' => $request->input('address'),
                        'building_type' =>  $buidling_type,
                        'hospital_id' => $request->input('hospital'),
                        'logo' => RayCenterController::FileUpload($request['logo']),

                    ]
                );


                $building_Id = Building::where('name', $request['name'])->where('city', $request['city'])->where("building_type", $buidling_type)->first();

                User::create([
                    'email' => $request->input('email'),
                    'password' => Hash::make('123456789'),
                    'phone_number' => $request->input('phone'),
                    'building_id' => $building_Id->id,

                ]);
                $userId = User::where('email', $request->input('email'))->first();

                Primation::create([
                    'user_id' => $userId->id,
                    'role_id' => $role
                ]);
                event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة مركز أشعة  جديد  ', null, $request->input('name')));
                Alert::toast('تم اضافة مركز الأشعة   ' . $request['name'] . '  بنجاح','success');

                return redirect()->route('admin.raycenter.index')->with('success', 'تم اضافة مركز الأشعة   ' . $request['name'] . '  بنجاح');
            }
            Alert::error(' يجب اختيار شعار المركز ');
            return redirect()->route('admin.raycenter.index')->with('error', ' يجب اختيار شعار المركز ');
        }
    }



    public function Update(RayRequest $request)
    {

        if ($request->validated()) {
            $building = Building::findOrFail($request->input('number'));

            if (isset($request['logo'])) {
                $logo = RayCenterController::FileUpload($request['logo']);


                $building->logo = $logo;
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل شعار مركز الأشعة (' .$request->input('name') . ')',  $building->logo,  $logo));
            }
            if ($building->name !=  $request->input('name')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم المركز الأشعة ',  $building->name,   $request->input('name')));
                $building->name =  $request->input('name');

            }
            if ($building->city !=  $request->input('city')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل مدينة مركز الأشعة (' .$request->input('name') . ')',  $building->city,   $request->input('city')));
                $building->city =  $request->input('city');

            }
            if ($building->address !=  $request->input('address')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل عنوان مركز الأشعة (' .$request->input('name') . ')',  $building->address,   $request->input('address')));
                $building->address =  $request->input('address');

            }

            if ($building->hospital_id != $request->input('hospital')) {


                if ($request->input('hospital') == '0') {
                    $oldHospital = Hospital::findOrFail($building->hospital_id);

                    event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل  مركز الأشعة (' . $request->input('name') . ')', ' مستشفى ' . $oldHospital->name, ' مركز الأشعة خارجي '));
                } else if ($building->hospital_id == 0) {
                    $newHospital = Hospital::findOrFail($request->input('hospital'));

                    event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل  مركز الأشعة (' . $request->input('name') . ')', ' مركز الأشعة خارجي ', ' مستشفى ' . $newHospital->name,));
                } else {
                    $oldHospital = Hospital::findOrFail($building->hospital_id);
                    $newHospital = Hospital::findOrFail($request->input('hospital'));

                    event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل مستشفى مركز الأشعة (' . $request->input('name') . ')', ' مستشفى ' . $oldHospital->name, ' مستشفى ' . $newHospital->name));
                }
                $building->hospital_id =  $request->input('hospital');

            }

            $building->updated_at =   Carbon::now();
            $building->save();

            $user = User::where('building_id', $request->input('number'))->first();

            if($user->email != $request->input('email')){
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل البريد الالكتروني الخاص بمركز الأشعة (' .$request->input('name') . ')',  $user->email,   $request->input('email')));
                $user->email = $request->input('email');

            }
            if($user->phone_number != $request->input('phone')){
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل رقم الهاتف  الخاص بمركز الأشعة (' .$request->input('name') . ')',  $user->phone_number,   $request->input('phone')));
                $user->phone_number = $request->input('phone');

            }
            $user->updated_at = Carbon::now();
            $user->save();
            Alert::toast(  '   تم تعديل بيانات مركز    ' . $request['name'] . '   بنجاح    ','success');

            return redirect()->route('admin.raycenter.index')->with('success', '   تم تعديل بيانات مركز    ' . $request['name'] . '   بنجاح    ');
        }
    }




    public function Block(Request $request)
    {
        if ($request->input('block') == 0) {

            $block = '1';
            $msg = 'تم  اعادة تفعيل  حساب مركز الأشعة  ';
        } else {

            $block = '0';
            $msg = 'تم ايقاف حساب مركز الأشعة  ';
        }
        $user = User::findOrFail( $request->input('number'));

        event(new OperationOccurred(Auth::user()->person->name,  $msg .'('.$user->building->name.')',  $request->input('block'),   $block));
        $user->status=$block;
        $user->save();
        Alert::toast( $msg,'success');

        return redirect()->route('admin.raycenter.index')->with('success', $msg);
    }


    public function Search(Request $request)
    {
        $query = $request->get('query');
        $posts = Building::where('building_type', 'أشعة')->where('name', 'like', "%$query%")->pluck('name');


        return response()->json($posts);
    }
}
