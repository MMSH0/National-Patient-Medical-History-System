<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Models\Doctor\Patient;
use App\Models\User;
use App\Rules\checkPhoneNumber;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class PatientController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function notification($userId, $title, $message)
    {



        try {
            $fcmTokens = User::where('id', $userId)->whereNotNull('fcm_token')->pluck('fcm_token')->first();

            $url = 'https://fcm.googleapis.com/fcm/send';


            $serverKey = "AAAAbor-lLo:APA91bFnN-I3OUh7XCwa6JprxUlbGQnu_W8Gif7IJROdPaXXdQuHvheAT3IAGG_Ss7QBshdI7BP4ttWzP2yoJuRldzse_3-YBnmE_7EhUjHewsP-gdSDVLrtYNonRalWOYvf7OmRmd6N";

            $dataArr = [
                "click_action" => "FLUTTER_NOTIFICATION_CLICK",
                "status" => "done"
            ];


            $data = [
                "registration_ids" => [$fcmTokens],
                "notification" => [
                    "title" => str($title),
                    "body" => str($message),
                    "sound" => "default",
                ],
                "data" => $dataArr,
                "priority" => "high",
            ];

            $encodedData = json_encode($data);

            $headers = [
                "Authorization:key=" . $serverKey,
                "Content-Type: application/json"
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedData);
            $result = curl_exec($ch);
        } catch (\Exception $e) {
        }
    }



    public function Index()
    {
        $all_patient = Patient::whereNotNull('user_id')->orderBy("id", "DESC")->distinct('user.phoneNumber')->get();

        $index = 0;
        return view('A.Patient', compact('all_patient', 'index'));
    }
    public function Auth()
    {
        $all_patient = Patient::whereNotNull('user_id')
            ->whereHas('user', function ($query) {
            $query->where('status', '!=', '1');
            })
            ->orderBy("id", "DESC")
            ->distinct('user.phoneNumber')
            ->get();

        $index = 0;
        return view('A.PatientAuth', compact('all_patient', 'index'));
    }
    public function verify(Request $request)
    {
        $patient = Patient::findOrFail($request->input('number'));
        $patient->user->status = $request->input('submit');
        event(new OperationOccurred(Auth::user()->person->name, $request->input('submit') == '0' ? 'تم رفض تاكيد الحساب' : 'تم تاكيد الحساب' . '(' . $patient->user->person->name . ')  ', $patient->user->status, $request->input('submit')));
        $patient->user->save();

        PatientController::notification($patient->user->id, 'تم تاكيد الحساب', 'تم تاكيد الحساب بنجاح');
        Alert::toast($request->input('submit') == '0' ? 'تم رفض تاكيد الحساب' : 'تم تاكيد الحساب', 'success');

        return redirect()->route('admin.patient.auth')->with('success', $request->input('submit') == '0' ? 'تم رفض تاكيد الحساب' : 'تم تاكيد الحساب');
    }
    public function EditData(Request $request)
    {
        $patient = Patient::findOrFail($request->input('number'));



        if ($patient->user->phone_number != $request->input('phone')) {
            $validatedDate  = $this->validate($request, [
                'phone' => ['required', new  checkPhoneNumber('users', 'phone_number')]
            ]);
            $patient->user->phone_number = $request->input('phone');
            PatientController::notification($patient->user->id, 'تم تعديل رقم الهاتف الخاص بالحساب  ' . '(' . $patient->user->person->name . ')  ',  ' ');

            event(new OperationOccurred(Auth::user()->person->name, ' تعديل رقم الهاتف المريض ' . '(' . $patient->user->person->name . ')  ', $patient->user->phone_number, $request->input('phone')));
            Alert::toast('تم تعديل رقم الهاتف الخاص ' . $patient->user->person->name . ' بنجاح', 'success');
        }

        if ($patient->user->person->name != $request->input('name')) {
            $patient->user->person->name = $request->input('name');
            PatientController::notification($patient->user->id, 'تم تعديل اسم مالك الحساب ' . '(' . $patient->user->person->name . ')  ', ' الاسم السابق : ' . $patient->user->person->name . '\n  الاسم الحالي :' . $request->input('name') . ' ');

            event(new OperationOccurred(Auth::user()->person->name, ' تعديل اسم  المريض ' . '(' . $patient->user->person->name . ')  ', $patient->user->person->name, $request->input('name')));
            Alert::toast('تم تعديل  اسم المريض  ' . $request->input('name') . ' بنجاح', 'success');
        }

        $patient->user->save();
        $patient->user->person->save();



        return redirect()->route('admin.patient.index')->with('success', $request->input('submit') == '0' ? 'تم رفض تاكيد الحساب' : 'تم تاكيد الحساب');
    }
    public function Decline(Request $request)
    {
        $patient = Patient::findOrFail($request->input('number'));
        $patient->user->status = $request->input('submit');

        PatientController::notification($patient->user->id, 'تم  رفض  الحساب ', ' المشكلة : '.$request->input('notes').' ');


        event(new OperationOccurred(Auth::user()->person->name, $request->input('submit') == '0' ? 'تم رفض تاكيد الحساب' : 'تم تاكيد الحساب' . '(' . $patient->user->person->name . ')  ', $patient->user->status, $request->input('submit')));
        $patient->user->save();
        Alert::toast($request->input('submit') == '0' ? 'تم رفض تاكيد الحساب' : 'تم تاكيد الحساب', 'success');

        return redirect()->route('admin.patient.index')->with('success', $request->input('submit') == '0' ? 'تم رفض تاكيد الحساب' : 'تم تاكيد الحساب');
    }
}
