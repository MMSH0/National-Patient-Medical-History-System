<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SurgeryRequest;
use App\Models\Admin\Surgery;
use App\Models\Doctor\Patient;
use App\Models\Doctor\PatientFamily;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use RealRashid\SweetAlert\Facades\Alert;

class SurgeryController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }



    public  function importCsv(Request $request)
    {
        if (isset($request['file']) && ($request['file']->getClientOriginalExtension() == "csv")) {
            $csvData = file_get_contents($request['file']);
            $rows = array_map("str_getcsv", explode("\n", $csvData));

            $headers = array_shift($rows);
            $index = 0;

            foreach ($rows as $row) {

                if (count($row) !== count($headers)) {

                    continue;
                }


                $data = array_combine($headers, $row);

                $sep = new Surgery();


                $sep->name = $data['Name'];
                $sep->description = $data['Description'];
                $sep->save();

                ++$index;
            }
            event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة   ' . $index . '    اسم  بنجاح    ', null, null));
            Alert::toast('تمت اضافة   ' . $index . '    اسم  بنجاح    ', 'success');

            return redirect()->route('admin.surgery.index')->with('success', 'تمت اضافة   ' . $index . '    اسم  بنجاح    ');
        }
        return redirect()->route('admin.surgery.index')->with('error', ' تاكد من اختيار الملف بشكل صحيح يكون بصيغة .csv');
    }

    public function Index()
    {
        $all_surgery = Surgery::all();
        $index = 0;
        return view('A.Surgery', compact('all_surgery', 'index'));
    }

    public function Store(SurgeryRequest $request)
    {
        if ($request->validated()) {

            Surgery::create([
                'name' => $request->input('name'),
                'description' => $request->input('description'),
            ]);
            event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة  عملية  جديد  ', null, $request->input('name')));
            Alert::toast('تم اضافة عملية    ' . $request['name'] . '    بنجاح', 'success');

            return redirect()->route('admin.surgery.index')->with('success', 'تم اضافة عملية    ' . $request['name'] . '    بنجاح');
        }
    }

    public function Update(SurgeryRequest $request)
    {
        if ($request->validated()) {
            $surgery = Surgery::findOrFail($request->input('number'));

            if ($surgery->name != $request->input('name')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم  العملية  ', $surgery->name, $request->input('name')));
                $surgery->name = $request->input('name');
            }
            if ($surgery->description != $request->input('description')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل  وصف العملية  (' . $request->input('name') . ')', $surgery->description, $request->input('description')));
                $surgery->description = $request->input('description');
            }
            $surgery->save();

            Alert::toast('تم تعديل بيانات عملية    ' . $request['name'] . '    بنجاح', 'success');


            return redirect()->route('admin.surgery.index')->with('success', 'تم تعديل بيانات عملية    ' . $request['name'] . '    بنجاح');
        }
    }



    public function Search(Request $request)
    {
        $query = $request->get('query');
        $posts = Surgery::where('name', 'like', "%$query%")->pluck('name');
        return response()->json($posts);
    }
}
