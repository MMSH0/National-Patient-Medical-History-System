<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\MedicenRequest;
use App\Models\Admin\Medicen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class MedicenController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }


    // Compelete the operations of Log File
    public  function importCsv(Request $request)
    {
        if (isset($request['file']) && ($request['file']->getClientOriginalExtension() == "csv")) {
            $csvData = file_get_contents($request['file']);
            $rows = array_map("str_getcsv", explode("\n", $csvData));

            $headers = array_shift($rows);
            $index = 0;

            foreach ($rows as $row) {

                if (count($row) !== count($headers)) {

                    continue;
                }


                $data = array_combine($headers, $row);

                $sep = new Medicen();


                $sep->name = $data['Name'];
                $sep->country = $data['country'];
                $sep->company_name = $data['company_name'];
                $sep->scientific_name = $data['scientific_name'];
                $sep->description = $data['Description'];
                $sep->save();

                ++$index;
            }
            Alert::toast( 'تمت اضافة   ' . $index . '     علاج  بنجاح    ','success');

            return redirect()->route('admin.chronicdisease.index')->with('success', 'تمت اضافة   ' . $index . '     علاج  بنجاح    ');
        }
        Alert::error(' تاكد من اختيار الملف بشكل صحيح يكون بصيغة .csv');

        return redirect()->route('admin.chronicdisease.index')->with('error', ' تاكد من اختيار الملف بشكل صحيح يكون بصيغة .csv');
    }


    public function Index()
    {
        $all_medicen = Medicen::all();
        $index = 0;
        return view('A.Medicen', compact('all_medicen', 'index'));
    }

    public function Store(MedicenRequest $request)
    {
        if ($request->validated()) {
            Medicen::create([
                'name' => $request->input('name'),
                'country' => $request->input('country'),
                'company_name' => $request->input('company_name'),
                'scientific_name' => $request->input('scientific_name'),
                'description' => $request->input('description'),
            ]);
            event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة علاج  جديد', null, $request->input('name')));
            Alert::toast(  'تم اضافة علاج    ' . $request['name'] . '  بنجاح','success');

            return redirect()->route('admin.medicen.index')->with('success', 'تم اضافة علاج    ' . $request['name'] . '  بنجاح');
        }
    }

    public function Update(MedicenRequest $request)
    {
        if ($request->validated()) {
            $medicen = Medicen::findOrFail($request->input('number'));
            if ($medicen->name != $request->input('name')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم العلاج ', $medicen->name, $request->input('name')));

                $medicen->name = $request->input('name');
            }

            if ($medicen->country != $request->input('country')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم دولة العلاج ('.$request->input('name').')', $medicen->country, $request->input('country')));

                $medicen->country = $request->input('country');
            }

            if ($medicen->company_name != $request->input('company_name')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم شركة العلاج ('.$request->input('name').')', $medicen->company_name, $request->input('company_name')));


                $medicen->company_name = $request->input('company_name');
            }

            if ($medicen->scientific_name != $request->input('scientific_name')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم العلمي العلاج ('.$request->input('name').')', $medicen->scientific_name, $request->input('scientific_name')));

                $medicen->scientific_name = $request->input('scientific_name');
            }

            if ($medicen->description != $request->input('description')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم العلمي العلاج ('.$request->input('name').')', $medicen->description, $request->input('description')));

                $medicen->description = $request->input('description');
            }
            $medicen->save();
            Alert::toast( 'تم تعديل بيانات علاج    ' . $request['name'] . '  بنجاح','success');
            return redirect()->route('admin.medicen.index')->with('success', 'تم تعديل بيانات علاج    ' . $request['name'] . '  بنجاح');
        }
    }

    public function Search(Request $request)
    {
        $query = $request->get('query');
        $posts = Medicen::where('name', 'like', "%$query%")->pluck('name');
        return response()->json($posts);
    }
}
