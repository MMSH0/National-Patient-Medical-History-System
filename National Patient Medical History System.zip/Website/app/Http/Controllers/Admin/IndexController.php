<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\Building;
use App\Models\Admin\Doctor;
use App\Models\Admin\Hospital;

class IndexController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function Index()
    {
        $doctor_count = Doctor::count();
        $lab_count = Building::where('building_type', 'مختبر')->count();
        $ray_count = Building::where('building_type', 'أشعة')->count();
        $hospital_count = Hospital::count();
        return view('A.Index', compact('doctor_count', 'lab_count', 'ray_count', 'hospital_count'));
    }

    public function Profile()
    {
        return view('A.Profile');
    }

}
