<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\RadiologyRequest;
use App\Models\Admin\Radiology;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class RadiologyController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function Index()
    {
        $all_ray = Radiology::all();
        $index = 0;
        return view('A.Radiology_list', compact('all_ray', 'index'));
    }

    public function Add()
    {
        return view('A.Add_radiology');
    }

    public function Store(RadiologyRequest $request)
    {
        if ($request->validated()) {

            Radiology::create([
                'name' => $request->input('name'),
                'Description' => $request->input('description'),
            ]);
            event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة أشعة  جديد  ', null, $request->input('name')));
            Alert::toast( '  تم اضافة أشعة   ' . $request['name'] . '   بنجاح  ','success');

            return redirect()->route('admin.radiology.store')->with('success', '  تم اضافة أشعة   ' . $request['name'] . '   بنجاح  ');
        }
    }

    public function Update(RadiologyRequest $request)
    {
        if ($request->validated()) {
            $radiology = Radiology::findOrFail($request->input('number'));


            if($radiology->name != $request->input('name')){
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم الأشعة    ', $radiology->name, $request->input('name')));
                $radiology->name = $request->input('name');

            }
            if($radiology->Description != $request->input('description')){
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل وصف أشعة    ('.$request->input('name').')', $radiology->Description, $request->input('description')));
                $radiology->Description = $request->input('description');

            }
            $radiology->save();


            Alert::toast( '  تم تعديل بيانات أشعة   ' . $request['name'] . '   بنجاح  ','success');

            return redirect()->route('admin.radiology.store')->with('success', '  تم تعديل بيانات أشعة   ' . $request['name'] . '   بنجاح  ');
        }
    }


    public function Search(Request $request)
    {
        $query = $request->get('query');
        $posts = Radiology::where('name', 'like', "%$query%")->pluck('name');
        return response()->json($posts);
    }
}
