<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ClincRequest;
use App\Models\Admin\Building;
use App\Models\Admin\Hospital;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class ClincController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function FileUpload($request)
    {
        $imageName = Carbon::now()->format('YmdHis') . '.' . $request->getClientOriginalExtension();
        $request->move(public_path('images/buildings/logos/'),  $imageName);
        return $imageName;
    }

    public function Index()
    {
        $all_building =  Building::where('building_type', 'عيادة')->get();
        $all_hospitall = Hospital::all();
        $index = 0;
        return view('A.Clinc', compact('all_building', 'index', 'all_hospitall'));
    }

    public function Store(ClincRequest $request)
    {

        if ($request->validated()) {
            Building::create(
                [
                    'name' => $request->input('name'),
                    'city' => $request->input('city'),
                    'address' => $request->input('address'),
                    'building_type' => "عيادة",
                    'hospital_id' => $request->input('hospital'),
                    'logo' => ClincController::FileUpload($request['logo']),

                ]
            );

            event(new OperationOccurred(Auth::user()->person->name, 'اضافة عيادة  جديده', null, $request->input('name')));
            Alert::toast( 'تم اضافة عيادة   ' . $request['name'] . '  بنجاح','success');

            return redirect()->route('admin.clinc.index')->with('success', 'تم اضافة عيادة   ' . $request['name'] . '  بنجاح');
        }
    }



    public function Update(ClincRequest $request)
    {
        if ($request->validated()) {
            $building = Building::findOrFail($request->input('number'));


            if (isset($request['logo'])) {
                $logo=ClincController::FileUpload($request['logo']);

                $building->logo =  $logo;
                event(new OperationOccurred(Auth::user()->person->name,  ' تم تعديل شعار العيادة (' . $request->input('name') . ')', $building->logo,  $logo));

            }

                if ($building->name != $request->input('name')) {
                    event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل أسم العيادة ', $building->name, $request->input('name')));
                    $building->name = $request->input('name');

                }
                if ($building->city != $request->input('city')) {
                    event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل مدينة عيادة (' . $request->input('name') . ')', $building->city, $request->input('city')));
                    $building->city = $request->input('city');

                }
                if ($building->address != $request->input('address')) {
                    event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل موقع عيادة (' . $request->input('name') . ')', $building->address, $request->input('address')));
                    $building->address = $request->input('address');

                }
                if ($building->hospital_id != $request->input('hospital')) {


                    if ($request->input('hospital') == '0') {
                        $oldHospital = Hospital::findOrFail($building->hospital_id);

                        event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل  العيادة (' . $request->input('name') . ')', ' مستشفى '.$oldHospital->name , ' عيادة خارجية '));
                    } else if ($building->hospital_id == 0) {
                        $newHospital = Hospital::findOrFail($request->input('hospital'));

                        event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل  العيادة (' . $request->input('name') . ')', ' عيادة خارجية ', ' مستشفى '.$newHospital->name ,));
                    } else {
                        $oldHospital = Hospital::findOrFail($building->hospital_id);
                        $newHospital = Hospital::findOrFail($request->input('hospital'));

                        event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل مستشفى العيادة (' . $request->input('name') . ')', ' مستشفى '.$oldHospital->name, ' مستشفى '.$newHospital->name));
                    }
                    $building->hospital_id = $request->input('hospital');

                }


                $building->save();

                Alert::toast( '   تم تعديل بيانات عيادة    ' . $request['name'] . '   بنجاح    ','success');


            return redirect()->route('admin.clinc.index')->with('success', '   تم تعديل بيانات عيادة    ' . $request['name'] . '   بنجاح    ');
        }
    }




    public function Search(Request $request)
    {
        $query = $request->get('query');
        $posts = Building::where('building_type', 'عيادة')->where('name', 'like', "%$query%")->pluck('name');
        return response()->json($posts);
    }
}
