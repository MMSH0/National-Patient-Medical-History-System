<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\TestRequest;
use App\Http\Requests\Admin\TestTypeRequest;
use App\Models\Admin\Test;
use App\Models\Admin\Test_type;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;


class TestController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function Add()
    {
        $all_test_type = Test_type::all();
        return view('A.Add_test', compact('all_test_type'));
    }
    public function Index()
    {
        $all_test = Test::all();
        $all_test_type = Test_type::all();
        $index = 0;
        return view('A.Test_list', compact('all_test', 'index', 'all_test_type'));
    }

    public function TypeIndex()
    {
        $all_test = Test_type::all();
        $index = 0;
        return view('A.Test_Type_list', compact('all_test', 'index'));
    }

    public function TypeStore(TestTypeRequest $request)
    {
        if ($request->validated()) {

            Test_type::create([
                'name' => $request['name'],
                'description' => $request['description'],
            ]);
            event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة  نوع فحص جديد  ', null, $request->input('name')));
            Alert::toast( 'تم اضافة نوع الفحص  ' . $request['name'] . '  بنجاح','success');

            return redirect()->route('admin.test.type.index')->with('success', 'تم اضافة نوع الفحص  ' . $request['name'] . '  بنجاح');
        }
    }

    public function TypeUpdate(TestTypeRequest $request)
    {
        if ($request->validated()) {
            $testType = Test_type::findOrFail($request['number']);

            if ($testType->name != $request->input('name')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل  اسم نوع الفحص ',  $testType->name, $request->input('name')));
                $testType->name = $request->input('name');

            }
            if ($testType->description != $request->input('description')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل  وصف نوع الفحص (' . $request->input('name') . ')',  $testType->description, $request->input('description')));
                $testType->description = $request->input('description');

            }

            $testType->save();
            Alert::toast( 'تم تعديل نوع الفحص  ' . $request['name'] . '  بنجاح','success');

            return redirect()->route('admin.test.type.index')->with('success', 'تم تعديل نوع الفحص  ' . $request['name'] . '  بنجاح');
        }
    }


    public function TestStore(TestRequest $request)
    {
        if ($request->validated()) {
            Test::create([
                'name' => $request->input('name'),
                'normal' => $request->input('normal'),
                'high' => $request->input('high'),
                'low' => $request->input('low'),
                'test_type_id' => $request->input('test_type_id'),
                'description' => $request->input('description'),
            ]);
            event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة فحص جديد  ', null, $request->input('name')));

        }
        Alert::toast( 'تم اضافة فحص  ' . $request['name'] . '  بنجاح','success');
        return redirect()->route('admin.test.index')->with('success', 'تم اضافة فحص   ' . $request['name'] . '  بنجاح');
    }

    public function TestUpdate(TestRequest $request)
    {
        if ($request->validated()) {

            $test=Test::findOrFail($request->input('number'));
            if($test->name!=$request->input('name')){
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم الفحص ('. $request->input('name').')',  $test->name, $request->input('name')));
                $test->name=$request->input('name');

            }
            if($test->normal!=$request->input('normal')){
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل الحالة الطبيعية للفحص ('. $request->input('name').')',  $test->normal, $request->input('normal')));
                $test->normal=$request->input('normal');

            }
            if($test->high!=$request->input('high')){
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل الحالة المرتفعة للفحص ('. $request->input('name').')',  $test->high, $request->input('high')));
                $test->high=$request->input('high');

            }
            if($test->low!=$request->input('low')){
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل الحالة المنخفظة للفحص ('. $request->input('name').')',  $test->low, $request->input('low')));
                $test->low=$request->input('low');

            }
            if($test->description!=$request->input('description')){
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل وصف الفحص ('. $request->input('name').')',  $test->description, $request->input('description')));
                $test->description=$request->input('description');

            }
            if($test->test_type_id!=$request->input('test_type_id')){
            $oldTestType = Test_type::findOrFail($test->test_type_id);
            $newTestType = Test_type::findOrFail($request->input('test_type_id'));

                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل وصف الفحص ('. $request->input('name').')',  $oldTestType->name, $newTestType->name));
                $test->test_type_id=$request->input('test_type_id');

            }

            $test->save();
            Alert::toast( 'تم تعديل فحص  ' . $request['name'] . '  بنجاح','success');
            return redirect()->route('admin.test.index')->with('success', 'تم تعديل فحص   ' . $request['name'] . ' بنجاح  ');
        }
    }

    public function TestSearch(Request $request)
    {
        $query = $request->get('query');
        $posts = Test::where('name', 'like', "%$query%")->pluck('name');
        return response()->json($posts);
    }

    public function TypeTestSearch(Request $request)
    {
        $query = $request->get('query');
        $posts = Test_type::where('name', 'like', "%$query%")->pluck('name');
        return response()->json($posts);
    }
}
