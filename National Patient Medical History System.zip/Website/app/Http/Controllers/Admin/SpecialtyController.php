<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SpecialtyRequest;
use App\Models\Admin\Specialty;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use RealRashid\SweetAlert\Facades\Alert;

class SpecialtyController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public  function importCsv(Request $request)
    {
        if (isset($request['file']) && ($request['file']->getClientOriginalExtension() == "csv")) {
            $csvData = file_get_contents($request['file']);
            $rows = array_map("str_getcsv", explode("\n", $csvData));

            $headers = array_shift($rows);
            $index = 0;
            foreach ($rows as $row) {

                if (count($row) !== count($headers)) {
                    continue;
                }


                $data = array_combine($headers, $row);

                $sep = new Specialty();


                $sep->name = $data['Name'];
                $sep->degree = $data['Degree'];
                $sep->save();

                ++$index;
            }
            Alert::toast('تمت اضافة   ' . $index . '    تخصص بنجاح    ', 'success');

            return redirect()->route('admin.specialty.index')->with('success', 'تمت اضافة   ' . $index . '    تخصص بنجاح    ');
        }
        Alert::error(' تاكد من اختيار الملف بشكل صحيح يكون بصيغة .csv', 'error');

        return redirect()->route('admin.specialty.index')->with('error', ' تاكد من اختيار الملف بشكل صحيح يكون بصيغة .csv');
    }

    public function Index()
    {

        $all_special = Specialty::all();
        $index = 0;


        return view('A.Specialty', compact('all_special', 'index'));
    }

    public function Search(Request $request)
    {
        $query = $request->get('query');
        $posts = Specialty::where('name', 'like', "%$query%")->pluck('name');


        return response()->json($posts);
    }

    public function Store(SpecialtyRequest $request)
    {

        if ($request->validated()) {
            Specialty::create([
                'name' => $request->input('name'),
                'degree' => $request->input('degree')
            ]);
            event(new OperationOccurred(Auth::user()->person->name, 'اضافة تخصص طبي جديد  ', null, $request->input('name')));
        }
        Alert::toast( 'تمت اضافه    ' . $request['name'] . '  بنجاح   ','success');

        return redirect()->route('admin.specialty.index')->with('success', 'تمت اضافه    ' . $request['name'] . '  بنجاح   ');
    }


    public function Update(SpecialtyRequest $request)
    {

        if ($request->validated()) {
            $specialty = Specialty::findOrFail($request->input('number'));
            if ($specialty->name != $request->input('name')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم التخصص الطبي   ', $specialty->name, $request->input('name')));
                $specialty->name = $request->input('name');
            }
            if ($specialty->degree != $request->input('degree')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل الدرجة العلمية الخاصة التخصص الطبي  (' . $request->input('name') . ')', $specialty->degree, $request->input('degree')));
                $specialty->degree = $request->input('degree');
            }
            $specialty->save();
        }
        Alert::toast('   تم تعديل بيانات تخصص    ' . $request['name'] . ' الطبي  بنجاح    '. '  بنجاح   ','success');

        return redirect()->route('admin.specialty.index')->with('success', '   تم تعديل بيانات تخصص    ' . $request['name'] . ' الطبي  بنجاح    ');
    }
}
