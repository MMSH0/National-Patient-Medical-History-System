<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ProfileRequest;
use App\Http\Requests\Admin\UserRequest;
use App\Models\Admin\Person;
use App\Models\Admin\Primation;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;

class UserController extends Controller
{

    public function FileUpload($request)
    {
        $imageName = Carbon::now()->format('YmdHis') . '.' . $request->getClientOriginalExtension();
        $request->move(public_path('images/admin/'),  $imageName);
        return $imageName;
    }
    public function Index()
    {
        $primation = Primation::where('user_id', Auth::user()->id)->with('role')->get();
        foreach ($primation as $pre) {
            if ($pre->role->user_type  === 'superadmin') {
                $usertype = $pre->role->user_type;
                break;
            } else {
                $usertype = $pre->role->user_type;
            }
        }
        if ($usertype == 'superadmin') {
            return view('A.Add_user');
        }
        return redirect()->route('admin.index');
    }

    public function All()
    {
        $primation = Primation::where('user_id', Auth::user()->id)->with('role')->get();
        foreach ($primation as $pre) {

            $usertype = $pre->role->user_type;
        }

        if ($usertype == 'superadmin') {
            $primation = Primation::where('role_id', 2)->with('role')->get();
            $userIds = $primation->pluck('user_id')->toArray();
            $all_user = User::whereIn('id', $userIds)->get();

            if (isset($all_user)) {

                $index = 0;
                return view('A.All_users', compact('all_user', 'index'));
            }
            return view('A.All_users');
        }
    }
    public function Store(UserRequest $request)
    {
        if ($request->validated())
            $name = $request->input('first_name') . ' ' . $request->input('last_name');

        User::create([
            'phone_number' => $request->input('phone'), 'email' => $request->input('email'), 'user_type' => "doctor", 'password' => Hash::make("123456789")
        ]);

        $userId = User::where('email', $request['email'])->first();


        Person::create([
            'name' => $name,
            'birthDate' => $request->input("birthday"),
            'gender' => $request->input("geneder"),
            'birthCity' => $request->input("city"),
            'indentityCardNumber' => $request->input("identity_card"),
            'address' => $request->input("address"),
            'user_Id' => $userId->id,
        ]);

        Primation::create([
            'user_id' => $userId->id,
            'role_id' => 2
        ]);
        event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة مستخدم جديد', null, $name));
        Alert::toast('تم اضافة مستخدم  ' . $name . '  بنجاح  ', 'success');


        return redirect()->route('admin.user.index')->with('success', 'تم اضافة مستخدم  ' . $name . '  بنجاح  ');
    }


    public function Update(ProfileRequest $request)
    {
        $user = User::where('id', $request['number'])->firstOrFail();

        if (isset($user) && $request->validated()) {
            $person = Person::where('user_Id', $user->id)->firstOrFail();

            if ($user->email != $request->input('email')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تحديث الايميل الاكتروني الخاص بالمستخدم (' . $request->input('name') . ')',  $user->email, $request->input('email')));
                $user->email = $request->input('email');
            }
            if ($user->phone_number != $request->input('phoneNumber')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تحديث رقم الهاتف الخاص بالمستخدم (' . $request->input('name') . ')',  $user->phone_number, $request->input('phoneNumber')));

                $user->phone_number = $request->input('phoneNumber');
            }

            if ($person->name != $request->input('name')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تحديث رقم الهاتف الخاص بالمستخدم (' . $request->input('name') . ')',  $user->phone_number, $request->input('phoneNumber')));
                $person->name = $request->input('name');
            }
            if ($person->birthDate != $request->input('birthDate')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تحديث تاريخ الميلاد الخاص بالمستخدم (' . $request->input('name') . ')',  $user->birthDate, $request->input('birthDate')));

                $person->birthDate = $request->input('birthDate');
            }
            if ($person->birthCity != $request->input('birthCity')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تحديث  مكان الميلاد الخاص بالمستخدم (' . $request->input('name') . ')',  $user->birthCity, $request->input('birthCity')));

                $person->birthCity = $request->input('birthCity');
            }
            if ($person->address != $request->input('address')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تحديث  عنوان السكن  الخاص بالمستخدم (' . $request->input('name') . ')',  $user->address, $request->input('address')));

                $person->address = $request->input('address');
            }

            $user->save();
            $person->save();
            Alert::toast(' تم تحديث بيانات حساب  ' . $request->input('name') . '  بنجاح  ', 'success');

            return redirect()->route('admin.profile')->with('success', ' تم تحديث بيانات حساب  ' . $request->input('name') . '  بنجاح  ');
        }
        Alert::error(' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');

        return redirect()->route('admin.profile')->with('error', ' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');
    }


    public function UpdatePassword(Request $request)
    {
        $user = User::where('id', $request['number'])->firstOrFail();


        if (isset($user) && Hash::check($request->input('oldPassword'), $user->password)) {
            $user->password = bcrypt($request->input('newPassword'));

            event(new OperationOccurred(Auth::user()->person->name, 'تم تحديث  كلمة السر  الخاص بالمستخدم (' . $request->input('name') . ')', null, null));
            Alert::toast(' تم تغيير كلمة السر  ' . $request->input('name') . ' بنجاح ', 'success');
            $user->save();
            return redirect()->route('admin.profile')->with('success', ' تم تغيير كلمة السر  ' . $request->input('name') . ' بنجاح ');
        } else if ($request->input('newPassword') != $request->input('newPassword2')) {
            event(new OperationOccurred(Auth::user()->person->name, ' حدث خطاء عند تحديث  كلمة السر  الخاص بالمستخدم بسبب ان كلمة السر غير متطابقة (' . $request->input('name') . ')', null, null));
            Alert::error(' كلمة السر  غير متطابقة  ');

            return redirect()->route('admin.profile')->with('error', ' كلمة السر  غير متطابقة  ');
        } else {
            event(new OperationOccurred(Auth::user()->person->name, ' حدث خطاء عند تحديث  كلمة السر  الخاص بالمستخدم (' . $request->input('name') . ')', null, null));
            Alert::error(' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');
            return redirect()->route('admin.profile')->with('error', ' حدث خطا!!  يجب تعبئة الببيانات بشكل صحيح ');
        }
    }

    public function UpdateImage(Request $request)
    {
        $user = User::where('id', $request['number'])->firstOrFail();
        if (isset($user) && isset($request['image'])) {
            $person = Person::where('user_Id', $user['id'])->firstOrFail();
            $image = UserController::FileUpload($request['image']);
            event(new OperationOccurred(Auth::user()->person->name, 'تم تحديث الصورة  الخاصه بالمستخدم (' . $request->input('name') . ')', $person->prsonalImage,  $image));

            $person->prsonalImage = $image;

            $person->save();
            Alert::toast(' تم تحديث الصورة الشخصية ', 'success');

            return redirect()->route('admin.profile')->with('success', ' تم تحديث الصورة الشخصية ');
        }
        event(new OperationOccurred(Auth::user()->person->name, 'حدث خطا عند تحديث الصورة الخاصه بالمستخدم (' . $request->input('name') . ')', null,  null));
        Alert::error(' حدث خطا!!  يجب اختيار الصورة بشكل صحيح ');

        return redirect()->route('admin.profile')->with('error', ' حدث خطا!!  يجب اختيار الصورة بشكل صحيح ');
    }


    public function Block(Request $request)
    {
        if ($request->input('block') == 0) {

            $block = '1';
            $msg = 'تم  اعادة تفعيل  حساب المسوؤل   ';
        } else {

            $block = '0';
            $msg = 'تم ايقاف حساب المسوؤل   ';
        }
        $user = User::findOrFail($request->input('number'));

        event(new OperationOccurred(Auth::user()->person->name, $msg . '(' . $request->input('name') . ')', $user->status,  $block));

        $user->status = $block;
        $user->save();
        Alert::toast($msg, 'success');

        return redirect()->route('admin.users.index')->with('success', $msg);
    }
}
