<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ChronicDiseaseRequest;
use App\Models\Admin\ChronicDisease;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class ChronicDiseaseController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }


    public  function importCsv(Request $request)
    {
        if (isset($request['file']) && ($request['file']->getClientOriginalExtension() == "csv")) {
            $csvData = file_get_contents($request['file']);
            $rows = array_map("str_getcsv", explode("\n", $csvData));

            $headers = array_shift($rows);
            $index = 0;

            foreach ($rows as $row) {

                if (count($row) !== count($headers)) {

                    continue;
                }


                $data = array_combine($headers, $row);

                $sep = new ChronicDisease();


                $sep->name = $data['Name'];
                $sep->description = $data['Description'];
                $sep->save();
                event(new OperationOccurred(Auth::user()->person->name, ' تم استيراد اسماء الامراض المزمنة  (' . (1 + $index) . ')', null, $data['Name']));

                ++$index;
            }
            Alert::toast( 'تمت اضافة   ' . $index . '    مرض مزمن بنجاح    ','success');
            return redirect()->route('admin.chronicdisease.index')->with('success', 'تمت اضافة   ' . $index . '    مرض مزمن بنجاح    ');
        }
        return redirect()->route('admin.chronicdisease.index')->with('error', ' تاكد من اختيار الملف بشكل صحيح يكون بصيغة .csv');
    }

    public function Index()
    {
        $all_Diagnose = ChronicDisease::all();
        $index = 0;
        return view('A.Chronic_Disease', compact('all_Diagnose', 'index'));
    }

    public function Store(ChronicDiseaseRequest $request)
    {
        if ($request->validated()) {
            ChronicDisease::create([
                'name' => $request->input('name'),
                'description' => $request->input('description'),
            ]);
            event(new OperationOccurred(Auth::user()->person->name, ' تم اضافة مرض مزمن  ', null, $request->input('name')));
            Alert::toast(  'تم اضافة مرض  ' . $request['name'] . '  المزمن بنجاح','success');

            return redirect()->route('admin.chronicdisease.index')->with('success', 'تم اضافة مرض  ' . $request['name'] . '  المزمن بنجاح');
        }
    }


    public function Update(ChronicDiseaseRequest $request)
    {
        if ($request->validated()) {


          $chronic=  ChronicDisease::findOrFail($request->input('number'));
          if($chronic->name!=$request->input('name')){
            event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل اسم المرض المزمن  ', $chronic->name, $request->input('name')));
            $chronic->name= $request->input('name');

          }
          if($chronic->description!=$request->input('description')){
            event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل وصف المرض المزمن ( '. $request->input('name').')', $chronic->description, $request->input('description')));
            $chronic->description= $request->input('description');

          }
        $chronic->save();
        Alert::toast( 'تم تعديل بيانات مرض  ' . $request['name'] . '  المزمن بنجاح','success');

            return redirect()->route('admin.chronicdisease.index')->with('success', 'تم تعديل بيانات مرض  ' . $request['name'] . '  المزمن بنجاح');
        }
    }

    public function Search(Request $request)
    {
        $query = $request->get('query');
        $posts = ChronicDisease::where('name', 'like', "%$query%")->pluck('name');
        return response()->json($posts);
    }
}
