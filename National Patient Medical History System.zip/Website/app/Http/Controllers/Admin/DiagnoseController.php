<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\DiagnosisRequest;
use App\Models\Admin\Diagnose;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class DiagnoseController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }



    public  function importCsv(Request $request)
    {
        if (isset($request['file']) && ($request['file']->getClientOriginalExtension() == "csv")) {
            $csvData = file_get_contents($request['file']);
            $rows = array_map("str_getcsv", explode("\n", $csvData));

            $headers = array_shift($rows);
            $index = 0;

            foreach ($rows as $row) {

                if (count($row) !== count($headers)) {

                    continue;
                }


                $data = array_combine($headers, $row);

                $sep = new Diagnose();


                $sep->name = $data['Name'];
                $sep->description = $data['Description'];
                $sep->save();
                event(new OperationOccurred(Auth::user()->person->name, ' تم استيراد تشخيصات طبية  (' . (1 + $index) . ')', null, $data['Name']));

                ++$index;
            }
            Alert::toast( 'تمت اضافة   ' . $index . '     تشخيص طبي بنجاح    ','success');

            return redirect()->route('admin.diagnosis.index')->with('success', 'تمت اضافة   ' . $index . '     تشخيص طبي بنجاح    ');
        }
        ALert::error(' تاكد من اختيار الملف بشكل صحيح يكون بصيغة .csv');
        return redirect()->route('admin.diagnosis.index')->with('error', ' تاكد من اختيار الملف بشكل صحيح يكون بصيغة .csv');
    }

    public function Index()
    {
        $all_Diagnose = Diagnose::all();
        $index = 0;
        return view('A.Diagnosis', compact('all_Diagnose', 'index'));
    }

    public function Store(DiagnosisRequest $request)
    {
        if ($request->validated()) {
            event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة تشخيص  جديد  ', null, $request->input('name')));

            Diagnose::create([
                'name' => $request->input('name'),
                'description' => $request->input('description'),
            ]);
            Alert::toast( 'تم اضافة تشخيص  ' . $request['name'] . '   بنجاح','success');

            return redirect()->route('admin.diagnosis.index')->with('success', 'تم اضافة تشخيص  ' . $request['name'] . '   بنجاح');
        }
    }


    public function Update(DiagnosisRequest $request)
    {
        if ($request->validated()) {
            $diagnose =  Diagnose::findOrFail($request->input('number'));
            if ($diagnose->name != $request->input('name')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم التشخيص  ', $diagnose->name , $request->input('name')));
                $diagnose->name = $request->input('name');

            }
            if ($diagnose->description != $request->input('description')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل وصف التشخيص  ('.$diagnose->name.')', $diagnose->description , $request->input('description')));
                $diagnose->description = $request->input('description');

            }

            $diagnose->save();
            Alert::toast('تم تعديل بيانات تشخيص  ' . $request['name'] . '   بنجاح','success');

            return redirect()->route('admin.diagnosis.index')->with('success', 'تم تعديل بيانات تشخيص  ' . $request['name'] . '   بنجاح');
        }
    }

    public function Search(Request $request)
    {
        $query = $request->get('query');
        $posts = Diagnose::where('name', 'like', "%$query%")->pluck('name');
        return response()->json($posts);
    }
}
