<?php

namespace App\Http\Controllers\Admin;

use App\Events\OperationOccurred;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\LabRequest;
use App\Models\Admin\Building;
use App\Models\Admin\Hospital;
use App\Models\Admin\Primation;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;

class LabController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    public function FileUpload($request)
    {
        $imageName = Carbon::now()->format('YmdHis') . '.' . $request->getClientOriginalExtension();
        $request->move(public_path('images/buildings/logos/'),  $imageName);
        return $imageName;
    }


    public function Index()
    {
        $all_building =  Building::where('building_type', 'مختبر')->orWhere('building_type', 'مختبروأشعة')->get();
        $all_hospitall = Hospital::all();
        $index = 0;
        return view('A.Lab', compact('all_building', 'all_hospitall', 'index'));
    }

    public function Store(LabRequest $request)
    {
        if ($request->validated()) {
            if ($request->input('buid_type') == 0) {
                $role = 4;
                $buidling_type = "مختبر";
            } else if ($request->input('buid_type') == 1) {
                $role = 7;
                $buidling_type = "مختبروأشعة";
            }

            if (isset($request['logo'])) {
                Building::create(
                    [
                        'name' => $request->input('name'),
                        'city' => $request->input('city'),
                        'address' => $request->input('address'),
                        'building_type' => $buidling_type,
                        'hospital_id' => $request->input('hospital'),
                        'logo' => LabController::FileUpload($request['logo']),

                    ]
                );


                $building_Id = Building::where('name', $request['name'])->where('city', $request['city'])->where("building_type", $buidling_type)->first();
                User::create([
                    'email' => $request->input('email'),
                    'password' => Hash::make('123456789'),
                    'phone_number' => $request->input('phone'),
                    'building_id' => $building_Id->id,

                ]);

                $userId = User::where('email', $request->input('email'))->first();

                Primation::create([
                    'user_id' => $userId->id,
                    'role_id' => $role
                ]);
                event(new OperationOccurred(Auth::user()->person->name, 'تم اضافة مختبر  جديد  ', null, $request->input('name')));
            Alert::toast( 'تم اضافة مختبر   ' . $request['name'] . '  بنجاح','success');

                return redirect()->route('admin.lab.index')->with('success', 'تم اضافة مختبر   ' . $request['name'] . '  بنجاح');
            }
            Alert::error('حدث خطا عند اضافة مختبر ');
            return redirect()->route('admin.lab.index')->with('error', 'حدث خطا عند اضافة مختبر ');
        }
    }


    public function Update(LabRequest $request)
    {
        if ($request->validated()) {
            $building = Building::findOrFail($request->input('number'));

            if (isset($request['logo'])) {
                $logo = LabController::FileUpload($request['logo']);
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل شعار المختبر (' . $request->input('name') . ')', $building->logo, $logo));

                $building->logo = $logo;
                $building->save();
            }
            if ($building->name != $request->input('name')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل اسم المختبر ', $building->name, $request->input('name')));
                $building->name = $request->input('name');
            }
            if ($building->city != $request->input('city')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل مدينة المختبر (' . $request->input('name') . ')', $building->city, $request->input('city')));
                $building->city = $request->input('city');
            }
            if ($building->address != $request->input('address')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل عنوان المختبر (' . $request->input('name') . ')', $building->address, $request->input('address')));
                $building->address = $request->input('address');
            }
            if ($building->hospital_id != $request->input('hospital')) {


                if ($request->input('hospital') == '0') {
                    $oldHospital = Hospital::findOrFail($building->hospital_id);

                    event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل  المختبر (' . $request->input('name') . ')', ' مستشفى ' . $oldHospital->name, ' مختبر خارجي '));
                } else if ($building->hospital_id == 0) {
                    $newHospital = Hospital::findOrFail($request->input('hospital'));

                    event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل  المختبر (' . $request->input('name') . ')', ' مختبر خارجي ', ' مستشفى ' . $newHospital->name,));
                } else {
                    $oldHospital = Hospital::findOrFail($building->hospital_id);
                    $newHospital = Hospital::findOrFail($request->input('hospital'));

                    event(new OperationOccurred(Auth::user()->person->name, ' تم تعديل مستشفى المختبر (' . $request->input('name') . ')', ' مستشفى ' . $oldHospital->name, ' مستشفى ' . $newHospital->name));
                }
                $building->hospital_id = $request->input('hospital');
            }

            $user = User::where('building_id', $request->input('number'))->firstOrFail();
            if ($user->email != $request->input('email')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل البريد الالكتروني الخاص بالمختبر (' . $request->input('name') . ')', $building->email, $request->input('email')));

                $user->email = $request->input('email');
            }
            if ($user->phone_number != $request->input('phone')) {
                event(new OperationOccurred(Auth::user()->person->name, 'تم تعديل رقم الهاتف الخاص بالمختبر (' . $request->input('name') . ')', $building->phone_number, $request->input('phone')));

                $user->phone_number = $request->input('phone');

            }
            $user->updated_at = Carbon::now();

            $user->save();
            Alert::toast('   تم تعديل بيانات مختبر    ' . $request['name'] . '   بنجاح    ','success');

            return redirect()->route('admin.lab.index')->with('success', '   تم تعديل بيانات مختبر    ' . $request['name'] . '   بنجاح    ');
        }
    }


    public function Block(Request $request)
    {
        if ($request->input('block') == 0) {

            $block = '1';
            $msg = 'تم اعادة تفعيل عن حساب المختبر  ';
        } else {

            $block = '0';
            $msg = 'تم ايقاف حساب المختبر  ';
        }
        $user = User::findOrFail($request->input('number'));

        event(new OperationOccurred(Auth::user()->person->name, $msg . ' (' .  $user->building->name . ')', $user->status, $block));

        $user->status = $block;
        $user->save();
        Alert::toast( $msg,'success');

        return redirect()->route('admin.lab.index')->with('success', $msg);
    }


    public function Search(Request $request)
    {
        $query = $request->get('query');
        $posts = Building::where('building_type', 'مختبر')->where('name', 'like', "%$query%")->pluck('name');

        return response()->json($posts);
    }
}
