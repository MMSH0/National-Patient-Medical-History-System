<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use RealRashid\SweetAlert\Facades\Alert;


class BackupController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function backup()
    {

        try {
            Artisan::call('backup:run');
            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            Log::error('Backup failed: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }

    }
    public function showRestoreForm()
    {
        // Get a list of all backup files
        $backups = $this->getBackupFiles();

        return view('A.Restore-from-backup', compact('backups'));
    }

    public function restore(Request $request)
    {
        // Run the backup:restore Artisan command
        Artisan::call('backup:restore --backup=latest --no-interaction');
        Alert::toast(  'Database has been successfully restored.','success');

        // Redirect back with a success message
        return redirect()->back()->with('status', 'Database has been successfully restored.');
    }

    private function getBackupFiles()
    {
        // Get all files from the backup disk
        $files = Storage::files('laravel');


        return $files ;
    }
}
