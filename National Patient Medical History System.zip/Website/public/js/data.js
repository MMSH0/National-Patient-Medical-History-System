

// ========================================================================= //
//   Ensure that name is not duplicate while adding
// ========================================================================= //



$(document).ready(function () {
    var input = $('#name');
    var resultsList = $('#SearchResults');
    input.on('input', function () {
            var query = input.val();
            var route = input.data('route');
            $.ajax({
                url: route ,
                method: 'GET',
                data: { query: query },
                success: function (data) {
                    displayResults(data);
                },
                error: function (error) {
                    console.log(error);
                }
            });
        });
    function displayResults(names) {
        resultsList.empty();
        if (names.length > 0) {
            names.forEach(function (name) {
                resultsList.append('<li>' + name + '</li>');
            });
            resultsList.show();
        }
        else {
            resultsList.append('<li>لا يوجد  بهذا الاسم</li>');
        }
    }

});






// ========================================================================= //
//   Ensure that name is not duplicate while editing
// ========================================================================= //




$(document).ready(function () {
    var input = $('#editName');
    var resultsList = $('#SearchResult');
    input.on('input', function () {
            var query = input.val();
            var route = input.data('route');
            $.ajax({
                url: route ,
                method: 'GET',
                data: { query: query },
                success: function (data) {
                    displayResults(data);
                },
                error: function (error) {
                    console.log(error);
                }
            });
        });
    function displayResults(names) {
        resultsList.empty();

        if (names.length > 0) {
            names.forEach(function (name) {
                resultsList.append('<li>' + name + '</li>');
            });

            resultsList.show();

        }
        else {
            resultsList.append('<li>لا يوجد  بهذا الاسم</li>');
        }
    }

});


// ========================================================================= //
//   Patient Tests
// ========================================================================= //


function fetchTests(number) {

    var resultsList = $('.AlllabTests');

    $.ajax({
        url: '/patientPortal/public/lab/tests/'+number+'' ,

        // url: 'http://ahmedsameer2024-001-site1.ktempurl.com/lab/tests/'+number+'' ,

        method: 'GET',
        dataType:'json',
        success: function (data) {

            displayResults(data);
        },
        error: function (error) {
            console.log("error "+number);
        }
    });
    function displayResults(names) {
        resultsList.empty();
        if (names.length > 0) {
            names.forEach(function (name) {
                resultsList.append('<option value="'+name['test_id'] +'">' + name['name'] + '</option>');
            });
            resultsList.show();
        }
        else {
            document.getElementById("SpanMessage").textContent="  لايوجد اي فحص";


        }
    }
}





// ========================================================================= //
//   Patient Rays
// ========================================================================= //


function fetchRays(number) {
    var resultsList = $('.AllRay');
    $.ajax({
        url: '/patientPortal/public/ray/rays/'+number+'' ,
        // url: 'http://ahmedsameer2024-001-site1.ktempurl.com/ray/rays/'+number+'' ,

        method: 'GET',
        dataType:'json',
        success: function (data) {

            displayResults(data);
        },
        error: function (error) {
            console.log(error);
        }
    });
    function displayResults(names) {
        resultsList.empty();
        if (names.length > 0) {
            names.forEach(function (name) {
                resultsList.append('<option value="'+name['ray_id'] +'">' + name['name'] + '</option>');
            });
            resultsList.show();
        }
        else {

            document.getElementById("SpanMessage").textContent="لايوجد اي اشعة";

        }
    }
}



// ========================================================================= //
//      Patient Lab AND Ray Test
// ========================================================================= //


function fetchLabTests(number) {
    var resultsList = $('.AllLabRaysRays');

    $.ajax({
        url: '/patientPortal/public/labray/tests/'+number+'' ,
        // url: 'http://ahmedsameer2024-001-site1.ktempurl.com/labray/tests/'+number+'' ,

        method: 'GET',
        dataType:'json',
        success: function (data) {
            displayResults(data);

        },
        error: function (error) {
            console.log(error);
        }
    });
    function displayResults(names) {
        resultsList.empty();
        if (names.length > 0) {
            names.forEach(function (name) {
                resultsList.append('<option value="'+name['test_id'] +'">' + name['name'] + '</option>');
            });
            resultsList.show();
        }
        else {
            document.getElementById("SpanMessage").textContent="لايوجد اي فحص";
        }
    }
}





// ========================================================================= //
//   Patient Lab AND Ray Rays
// ========================================================================= //


function fetchLabRays(number) {
    var resultsList = $('.AllLabRaysRays');
    $.ajax({
        url: '/patientPortal/public/labray/rays/'+number+'' ,
        // url: 'http://ahmedsameer2024-001-site1.ktempurl.com/labray/rays/'+number+'' ,

        method: 'GET',
        dataType:'json',
        success: function (data) {
            displayResults(data);
        },
        error: function (error) {
            console.log(error);
        }
    });
    function displayResults(names) {
        resultsList.empty();
        if (names.length > 0) {
            names.forEach(function (name) {
                resultsList.append('<option value="'+name['ray_id'] +'">' + name['name'] + '</option>');
            });
            resultsList.show();
        }
        else {
            document.getElementById("SpanMessage").textContent="  لايوجد اي اشعة";
        }
    }
}





//// ========================= DOCTOR ==============================================/
//// ========================= PatientTest ==============================================/


function fetchPatientTest() {
    var resultsList = $('.AllDoctorTest');
    var resultList = $('.AllDoctorTestType');

    $.ajax({
        url: '/patientPortal/public/doctor/test/search/tests' ,
        // url: 'http://ahmedsameer2024-001-site1.ktempurl.com/doctor/test/search/tests' ,

        method: 'GET',
        dataType:'json',
        success: function (data) {
            console.log(data);
            displayResults(data);

        },
        error: function (error) {
            console.log(error);
        }
    });

    function displayResults(names) {
        resultsList.empty();
        if (names.length > 0) {
            names.forEach(function (name) {
                resultList.append('<option value="'+name['id'] +'">' + name['name'] + '</option>');
                resultsList.append('<option value="'+name['typeId'] +'">' + name['typeName'] + '</option>');
            });
            resultsList.show();
            resultList.show();
        }
        else {
            document.getElementById("SpanMessage").textContent="  لايوجد اي اشعة";
        }
    }


}


//// ========================= DOCTOR ==============================================/
//// ========================= Patientray ==============================================/

function fetchPatientRay() {
    var resultsList = $('.AllDoctorRay');

    $.ajax({
        url: '/patientPortal/public/doctor/test/search/rays' ,
        // url: 'http://ahmedsameer2024-001-site1.ktempurl.com/doctor/test/search/rays' ,

        method: 'GET',
        dataType:'json',
        success: function (data) {
            console.log(data);
            displayResults(data);

        },
        error: function (error) {
            console.log(error);
        }
    });

    function displayResults(names) {
        resultsList.empty();
        if (names.length > 0) {
            names.forEach(function (name) {
                resultsList.append('<option value="'+name['id'] +'">' + name['name'] + '</option>');
            });
            resultsList.show();
        }
        else {
            document.getElementById("SpanMessage").textContent="  لايوجد اي اشعة";
        }
    }


}



//// ========================= DOCTOR ==============================================/
//// ========================= Tests ==============================================/

function fetchDoctorTests() {

    $.ajax({
        url: '/patientPortal/public/doctor/test/search/rays' ,
        // url: 'http://ahmedsameer2024-001-site1.ktempurl.com/doctor/test/search/rays' ,

        method: 'GET',
        dataType:'json',
        success: function (data) {
            displayResults(data);

        },
        error: function (error) {
            console.log(error);
        }
    });

    function displayResults(names) {
        resultsList.empty();
        if (names.length > 0) {
            names.forEach(function (name) {
                // testData.bloodTests.append(name);
            });
            resultsList.show();
        }
        else {
            document.getElementById("SpanMessage").textContent="  لايوجد اي اشعة";
        }
    }


}
