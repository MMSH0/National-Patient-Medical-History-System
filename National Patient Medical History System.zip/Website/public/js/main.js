$(function () {
    // ========================================================================= //
    //    Add remove class active has menu
    // ========================================================================= //

    jQuery(".has-submenu").click(function () {
        $(".has-submenu").removeClass("active");
        $(this).toggleClass("active");
    });

    // ========================================================================= //
    //    Toggle Aside Menu
    // ========================================================================= //

    jQuery(".hamburger").click(function () {
        jQuery("body").toggleClass("sidebar-toggled");
        jQuery("#main-wrapper").toggleClass("menu-toggle");
        jQuery(".left-panel").toggleClass("collapsed");
    });

    // ========================================================================= //
    //    Set attibute isnide body (Light)
    // ========================================================================= //

    jQuery("body").attr({
        "data-typography": "rubik",
        //'data-sidebar-style': "full",
        "data-sidebar-position": "fixed",
        "data-header-position": "fixed",
        // 'data-nav-headerbg': 'primary_color_1',
        // 'data-headerbg': 'primary_color_1',
        // 'data-primary': 'primary_color_1',
        //'data-sibebartext': 'primary_color_2',
        //'data-sibebarbg': 'primary_color_2',
        // 'data-theme-version': 'light',
        // 'data-header-logo': "fixed",
        //'data-layout': 'vertical',
        // 'data-topbar': 'light',
        // 'data-sidebar': "light",
        //'data-container': "boxed",
        // 'layout-positions': "full",
    });

    // ========================================================================= //
    //    Set attibute isnide body (Dark)
    // ========================================================================= //

    if (jQuery("body").hasClass("dark")) {
        jQuery("body").attr("data-theme-version", "dark");
        jQuery("body").attr("data-nav-headerbg", "primary_color_3");
        jQuery("body").attr("data-headerbg", "primary_color_3");
        jQuery("body").attr("data-sibebarbg", "primary_color_3");
        jQuery("body").attr("data-primary", "primary_color_3");
        jQuery("body").attr("data-sibebartext", "primary_color_3");
        jQuery("body").attr("data-topbar", "dark");
        jQuery("body").attr("data-sidebar", "dark");
        jQuery(".brand-title").attr("src", "assets/images/logo-dark.png");
    }

    // ========================================================================= //
    //   Top bar change
    // ========================================================================= //

    if ($(".auth").hasClass("dark")) {
        $(".logo img").attr("src", "assets/images/logo-dark.png");
    }

    // ========================================================================= //
    //    resize
    // ========================================================================= //

    function resize() {
        if (window.matchMedia("(max-width: 767px)").matches) {
            $("body").attr("data-sidebar-style", "overlay");
        } else if (window.matchMedia("(max-width: 1199px)").matches) {
            $("body").attr("data-sidebar-style", "mini");
        } else {
            // $('body').attr('data-sidebar-style', 'full');
            // $("#main-wrapper").removeClass('mini');
        }
    }

    resize();

    jQuery(window).resize(function () {
        resize();
    });
});

// ========================================================================= //
//    upload image in drag
// ========================================================================= //

function showPreview(event) {
    if (event.target.files.length > 0) {
        var src = URL.createObjectURL(event.target.files[0]);
        var preview = document.getElementById("file-ip-1-preview");
        preview.src = src;
        preview.style.display = "block";
    }
}

// ========================================================================= //
//   Preview Pictures
// ========================================================================= //

$(".widget-3 input[type='file']").on("change", function () {
    $(".widget-3").addClass("custom-text");
});

// ========================================================================= //
//   Date Range
// ========================================================================= //

$('input[name="daterange"]').daterangepicker(
    {
        opens: "right",
    },
    function (start, end, label) {
        console.log(
            "A new date selection was made: " +
                start.format("YYYY-MM-DD") +
                " to " +
                end.format("YYYY-MM-DD")
        );
    }
);

// ========================================================================= //
//   Button Add Ray
// ========================================================================= //

$("#butonAddRay").click(function () {
    var structure = `
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <select id="validationCustom05" name="testName[]" id="options" class="form-control form-select AllRay" required>
            </select>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <input id="validationCustom05" name="result[]" type="file" class="form-control" placeholder="النتيجة" required>
        </div>
    </div>
    <div class="row">
    <div class="form-group">
        <textarea id="validationCustom05" name="report[]" type="file" class="form-control" placeholder="النتيجة" required ></textarea>
    </div>
</div>
</div>
<hr/>
`;
    $(document).ready(function () {
        fetchRays(document.getElementById("number").value);
    });
    $(".addRay").append(structure);

    // $('select').selectpicker();
});

// ========================================================================= //
//  Button Add Test
// ========================================================================= //

$("#butonAddTest").click(function () {
    var structure = `
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <select id="validationCustom05" name="testName[]" id="options" class="form-control form-select AlllabTests" required>
            </select>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <input id="validationCustom05" name="result[]" type="text" class="form-control" placeholder="النتيجة" required>
        </div>
    </div>

</div>
<hr/>
`;

    $(document).ready(function () {
        fetchTests(document.getElementById("number").value);
    });
    $(".addTest").append(structure);

    // $('select').selectpicker();
});

// ========================================================================= //
//   Button Add Lab And Ray - Test
// ========================================================================= //

$("#butonAddLabRaysTest").click(function () {
    var structure = `
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <select id="validationCustom05" name="testName[]" id="options" class="form-control form-select AllLabRaysRays" required>
            </select>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <input id="validationCustom05" name="result[]" type="text" class="form-control" placeholder="النتيجة" required>
        </div>
    </div>

</div>
<hr/>
`;
    $(document).ready(function () {
        fetchLabTests(document.getElementById("number").value);
    });
    $(".addLabRayTest").append(structure);

    // $('select').selectpicker();
});

// ========================================================================= //
//  Button Add Lab And Ray - Ray
// ========================================================================= //

$("#butonAddLabRays").click(function () {
    var structure = `
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <select id="validationCustom05" name="testName[]" id="options" class="form-control form-select AllLabRaysRays" required>
            </select>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <input id="validationCustom05" name="result[]" type="file" class="form-control" placeholder="النتيجة" required>
        </div>
    </div>
    <div class="row">
    <div class="form-group">
        <textarea id="validationCustom05" name="report[]" type="file" class="form-control" placeholder="النتيجة" required ></textarea>
    </div>
</div>
</div>

</div>
<hr/>
`;

    $(document).ready(function () {
        fetchLabRays(document.getElementById("number").value);
    });
    $(".addLabRay").append(structure);

    // $('select').selectpicker();
});

// ========================================================================= //
//  Button Add Doctor
//  add test for Patient
// ========================================================================= //

$("#butonAddDoctorTest").click(function () {
    $(document).ready(function () {
        fetchPatientTest();
    });

    var structure = `
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <select id="validationCustom05" name="testName[]" id="options" class="form-control form-select AllDoctorTest" required>
            </select>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <select id="validationCustom05" name="result[]" type="text" class="form-control form-select AllDoctorTestType"  required>
            </select>
        </div>
    </div>

</div>
<hr/>
`;

    $("#addDoctorTest").append(structure);

    // $('select').selectpicker();
});

// ========================================================================= //
//  Button Add Doctor
//  add ray for Patient
// ========================================================================= //

$("#butonAddDoctorRay").click(function () {
    $(document).ready(function () {
        fetchPatientRay();
    });

    var structure = `
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <select id="validationCustom05" name="rayName[]" id="options" class="form-control form-select AllDoctorRay" required>
            </select>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <input id="validationCustom05" name="result[]" type="text" class="form-control" placeholder="ملاحظة" required/>

        </div>
    </div>

</div>
<hr/>
`;

    $("#addDoctorRay").append(structure);

    // $('select').selectpicker();
});

// ========================================================================= //
//  Change dates patient
// ========================================================================= //

$(function () {
    $('input[name="dates"]').daterangepicker(
        {
            singleDatePicker: true,
            showDropdowns: true,
            minYear: 1901,
            maxYear: parseInt(moment().format("YYYY"), 10),
        },
        function (start, end, label) {
            var years = moment().diff(start, "years");
        }
    );
});

// ========================================================================= //
//   refrech select picker inside modal
// ========================================================================= //
$(".selectRefresh").on("shown", function () {
    $(".selectpicker").selectpicker("refresh");
});

// ========================================================================= //
//   Responsive
// ========================================================================= //

function resize() {
    if (window.matchMedia("(max-width: 1199px)").matches) {
        $(".has-submenu").removeClass("active");
    }
}

resize();

jQuery(window).resize(function () {
    resize();
});

jQuery(function ($) {
    var path = window.location.href;
    $("ul li a").each(function () {
        if (
            window.matchMedia("(max-width: 1199px) and (max-width: 1199px)")
                .matches
        ) {
            if (this.href === path) {
                if ($(this).parent().hasClass("has-submenu")) {
                    $(this).parent().addClass("active-submenu");
                } else {
                    $(this)
                        .parent()
                        .parent()
                        .parent()
                        .addClass("active-submenu");
                }
            }
        }
    });
});

/*  ==========================================
    PROGRESS MESSAGE
* ========================================== */

// document.addEventListener("DOMContentLoaded", function () {
//     const successAlert = document.getElementById("successAlert");
//     const progressBar = document.getElementById("progressBar");

//     let timeLeft = 4;
//     let progress = 0;

//     const updateProgressBar = function () {
//         timeLeft--;

//         if (timeLeft <= 0) {
//             clearInterval(progressInterval);
//             successAlert.style.display = "none";
//         }

//         progress += 100 / 10; // Increment by (100 / countdown time in seconds)
//         progressBar.style.width = progress + "%";
//     };

//     const progressInterval = setInterval(updateProgressBar, 1000);
// });
// document.addEventListener("DOMContentLoaded", function () {
// const successAlert = document.getElementById("successAlert");
// successAlert.style.display = "none"; // Hide the alert initially

//   const Toast = Swal.mixin({
//     toast: true,
//     position: "top-start",
//     showConfirmButton: false,
//     timer: 3000,
//     timerProgressBar: true,
//     didOpen: (toast) => {
//       toast.onmouseenter = Swal.stopTimer;
//       toast.onmouseleave = Swal.resumeTimer;
//     }
//   });

//   function showToast(icon, message) {
//     Toast.fire({
//       icon: icon,
//       title: message
//     });
//   }
// });

/*  ==========================================
    FRONTED VALDITION
* ========================================== */

(function () {
    "use strict";

    var forms = document.querySelectorAll(".needs-validation");

    Array.prototype.slice.call(forms).forEach(function (form) {
        form.addEventListener(
            "submit",
            function (event) {
                var inputField = document.getElementById("name");
                var SpanMessage = document.getElementById("SpanMessage");
                var listItems = document.querySelectorAll("#SearchResults li");

                var isNameUsed = Array.from(listItems).some(
                    (item) => item.textContent === inputField.value
                );

                if (!form.checkValidity() || isNameUsed) {
                    event.preventDefault();
                    event.stopPropagation();
                    form.classList.add("was-validated");

                    if (isNameUsed) {
                        inputField.classList.add("error");
                        SpanMessage.textContent =
                            " تم استخدم هذا الاسم من قبل !! ";
                    } else {
                        // inputField.classList.remove("error");
                        // SpanMessage.textContent = "";
                    }
                }
            },
            false
        );
    });
})();

/*  ==========================================
    SHOW UPLOADED IMAGE
* ========================================== */
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $("#imageResult").attr("src", e.target.result);
        };
        reader.readAsDataURL(input.files[0]);
    }
}

$(function () {
    $("#upload").on("change", function () {
        readURL(input);
    });
});

/*  ==========================================
    SHOW UPLOADED IMAGE NAME
* ========================================== */
var input = document.getElementById("upload");
var infoArea = document.getElementById("upload-label");

input.addEventListener("change", showFileName);
function showFileName(event) {
    var input = event.srcElement;
    var fileName = input.files[0].name;
    // infoArea.textContent = "File name: " + fileName;
}

/*  ==========================================
    SHOW UPLOADED IMAGE
* ========================================== */
function getURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $("#backImageResult").attr("src", e.target.result);
        };
        reader.readAsDataURL(input.files[0]);
    }
}

$(function () {
    $("#backUpload").on("change", function () {
        getURL(input);
    });
});

/*  ==========================================
    SHOW UPLOADED IMAGE NAME
* ========================================== */
var input = document.getElementById("backUpload");

/*  ==========================================
    remove all
* ========================================== */
function removeAllInClass(className) {
    var elements = document.getElementsByClassName(className);

    document.getElementById("SpanMessage").textContent = "";

    for (var i = 0; i < elements.length; i++) {
        var element = elements[i];
        while (element.firstChild) {
            element.removeChild(element.firstChild);
        }
    }
}

$(document).ready(function () {
    $("#selectHospital").select2();

    $("#selectHospital").select2({
        placeholder: "اسم المستشفى",
    });
    $("#selectClinc").select2();

    $("#selectClinc").select2({
        placeholder: "اسم العيادة",
    });

});
