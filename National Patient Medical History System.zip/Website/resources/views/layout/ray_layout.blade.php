<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ray Dashboard </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" href="{{asset('favicon-32x32.png')}}">
    <!-- Base Styling  -->
    <link rel="stylesheet" href="{{ asset('css/select2.css') }}">

    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/fonts.css') }}">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">


</head>

<body dir="rtl">
    <div id="main-wrapper" class="show">

        <!-- start section sidebar -->
        <aside class="left-panel nicescroll-box">
            <nav class="navigation">
                <ul class="list-unstyled main-menu">



                    <li class="has-submenu @if (Route::currentRouteName() == 'ray.add') active @endif">
                        <a href="{{ route('ray.add') }}">
                            <i class="fas fa-file-invoice"></i>
                            <span class="nav-label">إضافة نتيجة أشعة</span>

                        </a>
                    </li>

                    <li class="has-submenu @if (Route::currentRouteName() == 'ray.index') active @endif">
                        <a href="{{ route('ray.index') }}">
                            <i class="fas fa-file-invoice"></i>
                            <span class="nav-label"> جميع الاشعات</span>
                        </a>
                    </li>


            </nav>
            <div class="sidebar-widgets">
                <div class="top-sidebar box-shadow mx-25 m-b-30 p-b-20 text-center">
                    <a href="#">
                        <img loading="lazy" src="{{ asset('images/appointement.svg') }}" class="side-img"
                        alt="img" />
                    </a>
                    <a href="#">
                        <h4 class="text-primary mb-0">بوابة المرضى الاكترونية</h4>
                    </a>
                </div>
                <div class="copyright text-center">
                    <p class="mb-0">Ray Dashboard</p>
                    <p class="mb-0">© {{ now()->year }}</p>
                </div>
            </div>
        </aside>
        <!-- End section sidebar -->


        <!-- start logo components -->
        <div class="nav-header">
            <div class="brand-logo">
                <a href="#"> <img loading="lazy" class="logo-tabib" src="{{ asset('images/download.png') }}" alt=""></a>
                <a href="#"><img loading="lazy" class="brand-title" src="{{  asset('images/logo.png')  }}" alt=""></a>
            </div>
        </div>
        <!-- End logo components -->


        <!-- start section header -->
        <div class="header">
            <header class="top-head container-fluid">
                <div class="nav-control">
                    <div class="hamburger">
                        <span class="line"></span><span class="line"></span><span class="line"></span>
                    </div>
                </div>
                <div class="header-right">
                    <div class="fullscreen notification_dropdown widget-5">
                        <div class="full">
                            <a class="text-dark" href="#!" onclick="javascript:toggleFullScreen()">
                                <i class="fas fa-expand"></i>
                            </a>
                        </div>
                    </div>

                    <div class="my-account-wrapper widget-7">
                        <div class="account-wrapper">
                            <div class="account-control">
                                <a class="login header-profile" href="#" title="Sign in">
                                    <div class="header-info">
                                        <span> {{ Auth::user()->building->name }}  </span>
                                        @if ( Auth::user()->building->hospital_id == 0)
                                            <small> مركز خاص </small>
                                        @else
                                            <small> {{Auth::user()->building->hospital->name  }} </small>
                                        @endif
                                    </div>
                                    <img loading="lazy" src="{{ asset('images/buildings/logos/') }}/{{ Auth::user()->building->logo }}" alt="people">
                                </a>
                                <div class="account-dropdown-form dropdown-container">
                                    <div class="form-content">
                                        <a href="{{ route('ray.profile') }}">
                                            <i class="far fa-user"></i>
                                            <span class="ml-2">الحساب</span>
                                        </a>

                                        @auth
                                            <a href="{{ route('logout') }}">
                                                <i class="fas fa-sign-in-alt"></i>
                                                <span class="ml-2">تسجيل الخروج </span>
                                            </a>
                                        @endauth
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
        </div>
        <!-- End section header -->
        @yield('content')




        <!-- start section footer -->
        <div class="footer">
            <div class="copyright">
                <p class="mb-0">Copyright © Designed &amp; Developed by AHMED SAMEER  {{ now()->year }}
                </p>
            </div>
        </div>
        <!-- End section footer -->



     <!-- JQuery v3.5.1 -->
     <script src="{{ asset('/plugins/jquery/jquery.min.js') }}" defer></script>
     <script src="{{ asset('/js/jquery-3.6.0.min.js') }}" defer></script>
    <script src="{{ asset('plugins/popper/popper.min.js') }}" defer></script>

    <script src="{{ asset('plugins/bootstrap/js/bootstrap.min.js') }}" defer></script>

    <script src="{{ asset('plugins/moment/moment.min.js') }}" defer></script>

    <script src="{{ asset('plugins/daterangepicker/daterangepicker.min.js') }}" defer></script>

    <script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}" defer></script>
    <script src="{{ asset('js/init-tdatatable.js') }}" defer></script>

    <script src="{{ asset('plugins/chart/chart/Chart.min.js') }}" defer></script>
    <script src="{{ asset('js/charts-custom.js') }}" defer></script>

    <script src="{{ asset('js/toggleFullScreen.js') }}" defer></script>
    <script src="{{ asset('js/main.js') }}" defer></script>
    <script src="{{ asset('js/option-themes.js') }}" defer></script>
    <script src="{{ asset('js/data.js') }}" defer></script>

    <script src="{{ asset('js/select2.js') }}" defer></script>

    {{-- <script src="{{ asset('../resources') }}/js/sweetalert2.min.js" defer></script> --}}
    @include('sweetalert::alert')

</body>

</html>
