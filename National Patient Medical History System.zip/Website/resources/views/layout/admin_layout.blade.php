<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" href="{{ asset('favicon-32x32.png') }}">
    <!-- Base Styling  -->
    <link rel="stylesheet" href="{{ asset('css/select2.css') }}">

    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/fonts.css') }}">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">


</head>

<body dir="rtl">
    <div id="main-wrapper" class="show">


        <!-- start section sidebar -->
        <aside class="left-panel nicescroll-box">
            <nav class="navigation">
                <ul class="list-unstyled main-menu">
                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.index') active @endif">
                        <a href="{{ route('admin.index') }}">
                            <i class="fas fa-th-large"></i>
                            <span class="nav-label">لوحةالتحكم</span>
                        </a>
                    </li>
                    <li class="has-submenu  @if (Route::currentRouteName() == 'admin.specialty.index') active @endif">
                        <a href="{{ route('admin.specialty.index') }}">
                            <i class="fas fa-tag"></i>
                            <span class="nav-label">التخصصات الطبية</span>
                        </a>
                    </li>
                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.hospital.index') active @endif">
                        <a href="{{ route('admin.hospital.index') }}">
                            <i class="fas fa-heartbeat"></i>
                            <span class="nav-label">المستشفيات</span>
                        </a>
                    </li>
                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.clinc.index') active @endif">
                        <a href="{{ route('admin.clinc.index') }}">
                            <i class="fas fa-book-medical"></i>
                            <span class="nav-label">العيادات</span>
                        </a>
                    </li>
                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.lab.index') active @endif">
                        <a href="{{ route('admin.lab.index') }}">
                            <i class="fas fa-file-invoice"></i>
                            <span class="nav-label">المختبرات</span>
                        </a>
                    </li>
                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.raycenter.index') active @endif">
                        <a href="{{ route('admin.raycenter.index') }}">
                            <i class="fas fa-file-invoice"></i>
                            <span class="nav-label">مراكز الأشعة</span>
                        </a>
                    </li>
                    <li class="has-submenu  @if (Route::currentRouteName() == 'admin.doctor.create' || Route::currentRouteName() == 'admin.doctor.index') active-submenu active @endif">
                        <a href="javascript:void()" class="has-arrow mm-collapsed">
                            <i class="fas fa-user-md"></i>
                            <span class="nav-label">الاطباء</span>
                        </a>
                        <ul class="list-unstyled mm-collapse">
                            <li><a href="{{ route('admin.doctor.create') }}">اضافة طبيب</a></li>
                            <li><a href="{{ route('admin.doctor.index') }}">جميع الاطباء</a></li>
                        </ul>
                    </li>
                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.patient.index') active @endif">
                        <a href="{{ route('admin.patient.index') }}">
                            <i class="fas fa-user"></i>
                            <span class="nav-label"> المرضى</span>
                        </a>
                    </li>
                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.patient.auth') active @endif">
                        <a href="{{ route('admin.patient.auth') }}">
                            <i class="fas fa-user"></i>
                            <span class="nav-label">مصادقة الحسابات</span>
                        </a>
                    </li>
                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.medicen.index') active @endif">
                        <a href="{{ route('admin.medicen.index') }}">
                            <i class="fas fa-pills"></i>
                            <span class="nav-label">العلاجات</span>
                        </a>
                    </li>
                    <li class="has-submenu  @if (Route::currentRouteName() == 'admin.test.create' || Route::currentRouteName() == 'admin.test.index') active-submenu active @endif">
                        <a href="javascript:void()" class="has-arrow mm-collapsed">
                            <i class="fas fa-heartbeat"></i>
                            <span class="nav-label">الفحوصات</span>
                        </a>
                        <ul class="list-unstyled mm-collapse">
                            <li><a href="{{ route('admin.test.create') }}">اضافة فحص</a></li>
                            <li><a href="{{ route('admin.test.index') }}">جميع الفحوصات</a></li>
                            <li><a href="{{ route('admin.test.type.index') }}">جميع انواع الفحوصات</a></li>
                        </ul>
                    </li>

                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.radiology.create' || Route::currentRouteName() == 'admin.radiology.index') active-submenu active @endif">
                        <a href="javascript:void()" class="has-arrow mm-collapsed">
                            <i class="fas fa-table"></i>
                            <span class="nav-label">الأشعة</span>
                        </a>
                        <ul class="list-unstyled mm-collapse">
                            <li><a href="{{ route('admin.radiology.create') }}">اضافة أشعة</a></li>
                            <li><a href="{{ route('admin.radiology.index') }}">جميع الأشعة</a></li>
                        </ul>
                    </li>


                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.chronicdisease.index') active @endif">
                        <a href="{{ route('admin.chronicdisease.index') }}">
                            <i class="fas fa-file-invoice"></i>
                            <span class="nav-label">الامراض المزمنة</span>
                        </a>
                    </li>

                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.surgery.index') active @endif">
                        <a href="{{ route('admin.surgery.index') }}">
                            <i class="fas fa-file-invoice"></i>
                            <span class="nav-label"> قسم العمليات </span>
                        </a>
                    </li>

                    <li class="has-submenu @if (Route::currentRouteName() == 'admin.diagnosis.index') active @endif">
                        <a href="{{ route('admin.diagnosis.index') }}">
                            <i class="fas fa-file-invoice"></i>
                            <span class="nav-label"> التشخيصات </span>
                        </a>
                    </li>
                    @if (isset($usertype))

                        @if ($usertype == 'superadmin')
                            <li class="has-submenu">
                                <a href="javascript:void()" class="has-arrow mm-collapsed">
                                    <i class="fas fa-cog"></i>
                                    <span class="nav-label">الاعدادات</span>
                                </a>
                                <ul class="list-unstyled mm-collapse">
                                    <li><a href="{{ route('admin.user.index') }}"> اضافة مستخدم </a></li>
                                    <li>
                                        <a href="{{ route('admin.users.index') }}"> المستخدمون </a>
                                    </li>
                                    <li>
                                        <a href="{{ route('admin.backup.index') }}">نسخة احتياطية</a>
                                    </li>
                                    <li>
                                        <a href="{{ route('admin.log.index') }}"> السجل </a>
                                    </li>
                                </ul>
                            </li>
                        @endif
                    @endif

                </ul>
            </nav>
            <div class="sidebar-widgets">
                <div class="top-sidebar box-shadow mx-25 m-b-30 p-b-20 text-center">
                    <a href="#">
                        <img loading="lazy" src="{{ asset('images/appointement.svg') }}" class="side-img"
                            alt="img" />
                    </a>
                    <a href="#">
                        <h4 class="text-primary mb-0">بوابة المرضى الاكترونية</h4>
                    </a>
                </div>
                <div class="copyright text-center">
                    <p class="mb-0">Admin Dashboard</p>
                    <p class="mb-0">© {{ now()->year }}</p>
                </div>
            </div>
        </aside>
        <!-- End section sidebar -->


        <!-- start logo components -->
        <div class="nav-header">
            <div class="brand-logo">
                <a href="{{ route('admin.index') }}"> <img loading="lazy" class="logo-tabib"
                        src="{{ asset('images/download.png') }}" alt=""></a>
                <a href="{{ route('admin.index') }}"><img loading="lazy" class="brand-title"
                        src="{{ asset('images/logo.png') }}" alt=""></a>
            </div>
        </div>
        <!-- End logo components -->


        <!-- start section header -->
        <div class="header">
            <header class="top-head container-fluid">
                <div class="nav-control">
                    <div class="hamburger">
                        <span class="line"></span><span class="line"></span><span class="line"></span>
                    </div>
                </div>
                <div class="header-right">
                    <div class="fullscreen notification_dropdown widget-5">
                        <div class="full">
                            <a class="text-dark" href="#!" onclick="javascript:toggleFullScreen()">
                                <i class="fas fa-expand"></i>
                            </a>
                        </div>
                    </div>

                    <div class="my-account-wrapper widget-7">
                        <div class="account-wrapper">
                            <div class="account-control">
                                <a class="login header-profile" href="#" title="Sign in">
                                    <div class="header-info">
                                        <span> {{ Auth::user()->person->name }} </span>

                                        @if (isset($usertype))
                                            @if ($usertype == 'superadmin')
                                                <small>مدير النظام</small>
                                            @else
                                                <small>مشرف</small>
                                            @endif
                                        @endif

                                    </div>
                                    <img loading="lazy" src="{{ asset('images/client.jpg') }}" alt="people">
                                </a>
                                <div class="account-dropdown-form dropdown-container">
                                    <div class="form-content">
                                        <a href="{{ route('admin.profile') }}">
                                            <i class="far fa-user"></i>
                                            <span class="ml-2">الحساب</span>
                                        </a>

                                        @auth
                                            <a href="{{ route('logout') }}">
                                                <i class="fas fa-sign-in-alt"></i>
                                                <span class="ml-2">تسجيل الخروج </span>
                                            </a>
                                        @endauth

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
        </div>
        <!-- End section header -->

        <div id="main-content"> @yield('content')</div>

        <!-- start section footer -->
        <div class="footer">
            <div class="copyright">
                <p class="mb-0">Copyright © Designed &amp; Developed by AHMED SAMEER</a>
                    {{ now()->year }}
                </p>
            </div>
        </div>
        <!-- End section footer -->


    </div>


    <!-- JQuery v3.5.1 -->
    <script src="{{ asset('/plugins/jquery/jquery.min.js') }}" defer></script>
    <script src="{{ asset('/js/jquery-3.6.0.min.js') }}" defer></script>
    <script src="{{ asset('plugins/popper/popper.min.js') }}" defer></script>

    <script src="{{ asset('plugins/bootstrap/js/bootstrap.min.js') }}" defer></script>

    <script src="{{ asset('plugins/moment/moment.min.js') }}" defer></script>

    <script src="{{ asset('plugins/daterangepicker/daterangepicker.min.js') }}" defer></script>

    <script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}" defer></script>
    <script src="{{ asset('js/init-tdatatable.js') }}" defer></script>

    <script src="{{ asset('plugins/chart/chart/Chart.min.js') }}" defer></script>
    <script src="{{ asset('js/charts-custom.js') }}" defer></script>

    <script src="{{ asset('js/toggleFullScreen.js') }}" defer></script>
    <script src="{{ asset('js/main.js') }}" defer></script>
    <script src="{{ asset('js/option-themes.js') }}" defer></script>
    <script src="{{ asset('js/data.js') }}" defer></script>

    <script src="{{ asset('js/select2.js') }}" defer></script>

    @include('sweetalert::alert')




</body>

</html>
