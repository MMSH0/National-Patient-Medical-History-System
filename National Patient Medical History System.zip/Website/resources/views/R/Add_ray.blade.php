@extends('layout.ray_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_prescription main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">اضافة نتيجة اشعة</h4>
                            <p class="mb-0">اضافة اشعة جديد</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/test_information.html">جميع المرضى</a></li>
                            <li class="breadcrumb-item active"><a href="#">اضافة اشعة</a>
                            </li>
                        </ol>
                    </div>
                </div>


                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow mb-4">
                            <div class="card-header">
                                <h4 class="card-title">معلومات المريض </h4>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="{{ route('ray.search') }}" class="form-inline">
                                    @csrf
                                    <div class="form-group mx-sm-3 mb-2">
                                        <label class="sr-only testLabel">البحث بالاسم</label>
                                        <input type="text" name="personalName" class="form-control"
                                            placeholder="البحث بالاسم">
                                    </div>
                                    <div class="form-inline" style="display: inline-flex">
                                        <div class="form-group mx-sm-3 mb-2">
                                            <label class="sr-only testLabel">رقم الهوية</label>
                                            <input type="number" name="identityCard" class="form-control"
                                                placeholder="xxxxxxxxxxxxxxxx">
                                        </div>
                                        <div class="form-group mx-sm-3 mb-2">
                                            <label class="sr-only testLabel">رقم الهاتف</label>
                                            <input type="number" name="numberPhone" id="numberPhone" class="form-control"
                                                placeholder="7xxxxxxxxxxxxx">
                                        </div>
                                        <button
                                            style="height: 3rem;
                                        align-self: flex-end;"
                                            type="submit" class="btn btn-primary mb-2">بحث </button>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>




                    @if (isset($all_patient))
                        <div class="card shadow">

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">ID</th>
                                                <th scope="col">صورة المريض</th>
                                                <th scope="col">اسم المريض</th>
                                                <th scope="col"> الجنس </th>
                                                <th scope="col"> العمر </th>
                                                <th scope="col"> رقم الهاتف </th>
                                                <th scope="col"> رقم الهوية </th>
                                                <th scope="col"> Action </th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach ($all_patient as $patient)
                                                <tr>
                                                    <td>#{{ ++$index }}</td>
                                                    @if ($patient->gender == 0 || !isset($patient->img))
                                                        <td><img loading="lazy" class="rounded-image"
                                                                src="{{ asset('images/client.jpg') }}"></td>
                                                    @else
                                                        <td><img loading="lazy" class="rounded-image"
                                                                src="{{ asset('patient/profile')}}/{{ $patient->img }}">
                                                        </td>
                                                    @endif
                                                    <td>{{ $patient->name }} </td>
                                                    @if ($patient->gender == 0)
                                                        <td> انثى </td>
                                                    @else
                                                        <td> ذكر </td>
                                                    @endif
                                                    <td> {{ \Carbon\Carbon::parse($patient->birthDate)->age }}</td>

                                                    <td> {{ $patient->phone_number }}</td>
                                                    <td> {{ $patient->indentityCardNumber }}</td>

                                                    <td class="text-start">
                                                        <button type="button" class="btn btn-primary"
                                                            onclick="populateEditModal('{{ $patient->patientId }}','{{ $patient->name }}');removeAllInClass('addRay');"
                                                            data-bs-toggle="modal" data-bs-target="#add_test"> عرض </button>
                                                    </td>
                                                </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    @endif

                    @if (isset($users))
                        <div class="card shadow">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">ID</th>
                                                <th scope="col">اسم المريض</th>
                                                <th scope="col">صورة المريض</th>
                                                <th scope="col"> الجنس </th>
                                                <th scope="col"> العمر </th>
                                                <th scope="col"> رقم الهاتف </th>
                                                <th scope="col"> رقم الهوية </th>
                                                <th scope="col"> Action </th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach ($users as $user)
                                                <tr>


                                                    <td>#{{ ++$index }}</td>

                                                        @if ($user->person->gender == 0 || !isset($user->person->img))
                                                            <td><img loading="lazy" class="rounded-image"
                                                                    src="{{ asset('images/client.jpg') }}">
                                                            </td>
                                                        @else
                                                            <td><img loading="lazy" class="rounded-image"
                                                                    src="{{ asset('patient/profile')}}/{{ $user->person->img }}">
                                                            </td>
                                                        @endif
                                                        <td> {{ $user->person->name }}</td>

                                                        @if ($user->person->gender == 0)
                                                            <td> انثى </td>
                                                        @else
                                                            <td> ذكر </td>
                                                        @endif

                                                        <td> {{ \Carbon\Carbon::parse($user->person->birthDate)->age }}
                                                        </td>
                                                        <td>{{ $user->phone_number }} </td>
                                                        <td>{{ $user->person->indentityCardNumber }} </td>
                                                        <td class="text-start">
                                                            <button type="button" class="btn btn-primary"
                                                                onclick="populateEditModal('{{ $user->person->id }}','{{ $user->person->name }}'); removeAllInClass('addRay');"
                                                                data-bs-toggle="modal" data-bs-target="#add_test"> عرض
                                                            </button>
                                                        </td>
                                                </tr>

                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- End section content -->



    <!-- Add Test -->
    <div class="modal fade selectRefresh" id="add_test" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة نتائج الاشعة </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form id="AddTestForm" method="POST" action="{{ route('ray.store') }}" class="needs-validation"
                        novalidate enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="number" id="number">
                        <input type="hidden" name="name" id="name">
                        <div class="col-md-12">
                            <div class="card shadow mb-4">
                                <div class="card-header">
                                    <h4 class="card-title">الاشعات</h4>
                                </div>
                                <div class="card-body">
                                    <div class="addRay"></div>
                                    <div class="form-group">
                                        <span id="SpanMessage"></span>
                                        <a class="btn btn-primary float-end" id="butonAddRay">اضافة نتائج الاشعة</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="card shadow mb-4">
                                <div class="card-body">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary float-end">حفظ البيانات</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <script>
        function populateEditModal(id, name) {
            document.getElementById('number').value = id;
            document.getElementById('name').value = name;
        }
    </script>
@endsection
