@extends('layout.ray_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">اشعات المرضى الخاصة بالمركز</h4>

                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">اشعات المرضى الخاصة بالمركز</a>
                            </li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header fix-card">

                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم المريض</th>
                                                <th>عرض الاشعات </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                                @foreach ($all_test as $test)
                                                    <tr>
                                                        <td>#{{ ++$index }}</td>
                                                        <td> {{ $test->Name }}</td>
                                                        <td class="text-start">
                                                            <a href="{{ route('ray.person.rays',['patient'=> $test->patient_id]) }}"
                                                                class='mr-4'>
                                                                <button class="btn btn-primary">عرض</button>
                                                            </a>

                                                        </td>
                                                    </tr>
                                                @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->
@endsection
