@extends('layout.ray_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h4 class="text-primary">الحساب</h4>

                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ route('lab.index') }}">الرئيسية</a></li>
                        <li class="breadcrumb-item active"><a href="#">الحساب</a></li>
                    </ol>
                </div>
            </div>


            <div class="row">
                <div class="col-md-12">
                    <div class="profile-header">

                        <div class="row ">
                            <div class="col-4">
                                <div class="form-group row widget-3">
                                    <div class="col-lg-10">
                                        <div class="form-input"
                                            style="background-image:
                                                @if (isset(Auth::user()->building->logo)) url('{{ asset('images/buildings/logos/') }}/{{ Auth::user()->building->logo }}')
                                                @else
                                                url('{{ asset('images/client.jpg') }}') @endif
                                                ;     background-size: cover;
                                                    background-repeat: no-repeat;
                                                ">

                                        </div>
                                    </div>
                                </div>


                            </div>
                            <div class="col ml-md-n2 m-29 profile-user-info">
                                <h4 class="user-name mb-3">{{ Auth::user()->building->name }} </h4>
                                {{-- @if ($usertype == 'lab') --}}
                                    <h6 class="text-muted mt-1"> مركز اشعة </h6>
                                {{-- @endif --}}
                                <div class="user-Location mt-1">
                                    <i style="color: #7366ff;" class="fas fa-map-marker-alt"></i>
                                    {{ Auth::user()->building->address }}
                                </div>

                            </div>

                        </div>
                        <div class="tab-pane fade show active" id="solid-rounded-justified-tab3">
                            <div class="row">
                                <div class="col">
                                    <div class="card ">
                                        <div class="card-body">
                                            <h5 class="card-title d-flex justify-content-between">
                                                <span>بيانات الحساب</span>

                                            </h5>
                                            <div class="row mt-5">
                                                <p class="col-sm-3 text-sm-right mb-0 mb-sm-3">
                                                    الاسم
                                                </p>
                                                <p class="col-sm-9"> {{ Auth::user()->building->name }}</p>
                                            </div>
                                            @if (Auth::user()->building->hospital_id != 0)
                                                <div class="row">
                                                    <p class="col-sm-3 text-sm-right mb-0 mb-sm-3">
                                                        مستشفى
                                                    </p>
                                                    <p class="col-sm-9"> {{ Auth::user()->building->hospital->name }} </p>
                                                </div>
                                            @endif
                                            <div class="row">
                                                <p class="col-sm-3 text-sm-right mb-0 mb-sm-3">
                                                    البريد الالكتروني
                                                </p>
                                                <p class="col-sm-9">
                                                    {{ Auth::user()->email }}
                                                </p>
                                            </div>
                                            <div class="row">
                                                <p class="col-sm-3 text-sm-right mb-0 mb-sm-3">
                                                    رقم الهاتف
                                                </p>
                                                <p class="col-sm-9">{{ Auth::user()->phone_number }}</p>
                                            </div>
                                            <div class="row">
                                                <p class="col-sm-3 text-sm-right mb-0">العنوان</p>
                                                <p class="col-sm-9 mb-0">
                                                    {{ Auth::user()->building->address }}
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                        <div id="password_tab" class="tab-pane fade show active">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">تغير كلمة السر</h5>
                                    <div class="row">
                                        <div class="col-md-10 col-lg-6">
                                            <form action="{{ route('ray.profile.password') }}" method="POST"
                                                class="row align-items-start needs-validation" novalidate>
                                                @csrf
                                                <input type="hidden" name="number" value="{{ Auth::user()->id }}" />
                                                <div class="form-group">
                                                    <label>كلمة السر القديمة</label>
                                                    <input name="oldPassword" id="validationCustom05" type="password"
                                                        class="form-control" required />
                                                </div>
                                                <div class="form-group">
                                                    <label>كلمة السر الجديدة</label>
                                                    <input name="newPassword" id="validationCustom05" type="password"
                                                        class="form-control" required />
                                                </div>
                                                <div class="form-group">
                                                    <label>تاكيد كلمة السر</label>
                                                    <input name="newPassword2" id="validationCustom05" type="password"
                                                        class="form-control" required />
                                                </div>
                                                <button class="btn btn-primary" type="submit">
                                                    حفظ التعديلات
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- End section content -->
    @endsection
