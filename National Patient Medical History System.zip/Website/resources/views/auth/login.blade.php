@extends('layouts.app')

@section('content')



<div id="main-wrapper" class="show">



    <!-- start section login tabib -->
    <div class="login-tabib">
        <div>
            <div class="text-center">
                <a class="logo" href="#">
                    <img loading="lazy" class="img-fluid" src="{{ asset('images/logo.png') }}" alt="loogin page">
                </a>
            </div>

            <div class="login-main">
                <form class="theme-form" method="POST" action="{{ route('login') }}">
                    @csrf

                    <h4>تسجيل الدخول</h4>
                    <p>ادخل البريد الالكتروني و كلمة السر </p>
                    <div class="form-group m-b-10">
                        <label class="col-form-label" >البريد الالكتروني</label>

                        <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="example@gmail.com">

                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror

                    </div>
                    <div class="form-group m-b-10">

                        <label class="col-form-label">كلمة السر</label>

                        <div class="form-input position-relative">
                            <input input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password" placeholder="*********">

                            <div class="show-hide"><span class="show"></span></div>

                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror

                        </div>
                    </div>
                    <div class="form-group mb-0">
                        <div class="checkbox p-0">
                            <input   class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                            <label  class="text-muted" for="remember">تذكرني</label>

                        </div>
                            @if (Route::has('password.request'))
                                <a class="link text-primary" href="{{ route('password.request') }}">نسيت كلمة السر ؟</a>
                            @endif
                        <div class="mt-3">
                            <button type="submit" name="submit" class="btn btn-primary w-100">تسجيل</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <!-- End section login tabib -->

</div>



@endsection
