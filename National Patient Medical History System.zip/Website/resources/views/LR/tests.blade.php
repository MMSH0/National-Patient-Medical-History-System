@extends('layout.labray_layout')
@section('content')
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <h2> جميع الفحوصات</h2>
                <h3>اسم المريض :{{ $tests[0]->patient->user->person->name }} </h3>
                <br />
                <label for="selectDate"> تاريخ الفحص</label>
                <select id="selectDate" class="form-control mb-3" onchange="filterTests()">
                    <!-- Populate this dropdown dynamically with unique dates from your data -->
                    @foreach ($date as $dates)
                        <option value="{{ $dates->test_date }}">
                            {{ $dates->test_date }}
                        </option>
                    @endforeach
                </select>
                <div class="card shadow">

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>اسم الفحص</th>
                                        <th>النتيجة</th>
                                        <th>الوقت</th>
                                    </tr>
                                </thead>
                                <tbody id="testTableBody">
                                    <!-- Data will be dynamically inserted here based on the selected date -->
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            // Replace this with your actual test data
            const testData = [
                @foreach ($tests as $test)
                    {
                        testNumber: "{{ $test->test->name }}",
                        result: "{{ $test->result }}",
                        date: "{{ $test->test_date }}",
                        time: "{{ $test->test_time }}",
                    },
                @endforeach
            ];

            function filterTests() {
                const selectedDate = document.getElementById("selectDate").value;
                const filteredTests = testData.filter(test => test.date === selectedDate);

                const tableBody = document.getElementById("testTableBody");
                tableBody.innerHTML = "";

                filteredTests.forEach(test => {
                    const row = document.createElement("tr");
                    row.innerHTML = `<td>${test.testNumber}</td><td>${test.result}</td><td>${test.time}</td>`;
                    tableBody.appendChild(row);
                });
            }

            // Initial population of the table with the first date
            filterTests();
        </script>
    @endsection
