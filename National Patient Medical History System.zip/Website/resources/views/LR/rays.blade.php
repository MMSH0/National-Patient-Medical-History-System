@extends('layout.labray_layout')
@section('content')
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <h2> جميع الاشعات</h2>
                <h3>اسم المريض :{{ $tests[0]->patient->user->person->name }} </h3>
                <br />
                <label for="selectDate"> تاريخ الاشعة</label>
                <select id="selectDate" class="form-control mb-3" onchange="filterTests()">
                    <!-- Populate this dropdown dynamically with unique dates from your data -->
                    @foreach ($date as $dates)
                        <option value="{{ $dates->date }}">
                            {{ $dates->date }}
                        </option>
                    @endforeach
                </select>
                <div class="card shadow">

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>اسم الاشعة</th>
                                        <th>النتيجة</th>
                                        <th>الوقت</th>
                                    </tr>
                                </thead>
                                <tbody id="testTableBody">
                                    <!-- Data will be dynamically inserted here based on the selected date -->
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            // Replace this with your actual test data
            const testData = [
                @foreach ($tests as $test)
                    {
                        testNumber: "{{ $test->ray->name }}",
                        result: "{{ $test->result }}",
                        date: "{{ $test->date }}",
                        time: "{{ $test->time }}",
                        patient: "{{ $test->patient->id }}",
                    },
                @endforeach
            ];

            function filterTests() {
                const selectedDate = document.getElementById("selectDate").value;
                const filteredTests = testData.filter(test => test.date === selectedDate);

                const tableBody = document.getElementById("testTableBody");
                tableBody.innerHTML = "";

                filteredTests.forEach(test => {
                    const row = document.createElement("tr");
                    row.innerHTML =
                        `<td>${test.testNumber}</td><td><a class="btn btn-primary" target="_blank" href="{{ asset('files/rays/') }}/{{ Auth::user()->building->id }}/${test.patient}/${test.result}">فتح</a></td><td>${test.time}</td>`;
                    tableBody.appendChild(row);
                });
            }

            // Initial population of the table with the first date
            filterTests();
        </script>
    @endsection
