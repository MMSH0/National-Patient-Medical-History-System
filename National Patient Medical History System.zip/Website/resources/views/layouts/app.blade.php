<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="بوابة المرضى الالكتروني">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
       <title>بوابة المرضى الالكتروني</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" href="{{ asset('favicon-32x32.png') }}">
    <!-- Base Styling  -->
    <link rel="stylesheet" href="{{ asset('css/select2.css') }}">

    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/fonts.css') }}">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

</head>
<body class="auth" dir="rtl">
    <div id="main-wrapper" class="show">
        <main class="py-4">
            @yield('content')
        </main>
    </div>



      <!-- JQuery v3.5.1 -->
    <script src="{{ asset('/plugins/jquery/jquery.min.js') }}" defer></script>
    <script src="{{ asset('/js/jquery-3.6.0.min.js') }}" defer></script>
    <script src="{{ asset('plugins/popper/popper.min.js') }}" defer></script>

    <script src="{{ asset('plugins/bootstrap/js/bootstrap.min.js') }}" defer></script>

    <script src="{{ asset('plugins/moment/moment.min.js') }}" defer></script>

    <script src="{{ asset('plugins/daterangepicker/daterangepicker.min.js') }}" defer></script>

    <script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}" defer></script>
    <script src="{{ asset('js/init-tdatatable.js') }}" defer></script>

    <script src="{{ asset('plugins/chart/chart/Chart.min.js') }}" defer></script>
    <script src="{{ asset('js/charts-custom.js') }}" defer></script>

    <script src="{{ asset('js/toggleFullScreen.js') }}" defer></script>
    <script src="{{ asset('js/main.js') }}" defer></script>
    <script src="{{ asset('js/option-themes.js') }}" defer></script>
    <script src="{{ asset('js/data.js') }}" defer></script>

    <script src="{{ asset('js/select2.js') }}" defer></script>

    {{-- <script src="{{ asset('../resources') }}/js/sweetalert2.min.js" defer></script> --}}
    @include('sweetalert::alert')

</body>
</html>
