@extends('layout.doctor_layout')
@section('content')


        <!-- start section content -->
        <div class="content-body">
            <div class="warper container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-lg-12 p-md-0">
                        <h4 class="text-primary"> مرحبا <span class="names">د/{{Auth::user()->person->name}}</span></h4>
                        <p class="mb-0">المستشفى / العيادة</p>
                    </div>
                </div>
                <div class="new-patients main_container">
                    <div class="row">
                        <div class="col-sm-6 col-xl-3 col-lg-6">
                            <div class="widget card card-primary bg-card1">

                                <div class="card-body">
                                  <a href="{{route('doctor.patinet.index')}}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-users fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                             <span class="text-white" >المرضى</span>

                                            <h3 class="mb-0 text-white">{{$patients}}</h3>
                                        </div>
                                    </div>
                                  </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-3 col-lg-6">
                            <div class="widget card card-danger bg-card2">
                                <div class="card-body">
                                    <a href="{{route('doctor.appointment')}}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-bell fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white">الحجوزات</span>
                                            <h3 class="mb-0 text-white">{{$appointments}}</h3>
                                        </div>
                                    </div>
                                  </a>
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="row">

                        <div class="col-lg-6">
                            <div class="card shadow widget1">
                                <div class="card-header">
                                    <h4 class="card-title">المرضى</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-12">
                                            <canvas id="chart1" width="100%" height="50"></canvas>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-6">
                            <div class="card shadow widget1">
                                <div class="card-header">
                                    <h4 class="card-title">المستشفى</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-12">
                                            <canvas id="chart2" width="100%" height="50"></canvas>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
        <!-- End section content -->

 @endsection
