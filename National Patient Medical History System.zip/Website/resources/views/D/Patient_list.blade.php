@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">المرضى</h4>
                            <p class="mb-0">اضافة مريض</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('doctor.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="{{ route('doctor.patinet.index') }}">المرضى</a>
                            </li>
                        </ol>
                    </div>
                </div>




                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-8">
                                        <h4 class="card-title">المرضى</h4>
                                    </div>
                                    <div class="col-4">
                                        <a type="button" href="{{ route('doctor.patient.search') }}"
                                            class="btn btn-primary float-end"> البحث عن سجل مريض</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>صورة المريض</th>
                                                <th>اسم المريض</th>
                                                <th> العمر </th>
                                                <th> الجنس </th>
                                                <th>رقم الهاتف</th>
                                                <th> تاريخ الزيارة </th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {{-- {{ dd($patients ) }} --}}
                                            @foreach ($patients as $patient)
                                                @if (\Carbon\Carbon::parse($patient->patient->user->person->birthDate)->age >=18 && isset( $patient->patient->user->phone_number ))
                                                <tr>
                                                    <td>{{ ++$index }}</td>
                                                    <td>
                                                        @if (isset($patient->patient->user->person->prsonalImage))
                                                            <img loading="lazy" class="rounded-image"
                                                                src="{{ asset('patient/profile') }}/{{ $patient->patient->user->person->prsonalImage }}">
                                                        @else
                                                            <img loading="lazy" class="rounded-image"
                                                                src="{{ asset('images/client.jpg') }}">
                                                        @endif
                                                    </td>


                                                    <td> {{ $patient->patient->user->person->name }} </td>
                                                    <td>{{ \Carbon\Carbon::parse($patient->patient->user->person->birthDate)->age }}
                                                    </td>

                                                    @if ($patient->patient->user->person->gender == 0)
                                                        <td> انثى </td>
                                                    @else
                                                        <td> ذكر </td>
                                                    @endif
                                                    <td>{{ $patient->patient->user->phone_number }}</td>
                                                    <td>
                                                        <select class="form-control form-select">
                                                            @foreach ($patient->patient->visitation as $visit)
                                                                <option> {{ $visit->visiting_date }}</option>
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                    <td class="float-center">
                                                        <a class='mr-4 btn btn-primary'
                                                            href="{{ route('doctor.patient.verfication', ['id' => Crypt::encryptString($patient->patient->id)]) }}">
                                                            عرض

                                                        </a>
                                                    </td>
                                                </tr>
                                                @endif

                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->
@endsection
