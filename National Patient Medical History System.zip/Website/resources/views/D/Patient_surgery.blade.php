@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">العمليات</h4>
                            <p class="mb-0">اضافة عملية</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('doctor.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">العمليات</a>
                            </li>
                        </ol>
                    </div>
                </div>






                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-8">
                                        <h4 class="card-title">العمليات</h4>
                                    </div>
                                    <div class="col-2">
                                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                            data-bs-target="#addDrugs"> اضافة عملية</button>
                                    </div>
                                    <div class="col-2">
                                        <a href="{{route('doctor.patient.report.surgery', ['id' => Crypt::encryptString($id)])}}" class="btn btn-primary float-end">اصدار تقرير</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>العملية </th>
                                                <th>الحالة</th>
                                                <th>الوصف</th>
                                                <th>تاريخ العملية</th>
                                                <th>action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @isset($surgery)

                                                @foreach ($surgery as $patientsurgery)
                                                    <tr>
                                                        <td>{{ ++$index }}</td>
                                                        <td>{{ $patientsurgery->surgery->name }}</td>
                                                        <td>{{ $patientsurgery->status }}</td>
                                                        <td>{{ $patientsurgery->note }}</td>
                                                        <td>{{ $patientsurgery->surgery_date_time }}</td>
                                                        <td class="text-start">
                                                            @if (
                                                                $patientsurgery->doctor_id == Auth::user()->doctor->id &&
                                                                    !\Carbon\Carbon::now()->greaterThanOrEqualTo(\Carbon\Carbon::parse($patientsurgery->surgery_date_time)))
                                                                <a data-bs-toggle='modal' data-bs-target='#editDiagnose'
                                                                    class='mr-4'
                                                                    onclick="populateEditModal('{{ $patientsurgery->id }}','{{ $patientsurgery->doctor_id }}','{{ $patientsurgery->notes }}');">
                                                                    <span class='fas fa-pencil-alt tbl-edit'></span>
                                                                </a>
                                                            @else
                                                                <a href="#" class="btn btn-danger">لا يمكنك تعديل على
                                                                    البيانات</a>
                                                            @endif
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            @else
                                                @endif
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End section content -->



        <!-- change date and time diagnose -->
        <div class="modal fade selectRefresh" id="addDrugs" tabindex="-1" role="dialog"
            aria-labelledby="modal-title-addDrug-modal">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal-title-addDrug-modal"> أضافة عملية </h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="{{ route('doctor.patient.surgery.store') }}"
                            class="row align-items-start needs-validation" novalidate>
                            {{-- <form method="POST"  class="row align-items-start needs-validation" novalidate> --}}
                            @csrf
                            <div class="col-lg-12">
                                <div class="row">
                                    <label for="validationCustom05" class="form-label"> العملية </label>

                                    <div class="col-12">
                                        <fieldset>
                                            <!-- Radio buttons for selected tests -->
                                            <div class="d-flex flex-wrap">
                                                @foreach ($all_surgeries as $Surgery)
                                                    <div class="checkbox-card" onclick="toggleCheckboxCard(event)">
                                                        <input class="custom-control-input" type="checkbox" name="surgeries[]"
                                                            value="{{ $Surgery->id }}">
                                                        <label class="form-check-label">{{ $Surgery->name }}</label>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>

                                <div class="form-group">

                                    <br>
                                    <div class="row">
                                        <div class="col-sm-6 col-xl-3 col-lg-6">
                                            <label>تاريخ العملية</label>
                                            <input class="form-control" type="date" name="surgery_date_time"
                                                id="validationCustom05">
                                        </div>

                                        <div class="col-sm-6 col-xl-3 col-lg-6">
                                            {{-- select the statuse of the surgery  --}}
                                            <div class="form-group">
                                                <div class="col-lg-12">
                                                    <label>حالة العملية</label>
                                                    <select id="validationCustom05" required class="form-control form-select"
                                                        name="Surgery_statues">
                                                        <option>تم التقرير</option>
                                                        <option>تم تحديد الموعد</option>
                                                        <option>تمت بنجاح </option>
                                                        <option>تمت بفشل </option>
                                                        <option>تم تقرير عملية اخرى </option>
                                                        <option>تم الإلغاء</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <label for="validationCustom05">ملاحظة</label>
                                    <textarea class="form-control" rows="3" value="{{ old('notes') }}" name="notes" id="validationCustom05"
                                        required></textarea>
                                    <br>

                                    <input type="hidden" name="Doctor_Id" value="{{ Auth::user()->doctor->id }}">
                                    <input type="hidden" name="number" value="{{ Crypt::encryptString($id) }}">
                                </div>
                                @error('notes')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal"
                                    aria-label="Colse">إغلاق</button>
                                <button type="submit" class="btn btn-primary" name ="submit">حفظ البيانات</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Edit Diagnose -->
        <div class="modal fade selectRefresh" id="editDiagnose" tabindex="-1" role="dialog"
            aria-labelledby="modal-title-addDrug-modal">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal-title-addDrug-modal"> تعديل العملية </h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="{{ route('doctor.patient.surgery.update') }}"
                            class="row align-items-start needs-validation" novalidate>
                            @csrf
                            @method('PUT')
                            <div class="row">
                                {{-- make a var in the controller
                                        to get only the patient surgeries from patient surgeries and send hidden input
                                         with each surgery  to chang the specefic surgery --}}

                                <input type="hidden" name="id" id="editSurg">

                                <div class="col-12">
                                    <fieldset>
                                        <label for="validationCustom05" class="form-label"> العملية </label>
                                        <!-- Radio buttons for selected tests -->
                                        <div class="d-flex flex-wrap">
                                            @foreach ($all_surgeries as $surgery)
                                                <div class="checkbox-card" onclick="toggleCheckboxCard(event)">
                                                    <input class="custom-control-input" type="checkbox" name="surgeries[]"
                                                        value="{{ $surgery->id }}">
                                                    <label class="form-check-label">{{ $surgery->name }}</label>
                                                </div>
                                            @endforeach
                                        </div>
                                    </fieldset>
                                </div>
                            </div>

                            <div class="form-group">
                                <br>
                                <div class="row">
                                    <div class="col-sm-6 col-xl-3 col-lg-6">
                                        <label>تاريخ العملية</label>
                                        <input class="form-control" type="date" name="surgery_date_time"
                                            id="validationCustom05" value="{{ old('surgery_date_time') }}">
                                    </div>

                                    <div class="col-sm-6 col-xl-3 col-lg-6">
                                        {{-- select the statuse of the surgery  --}}
                                        <div class="form-group">
                                            <div class="col-lg-12">
                                                <label>حالة العملية</label>
                                                <select id="validationCustom05" required class="form-control form-select"
                                                    name="Surgery_statues">
                                                    <option>تم التقرير</option>
                                                    <option>تم تحديد الموعد</option>
                                                    <option>تمت بنجاح </option>
                                                    <option>تمت بفشل </option>
                                                    <option>تم تقرير عملية اخرى </option>
                                                    <option>تم الإلغاء</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="validationCustom05"> الوصف </label>
                                    <textarea value="{{ old('notes') }}" name="notes" id="surgeryNotes" class="form-control" rows="3"
                                        id="validationCustom05" required> </textarea>
                                    @error('notes')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>
                                <input type="hidden" name="Doctor_Id" value={{ Auth::user()->doctor->id }}>
                                <input type="hidden" name="number" value="{{ Crypt::encryptString($id) }}">
                            </div>
                            <div class="modal-footer">

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal"
                                        aria-label="Colse">إغلاق</button>
                                    <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                                </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>

        </div>
        <!-- change date and time diagnose -->
        <script>
            function populateEditModal(id, SId, notes) {
                document.getElementById('editSurg').value = id;
                document.getElementById('SId').value = SId;

                document.getElementById('surgeryNotes').value = notes;
            }

            /*  ==========================================
                Filter test
            * ========================================== */


            // Function to update the test options based on the selected category
            function updateTestList() {
                const testData = {

                    // Add more categories and tests as needed
                };
                fetchDoctorTests();

                const testOptionsContainer = document.getElementById('testOptions');

                const categorySelect = document.querySelector('input[name="testCategory"]:checked');

                const selectedCategory = categorySelect ? categorySelect.value : null;

                // Clear existing options
                testOptionsContainer.innerHTML = '';

                // Populate the test options based on the selected category
                if (selectedCategory) {
                    testData[selectedCategory].forEach(test => {
                        const div = document.createElement('div');
                        div.classList.add('checkbox-card');
                        div.onclick = toggleCheckboxCard;

                        const input = document.createElement('input');
                        input.classList.add('custom-control-input');
                        input.type = 'checkbox';
                        input.name = 'selectedTest';
                        input.value = test;

                        const label = document.createElement('label');
                        label.classList.add('form-check-label');
                        label.textContent = test;

                        div.appendChild(input);
                        div.appendChild(label);

                        testOptionsContainer.appendChild(div);
                    });
                }
            }

            // Call the updateTestList function to populate the test options on page load
            updateTestList();



            function toggleCheckboxCard(event) {
                const testSelectedContainer = document.getElementById('testSelected');

                const checkboxCard = event.currentTarget;
                const checkbox = checkboxCard.querySelector('input[type="checkbox"]');
                const div = document.createElement('div');


                const input = document.createElement('input');
                input.classList.add('custom-control-input');
                input.type = 'button';
                input.name = 'selectedTest';
                input.value = checkbox.value;

                div.classList.add('checkbox-card');


                const label = document.createElement('label');
                label.classList.add('form-check-label');
                label.textContent = checkbox.value;

                div.appendChild(input);
                div.appendChild(label);

                checkbox.checked = !checkbox.checked;

                checkboxCard.classList.toggle('checked', checkbox.checked);

                if (checkbox.checked) {
                    testSelectedContainer.appendChild(checkboxCard);
                } else {
                    testOptionsContainer.appendChild(checkboxCard);

                }

            }
        </script>
    @endsection
