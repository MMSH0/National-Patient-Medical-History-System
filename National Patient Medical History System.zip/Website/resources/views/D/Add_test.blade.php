@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="add_Test main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">الفحوصات</h4>
                            <p class="mb-0">اضافة فحوصات</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">الفحوصات</a></li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow mb-4">
                            <div class="card-header">
                                <h4 class="card-title">اضافة فحص</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <div class="col-md-12">
                                        <div class="card shadow mb-4">
                                            <div class="card-header">
                                                <h4 class="card-title"></h4>
                                            </div>
                                            <div class="card-body">
                                                <form action="{{ route('doctor.patient.test.store') }}" method="POST" class="needs-validation"
                                                    novalidate>
                                                    @csrf
                                                    <input type="hidden" name="number" value="{{ $id }}">
                                                    <div class="form-group">
                                                        <h4 class="text-primary ">نوع الفحص</h4>
                                                        <fieldset class="custom-radio">

                                                            <!-- Custom-styled radio buttons for test categories -->
                                                            @foreach ($types as $type)
                                                                <div class="custom-control custom-radio">
                                                                    <input type="radio" id="{{ $type->id }}"
                                                                        name="testCategory" value="{{ $type->id }}"
                                                                        class="custom-control-input"
                                                                        onclick="updateTestList()" required>
                                                                    <label class="custom-control-label"
                                                                        for="{{ $type->id }}">{{ $type->name }}</label>
                                                                </div>
                                                            @endforeach


                                                            <div class="invalid-feedback"></div>
                                                        </fieldset>
                                                    </div>
                                                    <hr>

                                                    <div class="form-group">
                                                        <h5>أسم الفحص:</h5>
                                                        <fieldset>

                                                            <!-- Radio buttons for selected tests -->
                                                            <div id="testOptions" class="d-flex flex-wrap">
                                                                <!-- Options will be dynamically populated here -->
                                                            </div>

                                                        </fieldset>
                                                        <hr>
                                                        <h5>أسم الفحوصات التي تم اختيارها :</h5>
                                                        <fieldset>
                                                            <div id="testSelected" class="d-flex flex-wrap">
                                                                <!-- Options will be dynamically populated here -->
                                                            </div>
                                                        </fieldset>
                                                    </div>

                                                    <!-- Other result-related fields can be added here -->

                                                    <button type="submit" class="btn btn-primary float-end">إضافة
                                                        فحوصات</button>
                                                </form>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- End section content -->


    <script>
        /*  ==========================================
        Filter test
    * ========================================== */


        // Function to update the test options based on the selected category
        function updateTestList() {
            const testData = {
                @foreach ($types as $type)
                    {{ $type->id }}: [@foreach ($type->test as $test) "{{ $test->name }}", @endforeach],
                @endforeach

            };
            const testId= {
                @foreach ($types as $type)
                    {{ $type->id }}: [@foreach ($type->test as $test) "{{ $test->id }}", @endforeach],
                @endforeach

            };

            const testOptionsContainer = document.getElementById('testOptions');

            const categorySelect = document.querySelector('input[name="testCategory"]:checked');

            const selectedCategory = categorySelect ? categorySelect.value : null;

            // Clear existing options
            testOptionsContainer.innerHTML = '';

            // Populate the test options based on the selected category
            if (selectedCategory) {
                testData[selectedCategory].forEach(test => {
                    const div = document.createElement('div');
                    div.classList.add('checkbox-card');
                    div.onclick = toggleCheckboxCard;

                    const input = document.createElement('input');
                    input.classList.add('custom-control-input');
                    input.type = 'checkbox';
                    input.name = 'selectedTest[]';
                    input.value = testId[selectedCategory][testData[selectedCategory].indexOf(test)];


                    const label = document.createElement('label');
                    label.classList.add('form-check-label');
                    label.textContent = test;

                    div.appendChild(input);
                    div.appendChild(label);

                    testOptionsContainer.appendChild(div);
                });
            }
        }

        // Call the updateTestList function to populate the test options on page load
        updateTestList();



        function toggleCheckboxCard(event) {
            const testSelectedContainer = document.getElementById('testSelected');

            const checkboxCard = event.currentTarget;
            const checkbox = checkboxCard.querySelector('input[type="checkbox"]');
            const div = document.createElement('div');


            const input = document.createElement('input');
            input.classList.add('custom-control-input');
            input.type = 'button';
            input.name = 'selectedTest';
            input.value = checkbox.value;

            div.classList.add('checkbox-card');


            const label = document.createElement('label');
            label.classList.add('form-check-label');
            label.textContent = checkbox.value;

            div.appendChild(input);
            div.appendChild(label);

            checkbox.checked = !checkbox.checked;

            checkboxCard.classList.toggle('checked', checkbox.checked);

            if (checkbox.checked) {
                testSelectedContainer.appendChild(checkboxCard);
            } else {
                testOptionsContainer.appendChild(checkboxCard);

            }

        }
    </script>
@endsection
