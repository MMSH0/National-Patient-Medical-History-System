@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <div class="row">
                    @if (\Carbon\Carbon::parse($child->person->birthDate)->age >= 18)
                      @if (!isset($child->person->user_Id))
                      <a  data-bs-toggle='modal' data-bs-target='#editIll' class='mr-4' onclick="">
                        <div style="cursor: pointer;" class="alert alert-danger">
                            <strong>ملاحظة</strong> يرجى إدخال رقم الهاتف الخاص بالمريض لأنه قد بلغ سن الرشد.
                          <span
                            class='fas fa-pencil-alt tbl-edit'></span>
                        </div>
                    </a>
                      @else

                        <div style="cursor: pointer;" class="alert alert-success">
                            <strong>ملاحظة</strong> تم إدخال رقم الهاتف الخاص بالمريض.
                        </div>

                      @endif
                        @endif

                        <div class="row">
                            <div class="col-sm-1">
                                @if (isset($child->person->prsonalImage))
                                    <img loading="lazy" class="rounded-image"
                                        src="{{ asset('patient/profile') }}/{{ $child->person->prsonalImage }}">
                                @else
                                    <img loading="lazy" class="rounded-image"
                                        src="{{ asset('images/client.jpg') }}">
                                @endif
                            </div>

                            <div class="col">
                                <br>
                                <h4 class="text-primary"> اسم المريض <span class="text-danger">{{ $child->person->name }}
                                    </span></h4>
                                <a data-bs-toggle='modal' data-bs-target='#editIll' class='mr-4' onclick=""></a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                            </div>
                            <div class="col">



                                <h6 class="text-primary"> العمر <span class="text-danger">
                                        {{ \Carbon\Carbon::parse($child->person->birthDate)->age }} </h6>




                            </div>
                            <div class="col">
                                @if ($child->person->gender == 1)
                                    <h6 class="text-primary"> الجنس <span class="text-danger"> ذكر </h6>
                                @else
                                    <h6 class="text-primary"> الجنس <span class="text-danger"> انثى </h6>
                                @endif
                            </div>
                            <div class="col">
                                <h6 class="text-primary"> فصيلة الدم <span class="text-danger"> {{ $patient->blood_type }}
                                </h6>

                            </div>
                            <div class="col">
                                <h6 class="text-primary"> الطول <span class="text-danger"> {{ $patient->hight }} </h6>

                            </div>
                            <div class="col">
                                <h6 class="text-primary"> الوزن <span class="text-danger"> {{ $patient->weight }} </h6>

                            </div>
                        </div>

                    </div>

                </div>

            </div>
            <div class="col">
                <h6 class="mb-0"> تاريخ اخر الزيارة
                    <span class="text-primary">
                        @if (isset($patient->Visitation->last()->visiting_date))
                            {{ $patient->Visitation->last()->visiting_date }}
                        @else
                            لايوجد
                        @endif

                </h6>

            </div>
            <br />
            <br />
            <div class="new-patients main_container">
                <div class="row">
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card1">


                            <div class="card-body">
                                <form method="GET"
                                    action="{{ route('doctor.patient.diagnose', Crypt::encryptString($patient->id)) }}">
                                    @csrf
                                    <button type="submit" class="btn">
                                        <div class="media text-center">
                                            <span>
                                                <i class="fas fa-users fa-2x"></i>
                                            </span>
                                            <div class="media-body">
                                                <span class="text-white">التشخيصات</span>

                                                <h3 class="mb-0 text-white">{{ $diagnoses }}</h3>
                                            </div>
                                        </div>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-danger bg-card2">
                            <div class="card-body">


                                <a href="{{ route('doctor.patient.medicen', Crypt::encryptString($patient->id)) }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-bell fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white">الأدويه</span>
                                            <h3 class="mb-0 text-white">{{ $medicens }}</h3>
                                        </div>

                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card3">
                            <div class="card-body">
                                <a
                                    href="{{ route('doctor.patient.test.index', ['id' => Crypt::encryptString($patient->id)]) }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-th-large fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white">الفحوصات</span>
                                            <h3 class="mb-0 text-white">{{ $tests }}</h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card4">
                            <div class="card-body">
                                <a href="{{ route('doctor.patient.ray', ['id' => Crypt::encryptString($patient->id)]) }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-database fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white"> الأشعة</span>
                                            <h3 class="mb-0 text-white">{{ $rays }}</h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card4">
                            <div class="card-body">
                                <a
                                    href="{{ route('doctor.patient.disease.index', ['id' => Crypt::encryptString($patient->id)]) }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-heartbeat fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white"> الأمراض المزمنة </span>
                                            <h3 class="mb-0 text-white">{{ $diseases }}</h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card4">
                            <div class="card-body">
                                <a
                                    href="{{ route('doctor.patient.surgery.index', ['id' => Crypt::encryptString($patient->id)]) }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-heartbeat fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white"> العمليات </span>
                                            <h3 class="mb-0 text-white">{{ $surgeries }}</h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                @if ($children > 0)
                    <div class="row">
                        <hr />
                        <div class="col-sm-6 col-xl-3 col-lg-6">
                            <div class="widget card card-danger bg-card4">
                                <div class="card-body">
                                    <a
                                        href="{{ route('doctor.patient.children.index', ['pid' => Crypt::encryptString($patient->id)]) }}">
                                        <div class="media text-center">
                                            <span>
                                                <i class="fas fa-database fa-2x"></i>
                                            </span>
                                            <div class="media-body">
                                                <span class="text-white"> المعالين</span>
                                                <h3 class="mb-0 text-white">{{ $children }}</h3>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif


            </div>
        </div>
    </div>
    </div>
   <!-- edit  ILL -->
   <div class="modal fade selectRefresh" id="editIll" tabindex="-1" role="dialog"
   aria-labelledby="modal-title-addDrug-modal">
   <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
       <div class="modal-content">
           <div class="modal-header">
               <h5 class="modal-title" id="modal-title-addDrug-modal"> رقم الهاتف الخاص بالمريض </h5>
               <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                       aria-hidden="true">&times;</span></button>
           </div>
           <div class="modal-body">
               <form method="POST" action="{{ route('doctor.patient.phone.update') }}"
                   class="row align-items-start needs-validation" novalidate>
                   @csrf
                   @method('PUT')
                   <input type="hidden" value="{{ $patient->id }}" name="number" id="number" />
                   <div class="col">
                    <div class="form-group">

                        <input type="number" name="phone_number" id="phone"
                            value="{{ old('phone_number') }}" class="form-control"
                            placeholder="رقم الهاتف" id="validationCustom05" maxlength="9"
                            minlength="8" required />
                        <span class="error-message" id="phone_number_error"></span>
                        @error('phone_number')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                   </div>

                   <div class="modal-footer">
                       <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                       <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                   </div>
               </form>
           </div>

       </div>
   </div>
</div>

<!-- End section content -->
    <!-- End section content -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            function validateInput(value) {
                // Ensure the maximum length is 9
                if (value.length > 9) {
                    return value.substring(0, 9);
                }

                if (value.length > 1) {
                    if (!/^[7]([13780])/.test(value)) {
                        return value.substring(0, value.length - 1);
                    }
                } else if (!/^[7]/.test(value)) {
                    return value.substring(0, value.length - 1);
                }

                return value;
            }

            document.getElementById('phone').addEventListener('input', function(event) {
                const inputField = event.target;
                const inputValue = inputField.value;
                const messageSpan = document.getElementById('phone_number_error');

                const newValue = validateInput(inputValue);


                if ((newValue !== inputValue)) {

                    inputField.value = newValue;
                    if (inputValue.length < 9) {
                        messageSpan.textContent = "يجب ادخل الرقم بشكل صحيح";

                    } else {
                        messageSpan.textContent = "";
                    }

                } else {

                    messageSpan.textContent = ""; // Clear the message if input is valid
                }

                // Set the cursor position to the end of the input
                inputField.selectionStart = inputField.selectionEnd = inputField.value.length;
            });
        });

    </script>
@endsection
