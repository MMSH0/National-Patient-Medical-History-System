<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Doctor Dashboard ">
    <title>Doctor Dashboard </title>
    <!-- Favicon icon -->
    <!-- Base Styling  -->
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/fonts.css') }}">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

</head>

<body dir="rtl">
    <div id="main-wrapper" class="show">


        <!-- start section login tabib -->
        <div class="login-tabib">
            <div>
                <div class="text-center">
                    <a class="logo" href="{{ route('doctor.index') }}">
                    </a>
                </div>
                <div class="login-main">
                    <form method="POST" action="{{ route('doctor.patient.verify') }}" class="theme-form">
                        @csrf
                        <div class="row">
                            <div class="btn btn-danger">
                                طلب الوصول الى السجل الطبي
                            </div>
                        </div>
                         {{-- message --}}
                         @if (isset($erorr))
                         <div class="container mt-5" id="successAlert">
                             <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                 <span class="message">{{ $erorr }}</span>
                                 <div class="progress" style="height: 2px;">
                                     <div class="progress-bar bg-danger flex-row-reverse mr-auto ml-auto"
                                         role="progressbar" style="width:0%;" aria-valuenow="0" aria-valuemin="0"
                                         aria-valuemax="100" id="progressBar"></div>
                                 </div>
                             </div>

                         </div>
                     @endif
                     {{-- message --}}

                        <div class="form-group m-b-10">

                            <label class="col-form-label"> كود تم ارساله الى تطبيق المريض </label>
                            <input class="form-control" type="number" name="code" placeholder="*****">

                        </div>

                        <div class="form-group mb-0">
                            <div class="checkbox p-0">
                                <input id="checkbox1" type="checkbox">

                            </div>
                            <input type="hidden" name="number" value="{{ $id }}">
                            <a class="link text-primary" href="#">إرسال كودالتحقق مرةأخرى</a>


                            <div class="mt-3">
                                <button submit="type" class="btn btn-primary w-100">تأكيد</button>
                                <div></div>
                                <a href="#"> استخدام الباركود QR بدلا عن كود التحقق </a>

                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <!-- End section login tabib -->
    </div>


    <script src="{{ asset('plugins/jquery/jquery.min.js') }}" defer></script>
    <script src="{{ asset('plugins/popper/popper.min.js') }}" defer></script>

    <script src="{{ asset('plugins/bootstrap/js/bootstrap.min.js') }}" defer></script>

    <script src="{{ asset('plugins/moment/moment.min.js') }}" defer></script>

    <script src="{{ asset('plugins/daterangepicker/daterangepicker.min.js') }}" defer></script>

    <script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}" defer></script>
    <script src="{{ asset('js/init-tdatatable.js') }}" defer></script>

    <script src="{{ asset('plugins/chart/chart/Chart.min.js') }}" defer></script>
    <script src="{{ asset('js/charts-custom.js') }}" defer></script>

    <script src="{{ asset('js/toggleFullScreen.js') }}" defer></script>
    <script src="{{ asset('js/main.js') }}" defer></script>
    <script src="{{ asset('js/option-themes.js') }}" defer></script>
    <script src="{{ asset('js/data.js') }}" defer></script>

    <script src="{{ asset('js/select2.js') }}" defer></script>

    {{-- <script src="{{ asset('../resources') }}/js/sweetalert2.min.js" defer></script> --}}
    @include('sweetalert::alert')

</body>

</html>
