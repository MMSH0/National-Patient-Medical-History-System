@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="All-Rays main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">الأشعة</h4>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">الأشعة</a>
                            </li>
                        </ol>
                    </div>
                </div>





                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-8">
                                        <h4 class="card-title"> الأشعة </h4>
                                    </div>
                                    <div class="col-2">
                                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                        data-bs-target="#add_ray"> اضافة اشعة </button>  </div>
                                    <div class="col-2">
                                        <a href="{{ route('doctor.patient.report.rays', ['id' => Crypt::encryptString($id)]) }}"
                                            class="btn btn-primary float-end"> اصدار تقرير</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم الأشعة</th>
                                                <th>ملاحظة</th>
                                                <th>النتيجة</th>
                                                <th>التقرير</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($rays as $ray)
                                                <tr>
                                                    <td>{{ ++$index }}</td>
                                                    <td>{{ $ray->ray->name }}</td>
                                                    <td>{{ $ray->note }}</td>
                                                    @if (isset($ray->result))
                                                        <td>
                                                            <a href="{{ asset('files/rays/' . $ray->raycenter_id . '/' . $ray->patient_id . '') }}/{{ $ray->result }}"
                                                                target="_blank" class="btn btn-primary">عرض</a>
                                                        </td>
                                                    @else
                                                        <td>
                                                            <a href="#" class="btn btn-danger">لاتوجد نتيجة</a>
                                                        </td>
                                                    @endif


                                                    @if (isset($ray->report))
                                                        <td>
                                                            <a class="btn btn-primary">عرض</a>
                                                        </td>
                                                    @else
                                                        <td>
                                                            <a href="#" class="btn btn-danger">لايوجد تقرير</a>
                                                        </td>
                                                    @endif



                                                </tr>
                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->



    <!-- Add Test -->
    <div class="modal fade selectRefresh" id="add_ray" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> نوع الاشعة </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form id="AddTestForm" class="needs-validation" novalidate method="POST"
                        action="{{ route('doctor.patient.ray.store') }}">
                        @csrf
                        <input type="hidden" name="Doctor_Id" value={{ Auth::user()->doctor->id }}>
                        <input type="hidden" name="Patient_Id" value="{{ $id }}">
                        {{-- <input type="hidden" name="number" id="number">
                        <input type="hidden" name="name" id="name"> --}}
                        <div class="col-md-12">
                            <div class="card shadow mb-4">
                                <div class="card-header">
                                    <h4 class="card-title">اضافة اشعة</h4>
                                </div>
                                <div class="card-body">
                                    <div id="addDoctorRay"></div>
                                    <div class="form-group">
                                        <a class="btn btn-primary float-end" id="butonAddDoctorRay">اضافة اشعة</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="card shadow mb-4">
                                <div class="card-body">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary float-end">حفظ البيانات</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>



    <!-- start edit model -->
    <div class="modal fade" id="edit_personal_details" aria-hidden="true" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تاكد من البيانات</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row form-title">
                        <p class="col-4">اسم الاشعة</p>
                        <p class="col-4"> النتيجة </p>
                    </div>
                    <div class="row">
                        <p class="col-4">اسم اشعة</p>
                        <p class="col-4"> النتيجة </p>
                    </div>
                    <button class="btn btn-primary">تاكيد</button>
                </div>
            </div>
        </div>
    </div>
    <!--edit model  -->


@endsection
