@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <div class="row">
                        <div class="row">
                            <div class="col-sm-1">
                                @if (isset($patient->user->person->prsonalImage))
                                    <img loading="lazy" class="rounded-image"
                                        src="{{ asset('patient/profile') }}/{{ $patient->user->person->prsonalImage }}">
                                @else
                                    <img loading="lazy" class="rounded-image" src="{{ asset('images/client.jpg') }}">
                                @endif
                            </div>

                            <div class="col">

                                <br>

                                <h4 class="text-primary"> اسم المريض <span
                                        class="text-danger">{{ $patient->user->person->name }} </span></h4>

                            </div>

                        </div>
                        <div class="row">

                            <div class="col">
                            </div>
                            <div class="col">
                                <h6 class="text-primary"> العمر <span class="text-danger">
                                        {{ \Carbon\Carbon::parse($patient->user->person->birthDate)->age }} </h6>

                            </div>
                            <div class="col">
                                @if ($patient->user->person->gender == 1)
                                    <h6 class="text-primary"> الجنس <span class="text-danger"> ذكر </h6>
                                @else
                                    <h6 class="text-primary"> الجنس <span class="text-danger"> انثى </h6>
                                @endif
                            </div>
                            <div class="col">
                                <h6 class="text-primary"> فصيلة الدم <span class="text-danger"> {{ $patient->blood_type }}
                                </h6>
                                <a data-bs-toggle='modal' data-bs-target='#booldType' class='mr-4' onclick=""> <span
                                        class='fas fa-pencil-alt tbl-edit'></span></a>
                            </div>
                            <div class="col">
                                <h6 class="text-primary"> الطول <span class="text-danger"> {{ $patient->hight }} </h6>
                                <a data-bs-toggle='modal' data-bs-target='#heightAndWeight' class='mr-4' onclick="">
                                    <span class='fas fa-pencil-alt tbl-edit'></span></a>
                            </div>
                            <div class="col">
                                <h6 class="text-primary"> الوزن <span class="text-danger"> {{ $patient->weight }} </h6>
                                <a data-bs-toggle='modal' data-bs-target='#heightAndWeight' class='mr-4'
                                    onclick="">
                                    <span class='fas fa-pencil-alt tbl-edit'></span></a>
                            </div>
                            <div class="col">
                                <div class="row">
                                    <h6 class="text-primary"> الحالة الاجتماعية <span class="text-danger">
                                            {{ $patient->status == 0 ? 'عازب' : 'متزوج' }} </h6>
                                    @if ($patient->status == 0)
                                        <a data-bs-toggle='modal' data-bs-target='#editIll' class='mr-4' onclick="">
                                            <span class='fas fa-pencil-alt tbl-edit'></span></a>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div class="col-3">
                            <a href="{{route('doctor.patient.report.full', ['id' => Crypt::encryptString($patient->id)])}}" class="btn btn-primary float-end"
                                >اصدار تقرير طبي شامل</a>
                        </div>
                        {{-- <div class="col-2">
                            <a href="{{route('doctor.patient.report.full', ['id' => Crypt::encryptString($patient->id)])}}" class="btn btn-primary float-end"
                                > </a>
                        </div> --}}
                    </div>

                </div>

            </div>
            <br />

            <div class="col">
                <h6 class="mb-0"> تاريخ اخر الزيارة <span class="text-primary">
                        {{ $patient->Visitation->last()->visiting_date }} </h6>

            </div>
            <br />
            <br />
            <div class="new-patients main_container">
                <div class="row">
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card1">


                            <div class="card-body">
                                <form method="GET"
                                    action="{{ route('doctor.patient.diagnose', Crypt::encryptString($patient->id)) }}">
                                    @csrf
                                    <button type="submit" class="btn">
                                        <div class="media text-center">
                                            <span>
                                                <i class="fas fa-users fa-2x"></i>
                                            </span>
                                            <div class="media-body">
                                                <span class="text-white">التشخيصات</span>

                                                <h3 class="mb-0 text-white">{{ $diagnoses }}</h3>
                                            </div>
                                        </div>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-danger bg-card2">
                            <div class="card-body">


                                <a href="{{ route('doctor.patient.medicen', Crypt::encryptString($patient->id)) }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-bell fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white">الأدويه</span>
                                            <h3 class="mb-0 text-white">{{ $medicens }}</h3>
                                        </div>

                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card3">
                            <div class="card-body">
                                <a
                                    href="{{ route('doctor.patient.test.index', ['id' => Crypt::encryptString($patient->id)]) }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-th-large fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white">الفحوصات</span>
                                            <h3 class="mb-0 text-white">{{ $tests }}</h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card4">
                            <div class="card-body">
                                <a href="{{ route('doctor.patient.ray', ['id' => Crypt::encryptString($patient->id)]) }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-database fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white"> الأشعة</span>
                                            <h3 class="mb-0 text-white">{{ $rays }}</h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card4">
                            <div class="card-body">
                                <a
                                    href="{{ route('doctor.patient.disease.index', ['id' => Crypt::encryptString($patient->id)]) }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-heartbeat fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white"> الأمراض المزمنة </span>
                                            <h3 class="mb-0 text-white">{{ $diseases }}</h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card4">
                            <div class="card-body">
                                <a
                                    href="{{ route('doctor.patient.surgery.index', ['id' => Crypt::encryptString($patient->id)]) }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-heartbeat fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white"> العمليات </span>
                                            <h3 class="mb-0 text-white">{{ $surgeries }}</h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <hr />
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-danger bg-card4">
                            <div class="card-body">
                                <a
                                    href="{{ route('doctor.patient.children.index', ['pid' => Crypt::encryptString($patient->id)]) }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-database fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white"> المعالين</span>
                                            <h3 class="mb-0 text-white">{{ $children }}</h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </div>
    </div>
    </div>

    <!-- edit  ILL -->
    <div class="modal fade selectRefresh" id="editIll" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal">تعديل الحالة الاجتماعية</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('doctor.patient.status.update') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        @method('PUT')
                        <input type="hidden" value="{{ $patient->id }}" name="number" id="number" />
                        <div class="col">
                            <div class="form-group">
                                <select class="form-control form-select" id="validationCustom05" required name="status">
                                    <option value="0">عازب</option>
                                    <option value="1">متزوج</option>
                                </select>
                            </div>

                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- End section content -->

    <!-- edit  BloodType -->
    <div class="modal fade selectRefresh" id="booldType" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal">تعديل الحالة الاجتماعية</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('doctor.patient.bloodtype.update') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        @method('PUT')
                        <input type="hidden" value="{{ $patient->id }}" name="number" id="number" />
                        <div class="col">
                            <div class="form-group">
                                <div class="col-lg-12">
                                    <select id="validationCustom05" required class="form-control form-select"
                                        id="blood_type" name="blood_type">
                                        <option>A+</option>
                                        <option>A-</option>
                                        <option>B+</option>
                                        <option>B-</option>
                                        <option>AB+</option>
                                        <option>AB-</option>
                                        <option>O-</option>
                                        <option>O+</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- End section content -->
    <!-- edit  BloodType -->
    <div class="modal fade selectRefresh" id="heightAndWeight" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal">تعديل الطول و الوزن </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('doctor.patient.heightandweight.update') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        @method('PUT')
                        <input type="hidden" value="{{ $patient->id }}" name="number" id="number" />
                        <div class="row">

                            <div class="col">
                                <div class="form-group">
                                    <input type="number" name="hight"  value="{{$patient->hight }}"
                                        class="form-control" placeholder="الطول" id="validationCustom05" required />


                                </div>
                                @error('hight')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror

                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <input type="number" name="weight" id="weight"  value="{{ $patient->weight }}"
                                        class="form-control" placeholder="الوزن" id="validationCustom05" required />
                                </div>
                                @error('weight')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- End section content -->

@endsection
