@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary"> الحجوزات</h4>

                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('doctor.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="{{ route('doctor.appointment') }}">الحجوزات</a>
                            </li>
                        </ol>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>الوقت</th>
                                                <th>التاريخ</th>
                                                <th>أسم المريض</th>
                                                <th>رقم الهاتف</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($appointments as $appointement)
                                                <tr>
                                                    <td>{{ $appointement->time }}</td>
                                                    <td>{{ $appointement->date }}</td>
                                                    <td>{{ $appointement->patient->user->person->name }}</td>
                                                    <td>{{ $appointement->patient->user->phone_number }}</td>
                                                    @if ($appointement->status == 0)
                                                        <td class="text-start"> <span class="badge btn-danger">تم رفض
                                                                الحجز</span>
                                                        </td>
                                                    @elseif ($appointement->status == 1)
                                                        <td class="text-start"> <span class="badge btn-primary">تم تاكيد
                                                                الحجز</span>
                                                        </td>
                                                    @else
                                                        <td class="text-start"> <span class="badge btn-warning"> قيد
                                                                الانتظار </span>
                                                        </td>
                                                    @endif

                                                    @if ($appointement->status == 2)
                                                        <td class="float-center">

                                                            <form method="POST"
                                                                action="{{ route('doctor.appointment.updateStatus') }}">
                                                                @csrf

                                                                <input name="number" value="{{ $appointement->id }}"
                                                                    type="hidden" />
                                                                <button name="status" type="submit" value="1"
                                                                    class='btn btn-primary'>
                                                                    تاكيد الحجز
                                                                </button>

                                                            </form>
                                                            <br />

                                                            <form method="POST"
                                                                action="{{ route('doctor.appointment.updateStatus') }}">
                                                                @csrf
                                                                <input name="number" value="{{ $appointement->id }}"
                                                                    type="hidden" />
                                                                <button name="status" type="submit" value="0"
                                                                    class='btn btn-danger'>
                                                                    الغاء الحجز
                                                                </button>
                                                            </form>
                                                        </td>
                                                    @endif



                                                </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->
@endsection
