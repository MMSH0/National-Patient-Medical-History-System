@extends('layout.doctor_layout')
@section('content')


        <!-- start section content -->
        <div class="content-body">
            <div class="warper container-fluid">
                <div class="new_appointment main_container">
                    <div class="row page-titles mx-0">
                        <div class="col-sm-6 p-md-0">
                            <div class="welcome-text">
                                <h4 class="text-primary">الأبناء</h4>
                                <p class="mb-0">اضافة الأبناء</p>
                            </div>


                        </div>
                        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{route('doctor.index')}}">الرئيسية</a></li>
                                <li class="breadcrumb-item active"><a href="#">الأبناء</a>
                                </li>
                            </ol>
                        </div>


                    </div>


                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card shadow">
                                <div class="card-header fix-card">
                                    <div class="row">
                                        <div class="col-8">
                                            <h4 class="card-title">الأبناء</h4>
                                        </div>
                                        <div class="col-4">
                                            <a type="button" href="{{route('doctor.patient.children.add',['pid'=>  Crypt::encryptString($pid)]) }}" class="btn btn-primary float-end">
                                                إضافة الأبناء </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="example1" class="display nowrap">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>اسم المريض</th>
                                                    <th> العمر </th>
                                                    <th>العائل</th>
                                                    <th>السجل الطبي</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                               @foreach ($children as $child)
                                                <tr>
                                                    <td>#{{ ++$index }}</td>
                                                    <td>{{ $child->person->name }}</td>
                                                    <td> {{ \Carbon\Carbon::parse($child->person->birthDate)->age }} </td>
                                                    <td>{{ $child->relationship }}</td>
                                                    <td class="float-center">
                                                        <a href="{{ route('doctor.patient.children.info' , ['pid'=>Crypt::encryptString($child->child_id)] ) }}" class='btn btn-primary mr-4'>
                                                            عرض
                                                        </a>

                                                    </td>
                                                </tr>
                                               @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End section content -->

@endsection
