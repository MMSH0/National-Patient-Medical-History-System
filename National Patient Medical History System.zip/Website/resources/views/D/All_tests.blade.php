@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="All-Tests main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">الفحوصات</h4>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('doctor.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">الفحوصات</a>
                            </li>
                        </ol>
                    </div>
                </div>



                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-8">
                                        <h4 class="card-title"> الفحوصات </h4>
                                    </div>
                                    <div class="col-2">
                                        <a href="{{ route('doctor.patient.test.add', ['id' => Crypt::encryptString($id)]) }}"
                                            class="btn btn-primary float-end"> أضافة فحص</a>

                                    </div>
                                    <div class="col-2">
                                    <a href="{{ route('doctor.patient.report.test', ['id' => Crypt::encryptString($id)]) }}"
                                        class="btn btn-primary float-end">اصدار تقرير</a>
                                </div>

                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم الفحص</th>
                                                <th>نوع الفحص</th>
                                                <th> تاريخ اضافة الفحص </th>
                                                <th>مرتفع</th>
                                                <th>طبيعي</th>
                                                <th>منخفض</th>
                                                <th>النتيجة</th>
                                                <th> وقت ظهور النتيجة</th>
                                                <th> تاريخ ظهور النتيجة</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($tests as $test)
                                                <tr>
                                                    <td>{{ ++$index }}</td>
                                                    <td>{{ $test->test->name }}</td>
                                                    <td>{{ $test->test->test_type->name }}</td>
                                                    <td>{{ $test->created_at }}</td>
                                                    <td>{{ $test->test->high }}</td>
                                                    <td>{{ $test->test->normal }}</td>
                                                    <td>{{ $test->test->low }}</td>
                                                    @if (isset($test->result))
                                                        <td>{{ $test->result }}</td>
                                                        <td>{{ $test->test_time }}</td>
                                                        <td>{{ $test->test_date }}</td>
                                                    @else
                                                        <td><a href="#" class="btn btn-danger"> لم يتم اضافة
                                                                النتيجة</a></td>
                                                        <td><a href="#" class="btn btn-danger"> انتظر ...</a></td>
                                                        <td><a href="#" class="btn btn-danger"> انتظر ... </a></td>
                                                    @endif

                                                </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->
@endsection
