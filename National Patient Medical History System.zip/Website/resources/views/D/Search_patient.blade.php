@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_prescription main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary"> البحث عن مريض </h4>
                            <p class="mb-0"> رقم الهاتف \ رقم الهوية \ الاسم </p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"> البحث عن مريض </a></li>
                            <li class="breadcrumb-item active"><a href="#"> مرضى </a>
                            </li>
                        </ol>
                    </div>
                </div>
                  {{-- message --}}
                  @if (session('success'))
                  <div class="container mt-5" id="successAlert">
                      <div class="alert alert-success alert-dismissible fade show" role="alert">
                          <span class="message">{{ session('success') }}</span>
                          <div class="progress" style="height: 2px;">
                              <div class="progress-bar bg-success flex-row-reverse mr-auto ml-auto" role="progressbar"
                                  style="width:0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"
                                  id="progressBar"></div>
                          </div>
                      </div>

                  </div>
              @endif

              @if (session('error'))
                  <div class="container mt-5" id="successAlert">
                      <div class="alert alert-danger alert-dismissible fade show" role="alert">
                          <span class="message">{{ session('error') }}</span>
                          <div class="progress" style="height: 2px;">
                              <div class="progress-bar bg-danger flex-row-reverse mr-auto ml-auto" role="progressbar"
                                  style="width:0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"
                                  id="progressBar"></div>
                          </div>
                      </div>

                  </div>
              @endif
              {{-- message --}}

                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow mb-4">
                            <div class="card-header">
                                <h4 class="card-title">معلومات المريض </h4>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="{{ route('doctor.patients.search') }}" class="form-inline">
                                    @csrf
                                    <div class="form-group mx-sm-3 mb-2">
                                        <label  class="sr-only testLabel">البحث بالاسم</label>
                                        <input type="text" name="personalName" class="form-control"
                                            placeholder="البحث بالاسم">
                                    </div>
                                    <div class="form-inline" style="display: inline-flex">
                                        <div class="form-group mx-sm-3 mb-2">
                                            <label  class="sr-only testLabel">رقم  الهوية</label>
                                            <input type="number" name="identityCard" class="form-control"
                                                placeholder="xxxxxxxxxxxxxxxx">
                                        </div>
                                        <div class="form-group mx-sm-3 mb-2">
                                            <label class="sr-only testLabel">رقم الهاتف</label>
                                            <input type="number" name="numberPhone" id="numberPhone" class="form-control"
                                                placeholder="7xxxxxxxxxxxxx">
                                        </div>
                                        <button style="height: 3rem;
                                        align-self: flex-end;" type="submit" class="btn btn-primary mb-2">بحث </button>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>




                    @if (isset($all_patient))
                        <div class="card shadow">

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">ID</th>
                                                <th scope="col">صورة المريض</th>
                                                <th scope="col">اسم المريض</th>
                                                <th scope="col"> الجنس </th>
                                                <th scope="col"> العمر </th>
                                                <th scope="col"> رقم الهاتف </th>
                                                <th scope="col"> رقم الهوية </th>
                                                <th scope="col"> Action </th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach ($all_patient as $patient)
                                                <tr>
                                                    <td>#{{ ++$index }}</td>
                                                    @if ($patient->gender == 0 || !isset( $patient->img ))
                                                    <td><img loading="lazy" class="rounded-image"
                                                            src="{{ asset('images/client.jpg') }}"></td>
                                                    @else
                                                    <td><img loading="lazy" class="rounded-image"
                                                        src="{{ asset('patient/profile') }}/{{ $patient->img }}"></td>
                                                    @endif
                                                    <td>{{ $patient->name }} </td>
                                                    @if ($patient->gender == 0)
                                                        <td> انثى </td>
                                                    @else
                                                        <td> ذكر </td>
                                                    @endif
                                                    <td> {{ \Carbon\Carbon::parse($patient->birthDate)->age }}</td>

                                                    <td> {{ $patient->phone_number }}</td>
                                                    <td> {{ $patient->indentityCardNumber }}</td>

                                                    <td class="text-start">
                                                        <form method="GET" action="{{ route('doctor.patient.verfication',['id'=>Crypt::encryptString($patient->patientId)]) }}" >
                                                            @csrf

                                                            <button type="submit" class="btn btn-primary"> عرض </button>

                                                        </form>
                                                    </td>
                                                </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    @endif

                    @if (isset($users))
                    <div class="card shadow">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">اسم المريض</th>
                                        <th scope="col">صورة المريض</th>
                                        <th scope="col"> الجنس </th>
                                        <th scope="col"> العمر </th>
                                        <th scope="col"> رقم الهاتف </th>
                                        <th scope="col"> رقم الهوية </th>
                                        <th scope="col"> Action </th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @foreach ($users as $user)
                                        <tr>
                                            <td>#{{ ++$index }}</td>
                                            @if ($user->gender == 0 || !isset( $user->img ))
                                            <td><img loading="lazy" class="rounded-image"
                                                    src="{{ asset('images/client.jpg') }}"></td>
                                            @else
                                            <td><img loading="lazy" class="rounded-image"
                                                src="{{ asset('patient/profile') }}/{{ $user->img }}"></td>
                                            @endif
                                            <td> {{ $user->name }}</td>

                                            @if ($user->gender == 0)
                                                <td> انثى </td>
                                            @else
                                                <td> ذكر </td>
                                            @endif
                                            <td> {{ \Carbon\Carbon::parse($user->birthDate)->age }}</td>
                                            <td>{{ $user->phone_number }} </td>
                                            <td>{{ $user->indentityCardNumber }} </td>
                                            <td class="text-start">
                                                <form method="GET" action="{{ route('doctor.patient.verfication',['id'=>Crypt::encryptString($user->id)]) }}" >
                                                    @csrf

                                                    <button type="submit" class="btn btn-primary"> عرض </button>

                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach

                                </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- End section content -->





@endsection
