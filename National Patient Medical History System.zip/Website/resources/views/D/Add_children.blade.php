@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->

    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new-patients main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">الاطباء</h4>
                        </div>
                    </div>
                     <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex"> `
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('doctor.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active">
                            </li>
                        </ol>
                    </div>
                </div>
                {{-- message --}}
                @if (session('success'))
                    <div class="container mt-5" id="successAlert">
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <span class="message">{{ session('success') }}</span>
                            <div class="progress" style="height: 2px;">
                                <div class="progress-bar bg-success flex-row-reverse mr-auto ml-auto" role="progressbar"
                                    style="width:0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"
                                    id="progressBar"></div>
                            </div>
                        </div>

                    </div>
                @endif

                @if (session('error'))
                    <div class="container mt-5" id="successAlert">
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <span class="message">{{ session('error') }}</span>
                            <div class="progress" style="height: 2px;">
                                <div class="progress-bar bg-success flex-row-reverse mr-auto ml-auto" role="progressbar"
                                    style="width:0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"
                                    id="progressBar"></div>
                            </div>
                        </div>

                    </div>
                @endif
                {{-- message --}}
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">بيانات المريض</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form method="POST" class="needs-validation" novalidate
                                        action="{{ route('doctor.patient.children.store') }}">
                                        @csrf
                                        <input type="hidden" name="number" value="{{ $pid }}"/>
                                        <div class="row">

                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" placeholder="الأسم الاول"
                                                        name="name"  value="{{ old('name') }}" id="validationCustom05" required />
                                                </div>
                                                @error('name')
                                                <span class="error-message">{{ $message }}</span>
                                            @enderror
                                                <div class="form-group">
                                                    <input type="text" class="form-control" placeholder="اللقب"
                                                        name="last_name" value="{{ old('last_name') }}" id="validationCustom05" required />
                                                </div>
                                                @error('last_name')
                                                <span class="error-message">{{ $message }}</span>
                                            @enderror


                                                <div class="form-group">
                                                    <input type="text" name="weight" value="{{ old('weight') }}" class="form-control"
                                                        placeholder="الوزن" id="validationCustom05" required />
                                                </div>
                                                @error('weight')
                                                <span class="error-message">{{ $message }}</span>
                                            @enderror
                                                <div class="form-group">
                                                    <div class="col-lg-12">
                                                        <select id="validationCustom05" required
                                                            class="form-control form-select" name="City">
                                                            <option>صنعاء</option>
                                                            <option>تعز</option>
                                                            <option>عدن</option>
                                                            <option>اب</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <div class="col-lg-12">
                                                        <select id="validationCustom05" required
                                                            class="form-control form-select" name="relationship">
                                                            <option>صلة القرابه</option>
                                                            <option>أب</option>
                                                            <option>أم</option>
                                                            <option>أخ</option>
                                                            <option>أخت</option>
                                                            <option>عم</option>
                                                            <option>عمه</option>
                                                            <option>خال</option>
                                                            <option>خالت</option>
                                                        </select>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <select id="validationCustom05" required
                                                        class="form-control form-select" name="Gender">
                                                        <option value="1">ذكر</option>
                                                        <option value="0">انثى</option>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <input type="date" data-date-format="yyyy-mm-dd" class="form-control"
                                                        placeholder=" تاريخ الميلاد" name="birthday" value="{{ old('birthday') }}"
                                                        id="validationCustom05" required />
                                                </div>
                                                @error('birthday')
                                                <span class="error-message">{{ $message }}</span>
                                            @enderror
                                                <div class="form-group">
                                                    <input type="text" name="hight" value="{{ old('hight') }}" class="form-control"
                                                        placeholder="الطول" id="validationCustom05" required />
                                                </div>
                                                @error('hight')
                                                <span class="error-message">{{ $message }}</span>
                                            @enderror

                                                <div class="form-group">
                                                    <div class="col-lg-12">
                                                        <select id="validationCustom05" required
                                                            class="form-control form-select" name="blood_type">

                                                            <option>A+</option>
                                                            <option>A-</option>
                                                            <option>B+</option>
                                                            <option>B-</option>
                                                            <option>AB+</option>
                                                            <option>AB-</option>
                                                            <option>O-</option>
                                                            <option>O+</option>
                                                        </select>
                                                    </div>

                                                </div>

                                                <div class="form-group">
                                                    <input type="text" name="address" value="{{ old('address') }}" class="form-control"
                                                        placeholder="العنوان" id="validationCustom05" required />
                                                </div>
                                                @error('address')
                                                <span class="error-message">{{ $message }}</span>
                                            @enderror

                                            </div>



                                        </div>


                                        <div class="row">
                                            <div class="col-xl-4">
                                                <button type="submit" class="btn btn-primary"  >انشاء الحساب</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>





            </div>
        </div>
    </div>
    <!-- End section content -->
@endsection
