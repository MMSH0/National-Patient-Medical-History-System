@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">التشخيصات</h4>
                            <p class="mb-0">اضافة تشخيص</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('doctor.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">التشخيصات</a>
                            </li>
                        </ol>
                    </div>
                </div>






                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-8">
                                        <h4 class="card-title">التشخيصات</h4>
                                    </div>
                                    <div class="col-2">
                                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                            data-bs-target="#addDrugs"> اضافة تشخيص</button>
                                    </div>
                                    <div class="col-2">
                                        <a href="{{route('doctor.patient.report.diagnoes', ['id' => Crypt::encryptString($id)])}}" class="btn btn-primary float-end"
                                            > اصدار تقرير</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>التشخيص</th>
                                                <th>الوصف</th>
                                                <th>التاريخ</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach ($patientDiagnoses as $patientdiagnose)
                                                <tr>
                                                    <td>{{ ++$index }}</td>
                                                    <td>{{ $patientdiagnose->diagnosis->name }}</td>
                                                    <td>{{ $patientdiagnose->notes }}</td>
                                                    <td>{{ $patientdiagnose->diagnosis_date }}</td>
                                                    <td class="text-start">

                                                        @if (
                                                            $patientdiagnose->doctor_id == Auth::user()->doctor->id &&
                                                                !\Carbon\Carbon::now()->greaterThanOrEqualTo(\Carbon\Carbon::parse($patientdiagnose->diagnosis_date)))
                                                            <a data-bs-toggle='modal' data-bs-target='#editDiagnose'
                                                                class='mr-4'
                                                                onclick="populateEditModal('{{ $patientdiagnose->id }}','{{ $patientdiagnose->doctor_id }}','{{ $patientdiagnose->notes }}');">
                                                                <span class='fas fa-pencil-alt tbl-edit'></span>
                                                            </a>
                                                        @else
                                                            <a href="#" class="btn btn-danger">لا يمكنك تعديل على
                                                                البيانات</a>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->



    <!-- change date and time diagnose -->
    <div class="modal fade selectRefresh" id="addDrugs" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> أضافة تشخيص </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('doctor.patient.diagnose.store') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        <div class="col-lg-12">
                            <div class="row">
                                <label for="validationCustom05" class="form-label"> التشخيص </label>

                                <div class="col-12">
                                    <fieldset>

                                        <!-- Radio buttons for selected tests -->
                                        <div class="d-flex flex-wrap">
                                            @foreach ($diagnoses as $diagnose)
                                                <div class="checkbox-card" onclick="toggleCheckboxCard(event)">
                                                    <input class="custom-control-input" type="checkbox" name="diagnosis[]"
                                                        value="{{ $diagnose->id }}">
                                                    <label class="form-check-label">{{ $diagnose->name }}</label>
                                                </div>
                                            @endforeach


                                        </div>


                                    </fieldset>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="validationCustom05">ملاحضة</label>
                                <textarea class="form-control" rows="3" value="{{ old('notes') }}" name="notes" id="notes"
                                    id="validationCustom05" required></textarea>

                                <input type="hidden" name="Doctor_Id" value="{{ Auth::user()->doctor->id }}">
                                <input type="hidden" name="number" value="{{ Crypt::encryptString($id) }}">
                            </div>
                            @error('notes')
                                <span class="error-message">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal"
                                aria-label="Colse">إغلاق</button>
                            <button type="submit" class="btn btn-primary" name ="submit">حفظ البيانات</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit Diagnose -->
    <div class="modal fade selectRefresh" id="editDiagnose" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> تعديل التشخيص </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('doctor.patient.diagnose.update') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        @method('PUT')
                        <div class="row">
                            <input type="hidden" name="id" id="editDai">
                            <input type="hidden" name="did" id="dId">
                            <div class="col-12">
                                <fieldset>
                                    <label for="validationCustom05" class="form-label"> التشخيص </label>
                                    <!-- Radio buttons for selected tests -->
                                    <div class="d-flex flex-wrap">
                                        @foreach ($diagnoses as $diagnose)
                                            <div class="checkbox-card" onclick="toggleCheckboxCard(event)">
                                                <input class="custom-control-input" type="checkbox" name="diagnosis[]"
                                                    value="{{ $diagnose->id }}">
                                                <label class="form-check-label">{{ $diagnose->name }}</label>
                                            </div>
                                        @endforeach


                                    </div>


                                </fieldset>
                            </div>
                        </div>

                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="validationCustom05"> التشخيص </label>
                                <textarea value="{{ old('notes') }}" name="notes" id="notes" class="form-control" rows="3"
                                    id="validationCustom05" required> </textarea>

                            </div>
                            @error('notes')
                                <span class="error-message">{{ $message }}</span>
                            @enderror
                            <input type="hidden" name="Doctor_Id" value={{ Auth::user()->doctor->id }}>
                            <input type="hidden" name="number" value="{{ Crypt::encryptString($id) }}">
                        </div>
                        <div class="modal-footer">

                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal"
                                    aria-label="Colse">إغلاق</button>
                                <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                            </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

    </div>
    <!-- change date and time diagnose -->
    <script>
        function populateEditModal(id, did, notes) {
            document.getElementById('editDai').value = id;
            document.getElementById('dId').value = did;

            document.getElementById('diagnoseNotes').value = notes;
        }

        /*  ==========================================
            Filter test
        * ========================================== */


        // Function to update the test options based on the selected category
        function updateTestList() {
            const testData = {

                // Add more categories and tests as needed
            };
            fetchDoctorTests();

            const testOptionsContainer = document.getElementById('testOptions');

            const categorySelect = document.querySelector('input[name="testCategory"]:checked');

            const selectedCategory = categorySelect ? categorySelect.value : null;

            // Clear existing options
            testOptionsContainer.innerHTML = '';

            // Populate the test options based on the selected category
            if (selectedCategory) {
                testData[selectedCategory].forEach(test => {
                    const div = document.createElement('div');
                    div.classList.add('checkbox-card');
                    div.onclick = toggleCheckboxCard;

                    const input = document.createElement('input');
                    input.classList.add('custom-control-input');
                    input.type = 'checkbox';
                    input.name = 'selectedTest';
                    input.value = test;

                    const label = document.createElement('label');
                    label.classList.add('form-check-label');
                    label.textContent = test;

                    div.appendChild(input);
                    div.appendChild(label);

                    testOptionsContainer.appendChild(div);
                });
            }
        }

        // Call the updateTestList function to populate the test options on page load
        updateTestList();



        function toggleCheckboxCard(event) {
            const testSelectedContainer = document.getElementById('testSelected');

            const checkboxCard = event.currentTarget;
            const checkbox = checkboxCard.querySelector('input[type="checkbox"]');
            const div = document.createElement('div');


            const input = document.createElement('input');
            input.classList.add('custom-control-input');
            input.type = 'button';
            input.name = 'selectedTest';
            input.value = checkbox.value;

            div.classList.add('checkbox-card');


            const label = document.createElement('label');
            label.classList.add('form-check-label');
            label.textContent = checkbox.value;

            div.appendChild(input);
            div.appendChild(label);

            checkbox.checked = !checkbox.checked;

            checkboxCard.classList.toggle('checked', checkbox.checked);

            if (checkbox.checked) {
                testSelectedContainer.appendChild(checkboxCard);
            } else {
                testOptionsContainer.appendChild(checkboxCard);

            }

        }
    </script>
@endsection
