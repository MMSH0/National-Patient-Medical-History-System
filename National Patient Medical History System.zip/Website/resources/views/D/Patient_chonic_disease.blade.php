@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="All-Rays main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">الأمراض المزمنة</h4>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="/">الأمراض المزمنة</a>
                            </li>
                        </ol>
                    </div>
                </div>


                {{-- message --}}

                @if (session('success'))
                <script>
                    showSuccessAlert('{{ session('success') }}'); // Call the function directly if obj is not null
                </script>
            @endif

                @if (session('error'))
                    <div class="container mt-5" id="successAlert">
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <span class="message">{{ session('error') }}</span>
                            <div class="progress" style="height: 2px;">
                                <div class="progress-bar bg-danger flex-row-reverse mr-auto ml-auto" role="progressbar"
                                    style="width:0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"
                                    id="progressBar"></div>
                            </div>
                        </div>

                    </div>
                @endif
                {{-- message --}}

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-8">
                                        <h4 class="card-title"> الأمراض المزمنة </h4>
                                    </div>
                                    <div class="col-2">
                                        <a data-bs-toggle="modal" data-bs-target="#addIll"
                                            class="btn btn-primary float-end"> اضافة مرض مزمن</a>
                                    </div>
                                    <div class="col-2">
                                        <a href="{{ route('doctor.patient.report.chronicDieases', ['id' => Crypt::encryptString($id)]) }}" class="btn btn-primary float-end">اصدار تقرير</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم المرض المزمن</th>
                                                <th>الوصف</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($diseases as $disease)
                                                <tr>
                                                    <td>{{ ++$index }}</td>
                                                    <td>{{ $disease->disease->name }}</td>
                                                    <td>{{ $disease->note }}</td>

                                                </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->


    <!-- change date and time patient -->
    <div class="modal fade selectRefresh" id="addIll" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> أضافة مرض مزمن </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">

                    <form method="POST" action="{{ route('doctor.patient.disease.store') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        <div class="row">
                            <div class="col-12">
                                <fieldset>

                                    <!-- Radio buttons for selected tests -->
                                    <div class="d-flex flex-wrap">
                                        @foreach ($all_diseases as $disease)
                                            <div class="checkbox-card" onclick="toggleCheckboxCard(event)">
                                                <input class="custom-control-input" type="checkbox" name="selectedTest[]"
                                                    value="{{ $disease->id }}">
                                                <label class="form-check-label">{{ $disease->name }}</label>
                                            </div>
                                        @endforeach


                                    </div>


                                </fieldset>
                            </div>
                        </div>
                        <input type="hidden" value="{{ $id }}" name="number">
                        <div class="row">

                            <div class="col-12">
                                <div class="form-group">
                                    <label>ملاحظات</label>
                                    <textarea class="form-control" value="{{ old('notes') }}" name="notes" id="validationCustom05" required
                                        rows="3"></textarea>
                                </div>
                                @error('notes')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">إغلاق</button>
                            <button type="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <script>
        /*  ==========================================
        Filter test
    * ========================================== */


        // Function to update the test options based on the selected category
        function updateTestList() {
            const testData = {
                bloodTests: ['Complete Blood Count', 'Blood Glucose Test'],
                cardiacTests: ['Electrocardiogram', 'Stress Test']
                // Add more categories and tests as needed
            };
            fetchDoctorTests();

            const testOptionsContainer = document.getElementById('testOptions');

            const categorySelect = document.querySelector('input[name="testCategory"]:checked');

            const selectedCategory = categorySelect ? categorySelect.value : null;

            // Clear existing options
            testOptionsContainer.innerHTML = '';

            // Populate the test options based on the selected category
            if (selectedCategory) {
                testData[selectedCategory].forEach(test => {
                    const div = document.createElement('div');
                    div.classList.add('checkbox-card');
                    div.onclick = toggleCheckboxCard;

                    const input = document.createElement('input');
                    input.classList.add('custom-control-input');
                    input.type = 'checkbox';
                    input.name = 'selectedTest';
                    input.value = test;

                    const label = document.createElement('label');
                    label.classList.add('form-check-label');
                    label.textContent = test;

                    div.appendChild(input);
                    div.appendChild(label);

                    testOptionsContainer.appendChild(div);
                });
            }
        }

        // Call the updateTestList function to populate the test options on page load
        updateTestList();



        function toggleCheckboxCard(event) {
            const testSelectedContainer = document.getElementById('testSelected');

            const checkboxCard = event.currentTarget;
            const checkbox = checkboxCard.querySelector('input[type="checkbox"]');
            const div = document.createElement('div');


            const input = document.createElement('input');
            input.classList.add('custom-control-input');
            input.type = 'button';
            input.name = 'selectedTest';
            input.value = checkbox.value;

            div.classList.add('checkbox-card');


            const label = document.createElement('label');
            label.classList.add('form-check-label');
            label.textContent = checkbox.value;

            div.appendChild(input);
            div.appendChild(label);

            checkbox.checked = !checkbox.checked;

            checkboxCard.classList.toggle('checked', checkbox.checked);

            if (checkbox.checked) {
                testSelectedContainer.appendChild(checkboxCard);
            } else {
                testOptionsContainer.appendChild(checkboxCard);

            }

        }
    </script>
@endsection
