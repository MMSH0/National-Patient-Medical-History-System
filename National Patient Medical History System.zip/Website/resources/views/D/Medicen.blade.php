@extends('layout.doctor_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">العلاجات</h4>
                            <p class="mb-0">اضافة علاج</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('doctor.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a
                                    href="{{ route('doctor.patient.medicen', ['id' => $id]) }}">العلاجات</a>
                            </li>
                        </ol>
                    </div>
                </div>





                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-8">
                                        <h4 class="card-title">العلاجات</h4>
                                    </div>
                                    <div class="col-2">
                                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                            data-bs-target="#addDrugs"> اضافة علاج</button>

                                    </div>
                                    <div class="col-2">
                                        <a href="{{route('doctor.patient.report.medicen',['id' => Crypt::encryptString($id)])}}" class="btn btn-primary float-end"> اصدار تقرير</a>

                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم العلاج</th>
                                                <th>الاسم العلمي</th>
                                                <th>اسم الشركة المصنعه</th>
                                                <th>عدد المرات</th>
                                                <th>المده</th>
                                                <th>الوصف</th>
                                                <th>التاريخ</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach ($prescriptions as $prescription)
                                                <tr>
                                                    <td>{{ ++$index }}</td>
                                                    <td>{{ $prescription->medicen->name }}</td>
                                                    <td>{{ $prescription->medicen->scientific_name }}</td>
                                                    <td>{{ $prescription->medicen->company_name }}</td>
                                                    <td>{{ $prescription->how_many_times }}</td>
                                                    <td>{{ $prescription->usage_times }}</td>
                                                    <td>{{ $prescription->note }}</td>
                                                    <td>{{ $prescription->created_at }}</td>
                                                    <td class="text-start">

                                                        @if (
                                                            $prescription->doctor_id == Auth::user()->doctor->id &&
                                                                !\Carbon\Carbon::now()->greaterThanOrEqualTo(\Carbon\Carbon::parse($prescription->created_at)))
                                                            <a data-bs-toggle='modal' data-bs-target='#editDrugs'
                                                                class='mr-4'
                                                                onclick="populateEditModal('{{ $prescription->id }}','{{ $prescription->note }}');">
                                                                <span class='fas fa-pencil-alt tbl-edit'></span>
                                                            </a>
                                                        @else
                                                            <a href="#" class="btn btn-danger">لا يمكنك تعديل على
                                                                البيانات</a>
                                                        @endif
                                                    <td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->

    <!-- change date and time medicen -->
    <div class="modal fade selectRefresh" id="addDrugs" tabindex="-1" role="dialog" data-bs-target="#editDrugs"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> أضافة علاج </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form class="row align-items-start needs-validation" novalidate method="POST"
                        action="{{ route('doctor.patient.medicen.store') }}">
                        @csrf
                        <input type="hidden" value="{{ Crypt::encryptString($id) }}" name="patient_id">
                        <div class="col">
                            <div class="row">
                                <div class="col-12">
                                    <h5 class="text-primary">الاسم العلمي</h5>
                                    <fieldset>

                                        <!-- Radio buttons for selected medicen -->
                                        <div class="d-flex flex-wrap">
                                            @foreach ($types as $type)
                                                <div class="checkbox-card" onclick="toggleCheckboxCard(event)">
                                                    <input class="custom-control-input" type="checkbox" name="selectedMed[]"
                                                        value="{{ $type->id }}">
                                                    <label class="form-check-label">{{ $type->scientific_name }}</label>
                                                </div>
                                            @endforeach


                                        </div>


                                    </fieldset>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> المدة </label>
                                    <select id="validationCustom05" required class="form-control form-select"
                                        name="usage_times">
                                        <option value=1>يوم </option>
                                        <option value=2> اسبوع</option>
                                        <option value=3>شهر </option>
                                        <option value=4>6 اشهر </option>
                                        <option value=5>سنة </option>

                                    </select>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> عدد المرات </label>
                                    <select id="validationCustom05" required class="form-control form-select"
                                        name="how_many_times">
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                        <option>6</option>
                                        <option>7</option>
                                        <option>8</option>
                                        <option>9</option>
                                        <option>10</option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="validationCustom05" class="form-label"> وصف العلاج </label>
                                <textarea id="validationCustom05" value="{{ old('notes') }}" name="notes" id="notes" required
                                    class="form-control" rows="3" name="note"> </textarea>
                            </div>
                            @error('notes')
                                <span class="error-message">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal"
                                aria-label="Close">إغلاق</button>
                            <button type="submit" class="btn btn-primary" name ="submit">حفظ البيانات</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>



    <!-- Edit Drug -->
    <div class="modal fade selectRefresh" id="editDrugs" tabindex="-1" role="dialog" data-bs-target="editDrugs"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> تعديل علاج </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('doctor.patient.medicen.update') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        @method('PUT')
                        <input type="hidden" id="number" name="number">
                        <input type="hidden" value="{{ Auth::user()->doctor->id }}" name="dnumber">
                        <input type="hidden" value="{{ Crypt::encryptString($id) }}" name="patient_id">

                        <div class="col">
                            <div class="row">
                                <div class="col-12">
                                    <h5 class="text-primary">الاسم العلمي</h5>
                                    <fieldset>

                                        <!-- Radio buttons for selected medicen -->
                                        <div class="d-flex flex-wrap">
                                            @foreach ($types as $type)
                                                <div class="checkbox-card" onclick="toggleCheckboxCard(event)">
                                                    <input class="custom-control-input" type="checkbox"
                                                        name="selectedMed[]" value="{{ $type->id }}">
                                                    <label class="form-check-label">{{ $type->name }}</label>
                                                </div>
                                            @endforeach


                                        </div>


                                    </fieldset>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> المدة </label>
                                    <select id="validationCustom05" required class="form-control form-select"
                                        name="usage_times">
                                        <option value=1>يوم </option>
                                        <option value=2> اسبوع</option>
                                        <option value=3>شهر </option>
                                        <option value=4>6 اشهر </option>
                                        <option value=5>سنة </option>

                                    </select>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> عدد المرات </label>
                                    <select id="validationCustom05" required class="form-control form-select"
                                        name="how_many_times">
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                        <option>6</option>
                                        <option>7</option>
                                        <option>8</option>
                                        <option>9</option>
                                        <option>10</option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="validationCustom05" class="form-label"> وصف العلاج </label>
                                <textarea id="editnote" id="validationCustom05" required class="form-control" rows="3" name="note"> </textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal"
                                aria-label="Close">إغلاق</button>
                            <button type="submit" class="btn btn-primary" name ="submit">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>



    </div>
    <!-- change date and time medicen -->
    <script>
        function populateEditModal(number, note) {
            document.getElementById('editnote').value = note;
            document.getElementById('number').value = number;
        }

        /*  ==========================================
            Filter test
        * ========================================== */


        // Function to update the test options based on the selected category
        function updateTestList() {
            const testData = {
                bloodTests: ['Complete Blood Count', 'Blood Glucose Test'],
                cardiacTests: ['Electrocardiogram', 'Stress Test']
                // Add more categories and tests as needed
            };

            const testOptionsContainer = document.getElementById('testOptions');

            const categorySelect = document.querySelector('input[name="testCategory"]:checked');

            const selectedCategory = categorySelect ? categorySelect.value : null;

            // Clear existing options
            testOptionsContainer.innerHTML = '';

            // Populate the test options based on the selected category
            if (selectedCategory) {
                testData[selectedCategory].forEach(test => {
                    const div = document.createElement('div');
                    div.classList.add('checkbox-card');
                    div.onclick = toggleCheckboxCard;

                    const input = document.createElement('input');
                    input.classList.add('custom-control-input');
                    input.type = 'checkbox';
                    input.name = 'selectedTest';
                    input.value = test;

                    const label = document.createElement('label');
                    label.classList.add('form-check-label');
                    label.textContent = test;

                    div.appendChild(input);
                    div.appendChild(label);

                    testOptionsContainer.appendChild(div);
                });
            }
        }

        // Call the updateTestList function to populate the test options on page load
        updateTestList();



        function toggleCheckboxCard(event) {
            const testSelectedContainer = document.getElementById('testSelected');

            const checkboxCard = event.currentTarget;
            const checkbox = checkboxCard.querySelector('input[type="checkbox"]');
            const div = document.createElement('div');


            const input = document.createElement('input');
            input.classList.add('custom-control-input');
            input.type = 'button';
            input.name = 'selectedTest';
            input.value = checkbox.value;

            div.classList.add('checkbox-card');


            const label = document.createElement('label');
            label.classList.add('form-check-label');
            label.textContent = checkbox.value;

            div.appendChild(input);
            div.appendChild(label);

            checkbox.checked = !checkbox.checked;

            checkboxCard.classList.toggle('checked', checkbox.checked);

            if (checkbox.checked) {
                testSelectedContainer.appendChild(checkboxCard);
            } else {
                testOptionsContainer.appendChild(checkboxCard);

            }

        }
    </script>
@endsection
