<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title }}</title>
</head>
<body>
    <img loading="lazy" src="{{ $image1 }}">
    <br/>
    <br/>
    <img loading="lazy" src="{{ $image2 }}">
    @isset ($image3)
    <br/>
    <br/>
    <img loading="lazy" src="{{ $image3 }}">
    @endisset
</body>
</html>
