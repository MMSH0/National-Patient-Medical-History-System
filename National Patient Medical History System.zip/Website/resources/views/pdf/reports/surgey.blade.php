<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">

    <title>Doctor Dashboard </title>
    <!-- Favicon icon -->

    <!-- Base Styling  -->
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <style>
        @font-face {
            font-family: 'DINNextLTArabic-Medium';
            font-style: normal;
            font-weight: normal;
            src: local('DINNextLTArabic-Medium'), local('DINNextLTArabic-Medium'), url("{{ storage_path('fonts/DINNextLTArabic-Medium.ttf') }}") format('truetype');
        }

        @font-face {
            font-family: 'DINNextLTArabic-Medium';
            font-style: normal;
            font-weight: bold;
            src: local('DINNextLTArabic-Medium'), local('DINNextLTArabic-Medium'), url("{{ storage_path('fonts/DINNextLTArabic-Medium.ttf') }}") format('truetype');
        }

        ,

        body,
        div,
        span,
        h4,
        h1,
        h2,
        h3,
        h5,
        h6,
        p,
        td,
        tr,
        .text-primary,
        .warper,
        .container-fluid,
        .text-danger,
        table,
        thead,
        tbody,
        * {
            direction: rtl !important;
            font-family: 'DINNextLTArabic-Medium' !important;
        }

        ,
    </style>

</head>

<body dir="rtl" style="background-color:#fff;">
    <div id="main-wrapper" class="show">
        <div class="warper container-fluid">
            <div class="All-Tests main_container">
                <div class="row page-titles mx-0">
                    <div class="row page-titles mx-0">
                        <div class="col p-md-10">
                            <br>
                            <center>
                                <div class="row">

                                    <div class="col">
                                        <img loading="lazy" width="250em" height="100em"
                                            src="{{ asset('images/logo.png') }}">
                                        <br>
                                        <br>
                                        <div class="col">
                                            <p class="text-primary"><span
                                                    class="text-danger">{{ Auth::user()->person->name }} </span>
                                                الدكتور
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </center>
                            <br>

                            <table style="    width:100%;">
                                <thead>



                                    <th style=" padding-left: 20px;padding-right: 20px;    text-align: right;">
                                        فصيلة الدم

                                    </th>

                                    <th style=" padding-left: 20px;padding-right: 20px;    text-align: right;">
                                        الطول
                                    </th>
                                    <th style=" padding-left: 20px;padding-right: 20px;    text-align: right;">
                                        الوزن
                                    </th>

                                    <th style=" padding-left: 20px;padding-right: 20px;    text-align: right;">
                                        الجنس
                                    </th>
                                    <th style=" padding-left: 20px;padding-right: 20px;    text-align: right;">
                                        العمر

                                    </th>
                                    <th style=" padding-left: 20px;padding-right: 20px;    text-align: right;">
                                        اسم المريض
                                    </th>
                                </thead>
                                <tbody>
                                    <tr>



                                        <td style=" padding-left: 20px;   text-align: center;">
                                            <p class="text-primary">
                                                {{ isset($patient->user) ? $patient->blood_type : $patient->patientchild->blood_type }}
                                            </p>
                                        </td>
                                        <td style=" padding-left: 20px;   text-align: center;">
                                            <p class="text-primary">
                                                {{ isset($patient->user) ? $patient->hight : $patient->patientchild->hight }}

                                            </p>
                                        </td>
                                        <td style=" padding-left: 20px;   text-align: center;">

                                            <p class="text-primary">
                                                {{ isset($patient->user) ? $patient->weight : $patient->patientchild->weight }}

                                            </p>
                                        </td>
                                        <td style=" padding-left: 20px;   text-align: center;">
                                            @if (isset($patient->user) ? $patient->user->person->gender : $patient->person->gender == 1)
                                                <p class="text-primary"> ذكر
                                                </p>
                                            @else
                                                <p class="text-primary"> انثى
                                                </p>
                                            @endif
                                        </td>
                                        <td style=" padding-left: 20px;   text-align: center;">
                                            <p class="text-primary">
                                                {{ \Carbon\Carbon::parse(isset($patient->user) ? $patient->user->person->birthDate : $patient->person->birthDate)->age }}
                                            </p>
                                        </td>
                                        <td style=" padding-left: 20px;   text-align: right;">
                                            <p class="text-primary">
                                                {{ isset($patient->user) ? $patient->user->person->name : $patient->person->name }}
                                            </p>

                                        </td>
                                    </tr>
                                </tbody>

                            </table>

                        </div>



                    </div>

                </div>

            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header fix-card">
                            <div class="row">
                                <div class="col-8">
                                    <p class="card-title"> العمليات </p>
                                </div>

                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-box">
                                <table style="border-collapse: collapse; width: 100%; font-size: 12px;"
                                    class="table border-table table_data">
                                    <thead>
                                        <tr>


                                            <th style="border: 1px solid black; padding: 8px;">تاريخ العملية</th>

                                            <th style="border: 1px solid black; padding: 8px;">الوصف</th>

                                            <th style="border: 1px solid black; padding: 8px;">الحالة</th>

                                            <th style="border: 1px solid black; padding: 8px;">العملية </th>

                                            <th style="border: 1px solid black; padding: 8px;">ID</th>






                                        </tr>
                                    </thead>
                                    <tbody>





                                        @foreach ($surgery as $patientsurgery)
                                            <tr>




                                                <td style="border: 1px solid black; padding: 8px;">
                                                    {{ $patientsurgery->surgery_date_time }}</td>
                                                <td style="border: 1px solid black; padding: 8px;">
                                                    {{ $patientsurgery->note }}</td>

                                                <td style="border: 1px solid black; padding: 8px;">
                                                    {{ $patientsurgery->status }}</td>

                                                <td style="border: 1px solid black; padding: 8px;">
                                                    {{ $patientsurgery->surgery->name }}</td>

                                                <td style="border: 1px solid black; padding: 8px;">{{ ++$index }}
                                                </td>

                                            </tr>
                                        @endforeach




                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
    <!-- start section footer -->
    <div class="footer">
        <div class="copyright">
            <p class="mb-0">التقرير بتاريخ {{ now() }}</a>
                {{ now()->year }}
            </p>
            <br>

            <p class="mb-0">تم اصدار هذا التقرير من نظام بوابة المرض الالكترونية</a>
                {{ now()->year }}
            </p>
        </div>
    </div>
    <!-- End section footer -->


    </div>
    <!-- JQuery v3.5.1 -->


    <script src="{{ asset('plugins/jquery/jquery.min.js') }}" defer></script>
    <script src="{{ asset('plugins/popper/popper.min.js') }}" defer></script>

    <script src="{{ asset('plugins/bootstrap/js/bootstrap.min.js') }}" defer></script>

    <script src="{{ asset('plugins/moment/moment.min.js') }}" defer></script>

    <script src="{{ asset('plugins/daterangepicker/daterangepicker.min.js') }}" defer></script>

    <script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}" defer></script>
    <script src="{{ asset('js/init-tdatatable.js') }}" defer></script>

    <script src="{{ asset('plugins/chart/chart/Chart.min.js') }}" defer></script>
    <script src="{{ asset('js/charts-custom.js') }}" defer></script>

    <script src="{{ asset('js/toggleFullScreen.js') }}" defer></script>
    <script src="{{ asset('js/main.js') }}" defer></script>
    <script src="{{ asset('js/option-themes.js') }}" defer></script>
    <script src="{{ asset('js/data.js') }}" defer></script>



</body>

</html>
