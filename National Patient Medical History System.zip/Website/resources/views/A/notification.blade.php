
<div class="basic-form">
    <form method="POST" action="{{ route('fcmToken') }}" class="needs-validation"
        novalidate>
        @csrf
        <div class="row">
            <div class="col-xl-6">
                <div class="form-group">
                    <label for="validationCustom05" class="form-label"> اسم الفحص</label>
                    <div id="searchContainer">
                        <input type="text"
                            data-route="http://localhost:4321/patientPortal/public/admin/testSearch"
                            name="title" id="name" value="{{ old('title') }}"
                            id="validationCustom05" required class="form-control"
                            placeholder="اسم الفحص" />
                        <ul id="SearchResults"></ul>
                        <span id="SpanMessage"></span>
                    </div>
                    @error('title')
                        <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>
            </div>
            <div class="col-xl-6">
                <div class="form-group">
                    <label for="validationCustom05" class="form-label"> الطبيعي </label>
                    <input id="validationCustom05" required type="text" name="message"
                        class="form-control" value="{{ old('message') }}"
                        placeholder="الطبيعي" />
                    @error('message')
                        <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>
            </div>
            <div class="col-xl-6">
                <div class="form-group">
                    <label for="validationCustom05" class="form-label"> مرتفع </label>
                    <input type="text" id="validationCustom05" required name="userId"
                        value="{{ old('userId') }}" class="form-control"
                        placeholder="مرتفع" />
                    @error('userId')
                        <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>
            </div>

                <div class="col-xl-12">
                    <div class="form-group">
                        <button type="submit"
                            class="btn btn-primary float-end">حفظ</button>
                    </div>
                </div>
            </div>
    </form>
</div>
