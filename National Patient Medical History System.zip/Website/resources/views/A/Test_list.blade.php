@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="All-Tests main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">الفحوصات</h4>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">الفحوصات</a>
                            </li>
                        </ol>
                    </div>
                </div>

                {{-- message --}}
                @if (session('success'))
                    <script>
                        showSuccessAlert('{{ session('success') }}'); // Call the function directly if obj is not null
                    </script>
                @endif

                @if (session('error'))
                    <div class="container mt-5" id="successAlert">
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <span class="message">{{ session('error') }}</span>
                            <div class="progress" style="height: 2px;">
                                <div class="progress-bar bg-danger flex-row-reverse mr-auto ml-auto" role="progressbar"
                                    style="width:0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"
                                    id="progressBar"></div>
                            </div>
                        </div>

                    </div>
                @endif
                {{-- message --}}


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-7">
                                        <h4 class="card-title"> الفحوصات </h4>
                                    </div>

                                    <div class="col-5">
                                        <a href="{{ route('admin.test.create') }}" class="btn btn-primary float-end"> اضافة
                                            فحص</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم الفحص</th>
                                                <th>مرتفع</th>
                                                <th>طبيعي</th>
                                                <th>منخفض</th>
                                                <th>وصف</th>
                                                <th>نوع الفحص</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($all_test as $test)
                                                <tr>
                                                    <td>#{{ ++$index }}</td>
                                                    <td>{{ $test->name }}</td>
                                                    <td>{{ $test->high }}</td>
                                                    <td>{{ $test->normal }}</td>
                                                    <td>{{ $test->low }}</td>
                                                    <td>{{ $test->description }}</td>
                                                    <td>{{ $test->test_type->name }}</td>
                                                    <td>
                                                        <a data-bs-toggle='modal' data-bs-target='#editTest' class='mr-4'
                                                            onclick="populateEditModal('{{ $test->id }}','{{ $test->name }}','{{ $test->description }}','{{ $test->low }}','{{ $test->normal }}','{{ $test->high }}','{{ $test->test_type->id }}');">
                                                            <span class='fas fa-pencil-alt tbl-edit'></span>
                                                        </a>

                                                    </td>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->


    <!-- Modal -->
    <div class="modal fade" id="editTest" tabindex="-1" aria-labelledby="modal-title-name-tests" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-name-tests">تعديل بيانات الفحص</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="basic-form">
                                <form method="POST" action="{{ route('admin.test.update') }}" class="needs-validation"
                                    novalidate>
                                    @csrf
                                    @method('PUT')
                                    <input type="hidden" id="testNumber" name="number" />
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label class="form-label" for="validationCustom05"> اسم الفحص </label>
                                                <div id="searchContainer">
                                                    <input data-route="http://localhost:4321/patientPortal/public/admin/testSearch"
                                                        type="text" value="{{ old('name') }}" name="name"
                                                        id="editName" class="form-control" placeholder="اسم الفحص"
                                                        id="validationCustom05" required />

                                                    <ul id="SearchResult"></ul>
                                                </div>
                                                @error('name')
                                                    <span class="error-message">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="validationCustom05" class="form-label"> مرتفع </label>

                                                <input type="text" value="{{ old('high') }}" name="high"
                                                    id="testHigh" class="form-control" placeholder="مرتفع"
                                                    id="validationCustom05" required />
                                                @error('high')
                                                    <span class="error-message">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="validationCustom05" class="form-label"> الطبيعي </label>

                                                <input type="text" name="normal" value="{{ old('normal') }}"
                                                    id="testNormal" class="form-control" placeholder="الطبيعي"
                                                    id="validationCustom05" required />
                                                @error('normal')
                                                    <span class="error-message">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="validationCustom05" class="form-label"> منخفض </label>

                                                <input type="text" value="{{ old('low') }}" name="low"
                                                    id="testLow" class="form-control" placeholder="منخفض"
                                                    id="validationCustom05" required />
                                                @error('low')
                                                    <span class="error-message">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="validationCustom05" value="{{ old('test_type_id') }}"
                                                    class="form-label"> نوع الفحص </label>
                                                <select id="testType" name="test_type_id" class="form-control"
                                                    id="validationCustom05" required>

                                                    @foreach ($all_test_type as $test)
                                                        <option value="{{ $test->id }}" class="form-control">
                                                            {{ $test->name }}</option>
                                                    @endforeach

                                                </select>
                                                @error('test_type_id')
                                                    <span class="error-message">{{ $message }}</span>
                                                @enderror
                                            </div>

                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="validationCustom05" class="form-label"> وصف الفحص </label>
                                                <input name="description" value="{{ old('description') }}"
                                                    class="form-control" id="testDescription" placeholder="الوصف"
                                                    id="validationCustom05" required />
                                                @error('description')
                                                    <span class="error-message">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger"
                                                data-bs-dismiss="modal">اغلاق</button>
                                            <button type="submit" class="btn btn-primary">حفظ البيانات</button>
                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Modal -->





    <script>
        function populateEditModal(id, name, desc, low, normal, high, type) {
            document.getElementById('testNumber').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('testDescription').value = desc;
            document.getElementById('testLow').value = low;
            document.getElementById('testNormal').value = normal;
            document.getElementById('testHigh').value = high;
            document.getElementById('testType').value = type;
        }
        document.addEventListener("DOMContentLoaded", function () {
  showSuccessAlert(); // Call without argument (default message if no session success)
});
    </script>
@endsection
