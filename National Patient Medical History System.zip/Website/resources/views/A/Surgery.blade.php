@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">العمليات</h4>
                            <p class="mb-0">اضافة عملية</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="/add-test.html">العمليات</a>
                            </li>
                        </ol>
                    </div>
                </div>







                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-7">
                                        <h4 class="card-title">العمليات</h4>
                                    </div>
                                    <div class="col-3">
                                        <abbr title="استيراد اسماء العمليات  من ملف خارجي">
                                            <button type="button" class="btn btn-danger float-end" data-bs-toggle="modal"
                                                data-bs-target="#excelModel"> استيراد اسماء العمليات </button>
                                            <abbr>
                                    </div>
                                    <div class="col-2">
                                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                            data-bs-target="#addSurgery"> اضافة عملية </button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم العملية</th>
                                                <th>الوصف</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach ($all_surgery as $surgery)
                                                <tr>
                                                    <td>#{{ ++$index }}</td>
                                                    <td> {{ $surgery->name }} </td>
                                                    <td> {{ $surgery->description }} </td>
                                                    <td class="text-start">
                                                        <a data-bs-toggle='modal' data-bs-target='#editSurgery'
                                                            class='mr-4'
                                                            onclick="populateEditModal('{{ $surgery->id }}','{{ $surgery->name }}', '{{ $surgery->description }}');">
                                                            <span class='fas fa-pencil-alt tbl-edit'></span>
                                                        </a>

                                                    </td>
                                                </tr>
                                            @endforeach



                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->

    <!-- Add Surgery -->
    <div class="modal fade selectRefresh" id="addSurgery" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة عملية </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.surgery.store') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        <div class="col">
                            <div class="form-group">
                                <label for="validationCustom05" class="form-label"> اسم العملية </label>
                                <div id="searchContainer">
                                    <input data-route="http://localhost:4321/patientPortal/public/admin/surgerySearch"
                                        value="{{ old('name') }}" type="text" name="name" id="name"
                                        class="form-control" placeholder="اسم العملية" id="validationCustom05"
                                        required />
                                    <ul id="SearchResults"></ul>
                                    <span id="SpanMessage"></span>
                                </div>
                                @error('name')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror


                            </div>

                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="validationCustom05" class="form-label"> وصف العملية </label>

                                <input value="{{ old('description') }}" type="text" name="description"
                                    class="form-control" placeholder="الوصف" id="validationCustom05" required />
                                @error('description')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror

                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    <!-- edit Surgery -->
    <div class="modal fade selectRefresh" id="editSurgery" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> تعديل بيانات عملية </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.surgery.update') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        @method('PUT')
                        <input name="number" id="surgeryNumber" type="hidden" />
                        <div class="col">
                            <div class="form-group">
                                <label for="validationCustom05" class="form-label"> اسم العملية </label>
                                <div id="searchContainer">

                                    <input data-route="http://localhost:4321/patientPortal/public/admin/surgerySearch"
                                        value="{{ old('name') }}" type="text" name="name" id="editName"
                                        class="form-control" placeholder="اسم العملية" id="validationCustom05"
                                        required />
                                    <ul id="SearchResult"></ul>
                                </div>
                                @error('name')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror

                            </div>

                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="validationCustom05" class="form-label"> وصف العملية </label>

                                <input value="{{ old('description') }}" id="surgeryDescription" type="text"
                                    name="description" class="form-control" placeholder="الوصف" id="validationCustom05"
                                    required />
                                @error('description')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror

                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    <!-- file input -->
    <div class="modal fade selectRefresh" id="excelModel" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal">استيراد اسماء العمليات من ملف خارجي</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.surgery.csv.store') }}" method="POST"
                        class="row align-items-start needs-validation" novalidate enctype="multipart/form-data">
                        @csrf
                        <div class="mb-3">
                            <input class="form-control" id="formFile" name="file" type="file" required>
                            <p class="text-danger">.xslx .cvs</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    </div>




    <script>
        function populateEditModal(id, name, desc) {
            document.getElementById('surgeryNumber').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('surgeryDescription').value = desc;
        }
    </script>
@endsection
