@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">الاطباء</h4>
                            <p class="mb-0">اضافة طبيب</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">الاطباء</a>
                            </li>
                        </ol>
                    </div>
                </div>




                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>صورة الدكتور</th>
                                                <th>اسم الدكتور</th>
                                                <th> الجنس </th>
                                                <th>التخصص</th>
                                                <th>البريد الالكتروني</th>
                                                <th> رقم الهاتف </th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($all_doctor as $doctor)
                                                <tr>
                                                    <td>#{{ ++$index }} </td>
                                                    <td>

                                                        <img loading="lazy" class="rounded-image"
                                                            src="{{ asset('images/Doctors/profiles/') }}/{{ $doctor->user->person->prsonalImage }}">

                                                    </td>
                                                    <td>{{ $doctor->user->person->name }} </td>

                                                    @if ($doctor->user->person->gender == 0)
                                                        <td>انثى</td>
                                                    @else
                                                        <td>ذكر</td>
                                                    @endif
                                                    <td>{{ $doctor->resume[0]->specialty->name }} </td>
                                                    <td>{{ $doctor->user->email }} </td>
                                                    <td>{{ $doctor->user->phone_number }} </td>


                                                    <td class="text-start">
                                                        @if ($doctor->user->status == 1)
                                                            <a data-bs-toggle='modal' data-bs-target='#blockDoctor'
                                                                class='mr-4'
                                                                onclick="populateEditModalBlock('{{ $doctor->user->id }}','{{ $doctor->user->status }}');">
                                                                <button class="btn btn-danger">ايقاف الحساب</button>

                                                            </a>
                                                        @else
                                                            <a data-bs-toggle='modal' data-bs-target='#unblockDoctor'
                                                                class='mr-4'
                                                                onclick="populateEditModalUnBlock('{{ $doctor->user->id }}','{{ $doctor->user->status }}');">
                                                                <button class="btn btn-primary">تفعيل الحساب</button>

                                                            </a>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->


    <!-- BLOCK DIALG -->
    <div class="modal fade selectRefresh" id="blockDoctor" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> ايقاف حساب دكتور </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.doctor.block') }}" method="POST" class="row align-items-start">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="number" id="number" />
                        <input type="hidden" name="block" id="block" />
                        <div class="col">
                            <h5>هل متاكد من ايقاف حساب الدكتور؟</h5>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-danger"> ايقاف </button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- END BLOCK DIALG -->

    <!-- UNBLOCK DIALG -->
    <div class="modal fade selectRefresh" id="unblockDoctor" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal">تفعيل حساب الدكتور </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.doctor.block') }}" method="POST" class="row align-items-start">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="number" id="unblockNumber" />
                        <input type="hidden" name="block" id="unblock" />
                        <div class="col">
                            <h5>هل متاكد من تفعيل حساب الدكتور؟</h5>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-primary"> تفعيل </button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- UNBLOCK DIALG -->


    <script>
        function populateEditModalBlock(id, block) {
            document.getElementById('number').value = id;
            document.getElementById('block').value = block;
        }

        function populateEditModalUnBlock(id, block) {
            document.getElementById('unblockNumber').value = id;
            document.getElementById('unblock').value = block;
        }
    </script>
@endsection
