@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">قسم الأشعة</h4>
                            <p class="mb-0">اضافة قسم أشعة</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="/add-test.html">الأشعة</a>
                            </li>
                        </ol>
                    </div>
                </div>




                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-7">
                                        <h4 class="card-title">قسم الأشعة</h4>
                                    </div>
                                    <div class="col-5">
                                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                            data-bs-target="#addRayCeteral"> اضافة مركز أشعة </button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>شعار المركز</th>
                                                <th>اسم المركز</th>
                                                <th>المدينة</th>
                                                <th>العنوان</th>
                                                <th>خاصة / تابعة</th>
                                                <th> البريد الالكتروني </th>
                                                <th> رقم الهاتف </th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach ($all_building as $building)
                                                <tr>
                                                    <td>#{{ ++$index }}</td>
                                                    <td>
                                                        <img loading="lazy" class="rounded-image"
                                                            src="{{ asset('images/buildings/logos/') }}/{{ $building->logo }}">

                                                    </td>
                                                    <td> {{ $building->name }}</td>
                                                    <td>{{ $building->city }}</td>
                                                    <td> {{ $building->address }}</td>

                                                    @if ($building->hospital_id == 0)
                                                        <td> مركز أشعة خارجي</td>
                                                    @else
                                                        <td>مستشفى {{ $building->hospital->name }} </td>
                                                    @endif

                                                    <td> {{ $building->user->email }}</td>
                                                    <td> {{ $building->user->phone_number }}</td>


                                                    <td class="text-start">
                                                        <a data-bs-toggle='modal' data-bs-target='#editRayCeteral'
                                                            class='mr-4'
                                                            onclick="populateEditModal('{{ $building->id }}','{{ $building->name }}', '{{ $building->city }}', '{{ $building->address }}','{{ $building->hospital_id }}','{{ $building->user->email }}','{{ $building->user->phone_number }}','{{ asset('images/buildings/logos/') }}/{{ $building->logo }}','{{ $building->user->id }}');">
                                                            <span class='fas fa-pencil-alt tbl-edit'></span>
                                                        </a>

                                                        @if ($building->user->status == 1)
                                                            <a data-bs-toggle='modal' data-bs-target='#blockRayCenter'
                                                                class='mr-4'
                                                                onclick="populateEditModalBlock('{{ $building->user->id }}','{{ $building->user->status }}');">
                                                                <button class="btn btn-danger">ايقاف الحساب</button>
                                                            </a>
                                                        @else
                                                            <a data-bs-toggle='modal' data-bs-target='#unblockRayCenter'
                                                                class='mr-4'
                                                                onclick="populateEditModalUnBlock('{{ $building->user->id }}','{{ $building->user->status }}');">
                                                                <button class="btn btn-primary"> تفعيل الحساب</button>
                                                            </a>
                                                        @endif

                                                    </td>
                                                </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->

    <!--Add Ray Center -->
    <div class="modal fade selectRefresh" id="addRayCeteral" tabindex="-1" role="dialog"
        aria-RayCeteralelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة مركز أشعة </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-RayCeteralel="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.raycenter.store') }}" id="addRay"
                        class="row align-items-start needs-validation" novalidate enctype="multipart/form-data">
                        @csrf

                        <div class="row">

                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> اسم المركز </label>
                                    <div id="searchContainer">
                                        <input data-route="http://localhost:4321/patientPortal/public/admin/raycenterSearch"
                                            value="{{ old('name') }}" type="text" name="name"
                                            class="form-control" placeholder="اسم المركز" id="name"
                                            id="validationCustom05" required />

                                        <ul id="SearchResults"></ul>
                                        <span id="SpanMessage"></span>
                                    </div>
                                    @error('name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> البريد الاكتروني </label>

                                    <input type="email" name="email" value="{{ old('email') }}"
                                        class="form-control" placeholder=" example@email.com " id="validationCustom05"
                                        required />
                                    @error('email')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>

                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> المدينة </label>

                                    <select name="city" id="cityAdd" value="{{ old('city') }}" class="form-control"
                                        id="validationCustom05" required>

                                        <option class="form-control">صنعاء</option>
                                        <option class="form-control">تعز</option>
                                        <option class="form-control">اب</option>
                                        <option class="form-control">عدن</option>
                                    </select>
                                    @error('city')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> رقم الهاتف </label>

                                    <input type="number" value="{{ old('phone') }}" name="phone"
                                        class="form-control" placeholder=" 7******** " id="validationCustom05"
                                        required />
                                    @error('phone')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>


                            </div>

                        </div>
                        <div class="row">

                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> اسم المستشفى / مختبر خارجي
                                    </label>

                                    <select name="hospital" value="{{ old('hospital') }}" class="form-control"
                                        id="validationCustom05" onchange="disabledInput(this);"  required>
                                        <option value="0"> مختبر خارجي </option>
                                        @foreach ($all_hospitall as $hospitall)
                                            <option value="{{ $hospitall->id }}" class="form-control">
                                                {{ $hospitall->name }} -
                                                {{ $hospitall->city }} - {{ $hospitall->address }}</option>
                                        @endforeach
                                    </select>
                                    @error('hospital')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>

                            <div class="col">
                                <div class="form-group">

                                    <label for="validationCustom05" class="form-label"> شعار المركز </label>
                                    <input type="file" name="logo" class="form-control" id="validationCustom05"
                                        required />
                                    @error('logo')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col">

                                <label for="validationCustom05"  class="form-label"> عنوان المختبر </label>
                                <input name="address" id="addressAdd" value="{{ old('address') }}" class="form-control"
                                    placeholder="العنوان" id="validationCustom05" required />
                                @error('address')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col">

                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> </label>

                                    <select name="buid_type" class="form-control" id="validationCustom05" required>
                                        <option value="0" class="form-control">مركز اشعة</option>
                                        <option value="1" class="form-control">مختبر و مركزاشعة</option>

                                    </select>
                                    @error('buid_type')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    </div>



    <!-- BLOCK DIALG -->
    <div class="modal fade selectRefresh" id="blockRayCenter" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> ايقاف حساب مركز الأشعة </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.raycenter.block') }}" method="POST" class="row align-items-start">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="number" id="number" />
                        <input type="hidden" name="block" id="block" />
                        <div class="col">
                            <h5>هل متاكد من ايقاف حساب مركز الأشعة ؟</h5>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-danger"> ايقاف </button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- END BLOCK DIALG -->

    <!-- UNBLOCK DIALG -->
    <div class="modal fade selectRefresh" id="unblockRayCenter" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal">تفعيل حساب مركز الأشعة </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.raycenter.block') }}" method="POST" class="row align-items-start">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="number" id="unblockNumber" />
                        <input type="hidden" name="block" id="unblock" />
                        <div class="col">
                            <h5>هل متاكد من تفعيل حساب مركز الأشعة ؟</h5>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-primary">تفعيل</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- UNBLOCK DIALG -->


    <!--edit Ray Center -->
    <div class="modal fade selectRefresh" id="editRayCeteral" tabindex="-1" role="dialog"
        aria-RayCeteralelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> تحديث بيانات مركز أشعة </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-RayCeteralel="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.raycenter.update') }}" id="editRay"
                        class="row align-items-start needs-validation" enctype="multipart/form-data" novalidate>
                        @csrf
                        @method('PUT')
                        <input id="rayCeneterNumber" name="number" type="hidden" />
                        <input id="rayCeneterUNumber" name="unumber" type="hidden" />

                        <div class="row">

                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> اسم المركز </label>
                                    <div id="searchContainer">
                                        <input type="text" data-route="http://localhost:4321/patientPortal/public/admin/raycenterSearch"
                                            value="{{ old('name') }}" id="editName" name="name"
                                            class="form-control" placeholder="اسم المركز" id="validationCustom05"
                                            required />


                                        <ul id="SearchResult"></ul>
                                    </div>
                                    @error('name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> البريد الاكتروني </label>

                                    <input type="email" value="{{ old('email') }}" id="rayCeneterEmail"
                                        name="email" class="form-control" placeholder=" example@email.com "
                                        id="validationCustom05" required />
                                    @error('email')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> المدينة </label>

                                    <select value="{{ old('city') }}" id="rayCeneterCity" name="city"
                                        class="form-control" id="validationCustom05" required>

                                        <option class="form-control">صنعاء</option>
                                        <option class="form-control">تعز</option>
                                        <option class="form-control">اب</option>
                                        <option class="form-control">عدن</option>
                                    </select>
                                    @error('city')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> رقم الهاتف </label>

                                    <input type="number" value="{{ old('phone') }}" id="rayCeneterPhone"
                                        name="phone" class="form-control" placeholder=" 7******** "
                                        id="validationCustom05" required />
                                    @error('phone')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>

                        </div>

                        <div class="row">


                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> اسم المستشفى / مختبر خارجي
                                    </label>

                                    <select value="{{ old('hospital') }}" id="rayCeneterHospital" name="hospital"
                                        class="form-control" onchange="disabledInputs(this);"  id="validationCustom05" required>
                                        <option value="0"> مختبر خارجي </option>
                                        @foreach ($all_hospitall as $hospitall)
                                            <option value="{{ $hospitall->id }}" class="form-control">
                                                {{ $hospitall->name }} -
                                                {{ $hospitall->city }} - {{ $hospitall->address }}</option>
                                        @endforeach
                                    </select>
                                    @error('hospital')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>


                            <div class="col">
                                <div class="form-group">
                                    <img loading="lazy" style="width: 5rem;" src="#" id="editLogo" id="validationCustom05">

                                    <label for="validationCustom05" class="form-label"> شعار المركز </label>
                                    <input type="file" name="logo" id="editLogoFile" class="form-control"
                                        id="validationCustom05" />
                                    @error('logo')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                        </div>

                        <div class="row">
                          <div class="col">
                            <label for="validationCustom05" class="form-label"> عنوان المختبر </label>
                            <input name="address" value="{{ old('address') }}" id="rayCeneterAddress"
                                class="form-control" placeholder="العنوان" id="validationCustom05" required />
                            @error('address')
                                <span class="error-message">{{ $message }}</span>
                            @enderror
                          </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>

        <!--End edit Ray Center -->




    </div>
    </div>



    <script>
        function populateEditModal(id, name, city, address, hospital, email, phone, logo, unmber) {
            document.getElementById('rayCeneterNumber').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('rayCeneterCity').value = city;
            document.getElementById('rayCeneterAddress').value = address;
            document.getElementById('rayCeneterHospital').value = hospital;
            document.getElementById('rayCeneterEmail').value = email;
            document.getElementById('rayCeneterPhone').value = phone;
            document.getElementById('editLogo').src = logo;
            document.getElementById('editLogoFile').src = logo;
            document.getElementById('rayCeneterUNumber').value = unmber;


        }

        function populateEditModalBlock(id, block) {
            document.getElementById('number').value = id;
            document.getElementById('block').value = block;
        }

        function populateEditModalUnBlock(id, block) {
            document.getElementById('unblockNumber').value = id;
            document.getElementById('unblock').value = block;
        }

        function disabledInput(data) {
            [_, city, address] = data.options[data.selectedIndex].text.split('-');

            document.getElementById('addressAdd').value = address;
            document.getElementById('cityAdd').options[0].text = city;
            var inputs = document.querySelectorAll('#cityAdd, #addressAdd');
            if (data.value !== '0') {

                inputs.forEach(function(input) {

                    input.disabled = true;
                });
            } else {
                document.getElementById('addressAdd').value = '';
                document.getElementById('cityAdd').options[0].text = '';
                inputs.forEach(function(input) {
                    input.disabled = false;
                });
            }
        }

        function disabledInputs(data) {
            [_, city, address] = data.options[data.selectedIndex].text.split('-');

            document.getElementById('rayCeneterAddress').value = address;
            document.getElementById('rayCeneterCity').options[0].text = city;
            var inputs = document.querySelectorAll('#rayCeneterCity, #rayCeneterAddress');
            if (data.value !== '0') {

                inputs.forEach(function(input) {

                    input.disabled = true;
                });
            } else {
                document.getElementById('rayCeneterAddress').value = '';
                document.getElementById('rayCeneterCity').options[0].text = '';
                inputs.forEach(function(input) {
                    input.disabled = false;
                });
            }
        }


        document.getElementById('addRay').addEventListener('submit', function(event) {
            // Enable the fields just before submitting the form
            var inputs = document.querySelectorAll('#cityAdd, #addressAdd');
            inputs.forEach(function(input) {
                input.disabled = false;
            });
        });
        document.getElementById('editRay').addEventListener('submit', function(event) {
            // Enable the fields just before submitting the form
            var inputs = document.querySelectorAll('#rayCeneterCity, #rayCeneterAddress');
            inputs.forEach(function(input) {
                input.disabled = false;
            });
        });
    </script>
@endsection
