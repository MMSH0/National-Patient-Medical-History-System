@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="All-Tests main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">انواع الفحوصات</h4>
                        </div>

                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">انواع الفحوصات</a>
                            </li>
                        </ol>
                    </div>
                </div>




                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-7">
                                        <h4 class="card-title"> انواع الفحوصات </h4>
                                    </div>

                                    <div class="col-4">
                                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                            data-bs-target="#addRayCeteral"> اضافة نوع الفحص </button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم نوع الفحص</th>

                                                <th>وصف</th>

                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($all_test as $test)
                                                <tr>
                                                    <td>#{{ ++$index }}</td>
                                                    <td>{{ $test->name }}</td>

                                                    <td>{{ $test->description }}</td>
                                                    <td>
                                                        <a data-bs-toggle='modal' data-bs-target='#editTest' class='mr-4'
                                                            onclick="populateEditModal('{{ $test->id }}','{{ $test->name }}','{{ $test->description }}');">
                                                            <span class='fas fa-pencil-alt tbl-edit'></span>
                                                        </a>

                                                    </td>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- change date and time patient -->
        <div class="modal fade selectRefresh" id="addRayCeteral" tabindex="-1" role="dialog"
            aria-RayCeteralelledby="modal-title-addDrug-modal">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة نوع الفحص </h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-RayCeteralel="Close"><span
                                aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="{{ route('admin.typetest.store') }}" class="row needs-validation"
                            novalidate>
                            @csrf

                            <div class="row">
                                <div class="col">
                                    <div class="form-group">
                                        <div id="searchContainer">
                                            <input id="name" data-route="http://localhost:4321/patientPortal/public/admin/typetestSearch"
                                                id="validationCustom05" required type="text" name="name"
                                                class="form-control" placeholder="الاسم " />
                                            <ul id="SearchResults"></ul>
                                            <span id="SpanMessage"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col">
                                    <textarea name="description" id="validationCustom05" required class="form-control" placeholder="الملاحظات"></textarea>

                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                                <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->


    <!-- Edit Test type -->
    <div class="modal fade" id="editTest" tabindex="-1" aria-labelledby="modal-title-name-tests" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-name-tests">تعديل بيانات نوع الفحص</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="basic-form">
                                <form method="POST" action="{{ route('admin.test.type.update') }}"
                                    class="needs-validation" novalidate>
                                    @csrf
                                    @method('PUT')
                                    <input type="hidden" id="testNumber" name="number" />
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label class="form-label" for="validationCustom05"> اسم الفحص </label>
                                                <div id="searchContainer">
                                                    <input data-route="http://localhost:4321/patientPortal/public/admin/testSearch"
                                                        type="text" value="{{ old('name') }}" name="name"
                                                        id="editName" class="form-control" placeholder="اسم الفحص"
                                                        id="validationCustom05" required />

                                                    <ul id="SearchResult"></ul>
                                                </div>
                                                @error('name')
                                                    <span class="error-message">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">

                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="validationCustom05" class="form-label"> وصف الفحص </label>
                                                <input name="description" value="{{ old('description') }}"
                                                    class="form-control" id="testDescription" placeholder="الوصف"
                                                    id="validationCustom05" required />
                                                @error('description')
                                                    <span class="error-message">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger"
                                            data-bs-dismiss="modal">اغلاق</button>
                                        <button type="submit" class="btn btn-primary">حفظ البيانات</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <!-- End Modal -->





    <script>
        function populateEditModal(id, name, desc, low, normal, high, type) {
            document.getElementById('testNumber').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('testDescription').value = desc;
            document.getElementById('testLow').value = low;
            document.getElementById('testNormal').value = normal;
            document.getElementById('testHigh').value = high;
            document.getElementById('testType').value = type;
        }
    </script>
@endsection
