@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">العلاجات</h4>
                            <p class="mb-0">اضافة علاج</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="/add-test.html">العلاجات</a>
                            </li>
                        </ol>
                    </div>
                </div>




                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-7">
                                        <h4 class="card-title">العلاجات</h4>
                                    </div>
                                    <div class="col-3">
                                        <abbr title="استيراد اسماء العلاجات من ملف خارجي">
                                            <button type="button" class="btn btn-danger float-end" data-bs-toggle="modal"
                                                data-bs-target="#excelModel"> استيراد اسماء العلاجات</button>
                                        </abbr>
                                    </div>
                                    <div class="col-2">
                                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                            data-bs-target="#addDrugs"> اضافة علاج</button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم العلاج</th>
                                                <th>الاسم العلمي</th>
                                                <th>اسم الشركه </th>
                                                <th>اسم الدوله </th>
                                                <th>الوصف </th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($all_medicen as $medicen)
                                                <tr>
                                                    <td>#{{ ++$index }}</td>
                                                    <td> {{ $medicen->name }} </td>
                                                    <td>{{ $medicen->scientific_name }} </td>
                                                    <td>{{ $medicen->company_name }} </td>
                                                    <td>{{ $medicen->country }} </td>
                                                    <td>{{ $medicen->description }} </td>
                                                    <td class="text-start">
                                                        <a data-bs-toggle='modal' data-bs-target='#editDrugs'
                                                            class='mr-4'>
                                                            <span class='fas fa-pencil-alt tbl-edit'
                                                                onclick="populateEditModal('{{ $medicen->id }}','{{ $medicen->name }}', '{{ $medicen->scientific_name }}', '{{ $medicen->company_name }}','{{ $medicen->country }}','{{ $medicen->description }}');"></span>
                                                        </a>
                                                    </td>
                                                </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->

    <!-- Add Durg-->
    <div class="modal fade selectRefresh" id="addDrugs" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة علاج </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.medicen.store') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf

                        <div class="row">

                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05">اسم العلاج </label>
                                    <div id="searchContainer">
                                        <input data-route="http://localhost:4321/patientPortal/public/admin/medicenSearch"
                                            value="{{ old('name') }}" name="name" placeholder="اسم العلاج"
                                            id="name" class="form-control" id="validationCustom05" required>
                                        <ul id="SearchResults"></ul>
                                        <span id="SpanMessage"></span>
                                    </div>
                                    @error('name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror


                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> الاسم العملي </label>
                                    <input value="{{ old('scientific_name') }}" name="scientific_name"
                                        placeholder="الاسم العملي" class="form-control form-input"
                                        id="validationCustom05" required>
                                    @error('scientific_name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>

                        </div>


                        <div class="row">

                            <div class="col">
                                <div class="form-group">

                                    <label for="validationCustom05" class="form-label"> اسم الشركة </label>

                                    <input value="{{ old('company_name') }}" name="company_name"
                                        placeholder="اسم الشركة " class="form-control form-input" id="validationCustom05"
                                        required>
                                    @error('company_name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror


                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> اسم الدولة </label>

                                    <select value="{{ old('country') }}" name="country" class="form-control form-select"
                                        id="validationCustom05" required>

                                        <option>اليمن </option>
                                        <option> مصر </option>
                                        <option> اوروبي </option>
                                        <option> الماني </option>

                                    </select>
                                </div>
                            </div>


                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05">وصف</label>
                                    <textarea value="{{ old('description') }}" name="description" class="form-control" rows="3"
                                        id="validationCustom05" required></textarea>
                                    @error('description')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <!-- edit Durg-->


    <div class="modal fade selectRefresh" id="editDrugs" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة علاج </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.medicen.update') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        @method('PUT')
                        <input name="number" type="hidden" id="medicenNumber" />

                        <div class="row">

                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05">اسم العلاج </label>
                                    <div id="searchContainer">

                                        <input data-route="hhttp://localhost:4321/patientPortal/public/admin/medicenSearch"
                                            value="{{ old('name') }}" name="name" id="editName"
                                            placeholder="اسم العلاج" class="form-control" id="validationCustom05"
                                            required>
                                        <ul id="SearchResult"></ul>
                                    </div>
                                    @error('name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror



                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> الاسم العملي </label>
                                    <input value="{{ old('scientific_name') }}" name="scientific_name"
                                        id="medicenScientificName" placeholder="الاسم العملي"
                                        class="form-control form-input" id="validationCustom05" required>
                                    @error('scientific_name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>

                        </div>


                        <div class="row">

                            <div class="col">
                                <div class="form-group">

                                    <label for="validationCustom05" class="form-label"> اسم الشركة </label>

                                    <input value="{{ old('company_name') }}" name="company_name" id="medicenCompanyName"
                                        placeholder="اسم الشركة " class="form-control form-input" id="validationCustom05"
                                        required>
                                    @error('company_name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror


                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> اسم الدولة </label>

                                    <select id="medicenCountry" name="country" class="form-control form-select"
                                        id="validationCustom05" required>

                                        <option>اليمن </option>
                                        <option> مصر </option>
                                        <option> اوروبي </option>
                                        <option> الماني </option>

                                    </select>
                                    @error('country')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>


                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05">وصف</label>
                                    <textarea value="{{ old('description') }}" name="description" id="medicenDescription" class="form-control"
                                        rows="3" id="validationCustom05" required></textarea>
                                    @error('description')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>



    <!-- DELET DIALG -->
    <div class="modal fade selectRefresh" id="deleteDrugs" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> حذف علاج </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form class="row align-items-start">
                        <div class="col">
                            <h5>هل متاكد من حذف العلاج؟</h5>
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">اغلاق</button>
                    <button type="button" class="btn btn-danger"> حذف البيانات</button>
                </div>
            </div>
        </div>
    </div>

    </div>



    <div class="modal fade selectRefresh" id="excelModel" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal">استيراد اسماء العلاجات من ملف خارجي</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.medicen.csv.store') }}"
                        class="row align-items-start needs-validation" novalidate enctype="multipart/form-data">
                        @csrf
                        <div class="mb-3">
                            <input id="formFile" class="form-control form-input" id="validationCustom05" type="file"
                                required>
                            <p class="text-danger">.xslx .cvs</p>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <script>
        function populateEditModal(id, name, s_name, c_name, country, desc) {
            document.getElementById('medicenNumber').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('medicenScientificName').value = s_name;
            document.getElementById('medicenCompanyName').value = c_name;
            document.getElementById('medicenCountry').value = country;
            document.getElementById('medicenDescription').value = desc;
        }
    </script>
@endsection
