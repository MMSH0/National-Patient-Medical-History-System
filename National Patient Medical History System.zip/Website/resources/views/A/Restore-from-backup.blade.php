@extends('layout.admin_layout')

@section('content')
    <div class="content-body">
        <div class="warper container-fluid">

            <!-- Backup Button with Ajax and Progress Bar -->
            <button id="backupButton" class="btn  btn-primary mt-3">عمل نسخة احتياطية</button>
            <div class="progress mt-2" style="display: none;">
                <div id="progressBar" class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0"
                    aria-valuemin="0" aria-valuemax="100">0%</div>
            </div>

            {{-- message --}}

            <div class="container mt-5" style="display: none;" id="successAlert">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <span class="message">تم عمل النسخة الاحتياطية</span>

                </div>

            </div>
            {{-- message --}}

            <hr />
            <!-- Backup Form -->
            <form id="backupForm" action="{{ route('admin.backup.restore') }}" method="post">
                @csrf

                <div class="form-group">
                    <label for="selected_backup">اختار النسخة الاحتياطية:</label>
                    <select class="form-control" name="selected_backup" id="selected_backup">
                        @foreach ($backups as $backup)
                            <option value="{{ basename($backup) }}">{{ basename($backup) }}</option>
                        @endforeach
                    </select>
                </div>

                <button type="submit" class="btn btn-success">استعادة</button>
            </form>


            <!-- Available Backups List -->
            <h2 class="mt-4">النسخ الاحتياطية</h2>
            <ul class="list-group">
                @forelse ($backups as $backup)
                    <li class="list-group-item">{{ basename($backup) }}</li>
                @empty
                    <li class="list-group-item">لا يوجد اي نسخة احتياطية</li>
                @endforelse
            </ul>
        </div>
    </div>

    <script src="{{ asset('js/axios.min.js') }}"></script>
    <script>
        // JavaScript for handling backup button click and progress bar
        document.addEventListener('DOMContentLoaded', function() {
            const backupButton = document.getElementById('backupButton');
            const progressBar = document.getElementById('progressBar');
            const backupForm = document.getElementById('backupForm');

            backupButton.addEventListener('click', function() {
                progressBar.style.width = '10%';
                progressBar.innerHTML = '10%';
                progressBar.parentElement.style.display = 'block';

                // Simulate a gradual progress (0% to 20% to 100%)
                axios.post('{{ route('admin.backup.backup') }}', {}, {
                        onUploadProgress: function(progressEvent) {
                            let progress = Math.min(20, Math.floor((progressEvent.loaded /
                                progressEvent.total) * 100));
                            progressBar.style.width = progress + "%";
                            progressBar.innerHTML = progress + "%";
                        }
                    })
                    .then(response => {
                        if (response.data.success) {
                            progressBar.style.width = '100%';
                            progressBar.innerHTML = '100%';
                            setTimeout(function() {
                                progressBar.parentElement.style.display = 'none';
                                document.getElementById('successAlert').style.display='block';

                            }, 500);
                        } else {
                            console.log('Backup failed. Please check the server logs for more information.');
                        }
                    })
                    .catch(error => {
                        console.log('Backup failed. Please check the server logs for more information.');
                    });
            });
        });
    </script>
@endsection
