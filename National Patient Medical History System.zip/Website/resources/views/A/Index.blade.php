@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-lg-12 p-md-0">
                    <h4 class="text-primary"> مرحبا <span class="names"> {{ Auth::user()->person->name }} </span></h4>
                    <p class="mb-0"> مسوؤل النظام </p>
                </div>
            </div>
            <div class="new-patients main_container">
                <div class="row">
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card1">
                            <div class="card-body">
                                <a data-ajax href="{{ route('admin.doctor.index') }}">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-users fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white">الاطباء</span>
                                            <h3 class="mb-0 text-white">{{ $doctor_count }}</h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-danger bg-card2">
                            <a data-ajax href="{{ route('admin.hospital.index') }}">
                                <div class="card-body">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-bell fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white">المستشفيات</span>
                                            <h3 class="mb-0 text-white">{{ $hospital_count }}</h3>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card3">
                            <a data-ajax href="{{ route('admin.lab.index') }}">
                                <div class="card-body">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-th-large fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white">المختبرات</span>
                                            <h3 class="mb-0 text-white">{{ $lab_count }}</h3>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 col-lg-6">
                        <div class="widget card card-primary bg-card4">
                            <a data-ajax href="{{ route('admin.raycenter.index') }}">
                                <div class="card-body">
                                    <div class="media text-center">
                                        <span>
                                            <i class="fas fa-database fa-2x"></i>
                                        </span>
                                        <div class="media-body">
                                            <span class="text-white">مراكز الأشعة</span>
                                            <h3 class="mb-0 text-white">{{ $ray_count }}</h3>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card shadow widget1">
                            <div class="card-header">
                                <h4 class="card-title"></h4>
                            </div>
                            <div class="card-body">
                                <div class="row justify-content-center">
                                    <div class="col-lg-12">
                                        <canvas id="chart1" width="100%" height="50"></canvas>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card shadow widget1">
                            <div class="card-header">
                                <h4 class="card-title">الامراض</h4>
                            </div>
                            <div class="card-body">
                                <canvas id="chart2" width="100%" height="50"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End section content -->

    <script>

        document.addEventListener('DOMContentLoaded', function() {

            // Function to update the chart's data
            function updateChartData() {
                ActivityChart.data.labels = ["يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر"];
                ActivityChart.data.datasets[0].data = [100, 150, 700, 350, 500];
                ActivityChart.data.datasets[1].data = [120, 170, 220, 270, 320];

                // Re-render the chart
                ActivityChart.update();
            }

            // Call the update function to change the data
            updateChartData();
        });
    </script>
@endsection
