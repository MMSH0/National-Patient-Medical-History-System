@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="add_Test main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">الفحوصات</h4>
                            <p class="mb-0">اضافة فحوصات</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="/add-drug.html">الفحوصات</a></li>
                        </ol>
                    </div>
                </div>


                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow mb-4">
                            <div class="card-header">
                                <div class="col-8">
                                    <h4 class="card-title">اضافة فحص</h4>
                                </div>

                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form method="POST" action="{{ route('admin.test.store') }}" class="needs-validation"
                                        novalidate>
                                        @csrf
                                        <div class="row">
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> اسم الفحص</label>
                                                    <div id="searchContainer">
                                                        <input type="text"
                                                            data-route="http://localhost:4321/patientPortal/public/admin/testSearch"
                                                            name="name" id="name" value="{{ old('name') }}"
                                                            id="validationCustom05" required class="form-control"
                                                            placeholder="اسم الفحص" />
                                                        <ul id="SearchResults"></ul>
                                                        <span id="SpanMessage"></span>
                                                    </div>
                                                    @error('name')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> الطبيعي </label>
                                                    <input id="validationCustom05" required type="text" name="normal"
                                                        class="form-control" value="{{ old('normal') }}"
                                                        placeholder="الطبيعي" />
                                                    @error('normal')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> مرتفع </label>
                                                    <input type="text" id="validationCustom05" required name="high"
                                                        value="{{ old('high') }}" class="form-control"
                                                        placeholder="مرتفع" />
                                                    @error('high')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> منخفض </label>
                                                    <input type="text" value="{{ old('low') }}" name="low"
                                                        id="validationCustom05" required class="form-control"
                                                        placeholder="منخفض" />
                                                    @error('low')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> الوصف </label>
                                                    <input type="text" value="{{ old('description') }}"
                                                        id="validationCustom05" required name="description"
                                                        class="form-control" placeholder="الوصف" />
                                                    @error('description')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> نوع الفحص </label>
                                                    <select value="{{ old('test_type_id') }}" id="validationCustom05"
                                                        required name="test_type_id" class="form-control">

                                                        @foreach ($all_test_type as $test)
                                                            <option value="{{ $test->id }}" class="form-control">
                                                                {{ $test->name }}</option>
                                                        @endforeach

                                                    </select>
                                                    @error('test_type_id')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror
                                                </div>

                                                <div class="col-xl-12">
                                                    <div class="form-group">
                                                        <button type="submit"
                                                            class="btn btn-primary float-end">حفظ</button>
                                                    </div>
                                                </div>
                                            </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->
    </div>
@endsection
