@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">المـرضاء</h4>
                            <p class="mb-0">اضافة مريض</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">المـرضاء</a>
                            </li>
                        </ol>
                    </div>
                </div>




                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم المريض</th>
                                                <th> الجنس </th>
                                                <th>البريد الالكتروني</th>
                                                <th> رقم الهاتف </th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach ($all_patient as $patient)
                                                @if (\Carbon\Carbon::parse($patient->user->person->birthDate)->age > 18)
                                                    <tr>
                                                        <td>#{{ ++$index }} </td>
                                                        <td>{{ $patient->user->person->name }} </td>

                                                        @if ($patient->user->person->gender == 0)
                                                            <td>انثى</td>
                                                        @else
                                                            <td>ذكر</td>
                                                        @endif
                                                        <td>{{ $patient->user->email }} </td>
                                                        <td>{{ $patient->user->phone_number }} </td>

                                                        <td>
                                                            @if ( $patient->user->status=='0')
                                                            <a data-bs-toggle='modal' class='mr-4'>
                                                                <button data-bs-toggle="modal"
                                                                    class="btn btn-danger"> تم رفض تاكيد الحساب </button></a>
                                                            @else


                                                            @if ($patient->user->status=='1')
                                                            <a data-bs-toggle='modal' class='mr-4'>
                                                                <button
                                                                    class="btn btn-primary"> تم تاكيد الحساب </button></a>
                                                            @else
                                                            <a data-bs-toggle='modal' class='mr-4'>
                                                                <button data-bs-toggle="modal" data-bs-target="#showID"
                                                                    onclick="showPDF('{{ $patient->user->person->idinityCardImage }}','{{ $patient->id }}')"
                                                                    class="btn btn-primary"> عرض </button></a>
                                                            @endif


                                                            @endif
                                                        </td>

                                                    </tr>
                                                @endif
                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->
    <!-- Add Surgery -->
    <div class="modal fade selectRefresh" id="showID" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> صورة من البطاقة الشخصية </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.patient.verify') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        <embed src="{{ asset('files/patients/IDCards') }}/" id="fileContent" width="500px"
                            height="600px" />
                        <input type="hidden" name="number" id="pid" />
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#declineID">رفض</button>
                            <button type="submit" value="1" name="submit" class="btn btn-primary">تاكيد </button>
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade selectRefresh" id="declineID" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal">سبب الرفض  </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.patient.decline') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                       <input class="form-control" type="name" name="notes" required/>
                        <input class="form-control" type="hidden" name="number" id="dpid" />
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" value="0" name="submit" class="btn btn-primary">رفض  </button>
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    <script>
        function populateEditModalBlock(id, block) {
            document.getElementById('number').value = id;
            document.getElementById('block').value = block;
        }

        function populateEditModalUnBlock(id, block) {
            document.getElementById('unblockNumber').value = id;
            document.getElementById('unblock').value = block;
        }

        function showPDF(url, pid) {
            document.getElementById('fileContent').src += url;
            document.getElementById('pid').value = pid;
            document.getElementById('dpid').value = pid;
        }
        // Get the modal
        // const modal = document.getElementById('myModal');

        // Get the <span> element that closes the modal
        const span = document.getElementsByClassName('close')[0];

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = 'none';
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    </script>
@endsection
