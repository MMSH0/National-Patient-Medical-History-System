@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">المستشفيات</h4>
                            <p class="mb-0">اضافة مستشفى</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">المستشفيات</a>
                            </li>
                        </ol>
                    </div>
                </div>




                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-7">
                                        <h4 class="card-title"></h4>
                                    </div>

                                    <div class="col-5">
                                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                            data-bs-target="#addHospital"> اضافة مستشفى</button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>الشعار</th>
                                                <th>اسم المستشفى</th>
                                                <th>المدينة</th>
                                                <th>العنوان</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($all_hospital as $hospital)
                                                <tr>
                                                    <td>#{{ ++$index }}</td>
                                                    <td><img loading="lazy" class="rounded-image"
                                                            src="{{ asset('images/hospitals/logos/') }}/{{ $hospital->logo }}">
                                                    </td>
                                                    <td> {{ $hospital->name }} </td>
                                                    <td>{{ $hospital->city }}</td>
                                                    <td>{{ $hospital->address }}</td>

                                                    <td class="text-start">
                                                        <a data-bs-toggle='modal' data-bs-target='#editHospital'
                                                            class='mr-4'
                                                            onclick="populateEditModal('{{ $hospital->id }}','{{ $hospital->name }}', '{{ $hospital->city }}', '{{ $hospital->address }}','{{ asset('images/hospitals/logos/') }}/{{ $hospital->logo }}')">
                                                            <span class='fas fa-pencil-alt tbl-edit'></span>
                                                        </a>
                                                    </td>
                                                </tr>
                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->

    <!-- add hospital  -->
    <div class="modal fade selectRefresh" id="addHospital" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة مستشفى </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.hospital.store') }}"
                        class="row align-items-start needs-validation" novalidate enctype="multipart/form-data">
                        @csrf

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> اسم مستشفى </label>
                                    <div id="searchContainer">
                                        <input id="name"
                                            data-route="http://localhost:4321/patientPortal/public/admin/hospitalSearch"
                                            id="validationCustom05" required value="{{ old('name') }}" type="text"
                                            name="name" class="form-control" placeholder="اسم مستشفى" />
                                        <ul id="SearchResults"></ul>
                                        <span id="SpanMessage"></span>
                                    </div>
                                    @error('name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror


                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> المدينة </label>

                                    <select name="city" class="form-control" id="validationCustom05" required>
                                        <option class="form-control">صنعاء</option>
                                        <option class="form-control">تعز</option>
                                        <option class="form-control">اب</option>
                                        <option class="form-control">عدن</option>
                                    </select>
                                    @error('city')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> شعار مستشفى </label>
                                    <input type="file" name="logo" class="form-control" id="validationCustom05"
                                        required />
                                    @error('logo')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                            <div class="col">
                                <label for="validationCustom05" class="form-label"> عنوان مستشفى </label>

                                <input type="text" value="{{ old('address') }}" name="address" class="form-control"
                                    placeholder="العنوان" id="validationCustom05" required />
                                @error('address')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <!-- edit hospital -->
    <div class="modal fade selectRefresh" id="editHospital" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> تعديل بيانات المستشفى </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.hospital.update') }}"
                        class="row align-items-start needs-validation" novalidate enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <input type="hidden" id="editHospitalid" name="number" />

                        <div class="row">

                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> اسم مستشفى </label>
                                    <div id="searchContainer">
                                        <input
                                            data-route="http://localhost:4321/patientPortal/public/admin/hospitalSearch"
                                            value="{{ old('name') }}" type="text" name="name"
                                            class="form-control" placeholder="اسم مستشفى" id="editName"
                                            id="validationCustom05" required />
                                        <ul id="SearchResult"></ul>
                                    </div>
                                    @error('name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> المدينة </label>

                                    <select name="city" class="form-control" id="editHospitalCity"
                                        id="validationCustom05" required>
                                        <option>صنعاء</option>
                                        <option>تعز</option>
                                        <option>اب</option>
                                        <option>عدن</option>
                                    </select>
                                    @error('city')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <label for="validationCustom05" class="form-label"> عنوان المستشفى </label>

                                <input value="{{ old('address') }}" type="text" name="address" class="form-control"
                                    placeholder="العنوان" data-id="editHospitalAddress" id="editHospitalAddress"
                                    id="validationCustom05" required />
                                @error('address')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror
                            </div>


                            <div class="col">
                                <div class="form-group">
                                    <img loading="lazy" style="width: 5rem;" src="#" id="editLogo"
                                        id="validationCustom05">

                                    <label for="validationCustom05" class="form-label"> شعار مستشفى </label>
                                    <input type="file" name="logo" class="form-control" id="validationCustom05" />
                                    @error('logo')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>



    <script>
        function populateEditModal(id, name, city, address, logo) {
            document.getElementById('editHospitalid').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('editHospitalCity').value = city;
            document.getElementById('editHospitalAddress').value = address;
            document.getElementById('editLogo').src = logo;
        }
    </script>
@endsection
