@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">العيادات</h4>
                            <p class="mb-0">اضافة عيادة</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="/add-test.html">العيادات</a>
                            </li>
                        </ol>
                    </div>
                </div>




                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-7">
                                        <h4 class="card-title">العيادات</h4>
                                    </div>
                                    <div class="col-5">
                                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                            data-bs-target="#addClinc"> اضافة عيادة </button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th> الشعار </th>
                                                <th>اسم العيادة</th>
                                                <th>المدينة</th>
                                                <th>العنوان</th>
                                                <th>خاصة / تابعة</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($all_building as $building)
                                                <tr>

                                                    <td>#{{ ++$index }}</td>
                                                    <td>
                                                        <img loading="lazy" class="rounded-image"
                                                            src="{{ asset('images/buildings/logos/') }}/{{ $building->logo }}">
                                                    </td>
                                                    <td> {{ $building->name }}</td>
                                                    <td> {{ $building->city }}</td>
                                                    <td> {{ $building->address }}</td>
                                                    @if ($building->hospital_id == 0)
                                                        <td> عيادة خاصة</td>
                                                    @else
                                                        <td>مستشفى {{ $building->hospital->name }} </td>
                                                    @endif
                                                    <td class="text-start">
                                                        <a data-bs-toggle='modal' data-bs-target='#editClinc' class='mr-4'
                                                            onclick="populateEditModal('{{ $building->id }}','{{ $building->name }}', '{{ $building->city }}', '{{ $building->address }}','{{ $building->hospital_id }}','{{ asset('images/buildings/logos/') }}/{{ $building->logo }}');">

                                                            <span class='fas fa-pencil-alt tbl-edit'></span>
                                                        </a>

                                                    </td>
                                                </tr>
                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->


    <!-- Add Clinc -->
    <div class="modal fade selectRefresh" id="addClinc" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة عيادة </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.clinc.store') }}" id="editclinc"
                        class="row align-items-start needs-validation" novalidate enctype="multipart/form-data">
                        @csrf

                        <div class="row">

                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> اسم العيادة </label>

                                    <div id="searchContainer">

                                        <input id="name"
                                            data-route="http://localhost:4321/patientPortal/public/admin/clincSearch"
                                            required value="{{ old('name') }}" type="text" name="name"
                                            class="form-control" id="validationCustom05" placeholder="اسم العيادة" />

                                        <ul id="SearchResults"></ul>
                                        <span id="SpanMessage"></span>
                                    </div>
                                    @error('name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror


                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> المدينة </label>

                                    <select id="clincAddCity" id="validationCustom05" required name="city"
                                        class="form-control">
                                        <option class="form-control">صنعاء</option>
                                        <option class="form-control">تعز</option>
                                        <option class="form-control">اب</option>
                                        <option class="form-control">عدن</option>
                                    </select>
                                    @error('city')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>

                        </div>



                        <div class="row align-items-start">

                            <div class="form-group">
                                <label for="validationCustom05" class="form-label"> اسم المستشفى / عيادة خارجية
                                </label>

                                <select id="validationCustom05" onchange="disabledInput(this);" required name="hospital"
                                    id="hospital" class="form-control">
                                    <option value="0">عيادة خارجية</option>
                                    @foreach ($all_hospitall as $hospitall)
                                        <option value="{{ $hospitall->id }}" class="form-control">
                                            {{ $hospitall->name }} - {{ $hospitall->city }} -
                                            {{ $hospitall->address }}</option>
                                    @endforeach
                                </select>
                                @error('hospital_id')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror

                            </div>
                        </div>

                        <div class="row align-items-start">
                            <div class="col">
                                <label for="validationCustom05" class="form-label"> عنوان العيادة </label>

                                <input id="clincAddAddress" id="validationCustom05" required
                                    value="{{ old('address') }}" name="address" class="form-control"
                                    placeholder="العنوان" />
                                @error('address')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror

                            </div>
                            <div class="col">
                                <div class="form-group">

                                    <label for="validationCustom05" class="form-label"> شعار العيادة </label>
                                    <input type="file" name="logo" class="form-control" id="validationCustom05"
                                        required />
                                    @error('logo')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    </div>



    <!-- Edit Clinc -->


    <div class="modal fade selectRefresh" id="editClinc" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> تعديل بيانات العيادة </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.clinc.update') }}" id="addClinc"
                        class="row align-items-start needs-validation" enctype="multipart/form-data" novalidate>
                        @csrf
                        @method('PUT')
                        <input name="number" id="clincNumber" type="hidden" />

                        <div class="row">

                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> اسم العيادة </label>
                                    <div id="searchContainer">

                                        <input data-route="http://localhost:4321/patientPortal/public/admin/clincSearch"
                                            type="text" value="{{ old('name') }}" id="editName" name="name"
                                            class="form-control" placeholder="اسم العيادة" id="validationCustom05"
                                            required />
                                        <ul id="SearchResult"></ul>
                                    </div>
                                    @error('name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> المدينة </label>

                                    <select id="clincCity" name="city" class="form-control" id="validationCustom05"
                                        required>
                                        <option value="صنعاء" class="form-control">صنعاء</option>
                                        <option value="تعز" class="form-control">تعز</option>
                                        <option value="اب" class="form-control">اب</option>
                                        <option value="عدن" class="form-control">عدن</option>
                                    </select>
                                    @error('city')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                        </div>

                        <div class="row align-items-start">
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label"> اسم المستشفى / عيادة خارجية
                                    </label>

                                    <select id="clincHospital" onchange="disabledInputs(this);" name="hospital"
                                        class="form-control" id="validationCustom05" required>
                                        <option value="0">عيادة خارجية</option>
                                        @foreach ($all_hospitall as $hospitall)
                                            <option value="{{ $hospitall->id }}" class="form-control">
                                                {{ $hospitall->name }} - {{ $hospitall->city }} -
                                                {{ $hospitall->address }}</option>
                                        @endforeach
                                    </select>
                                    @error('hospital_id')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <img loading="lazy" style="width: 5rem;" src="#" id="editLogo"
                                        id="validationCustom05">

                                    <label for="validationCustom05" class="form-label"> شعار العيادة </label>
                                    <input type="file" name="logo" class="form-control" id="editLogoFile"
                                        id="validationCustom05" />
                                    @error('logo')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>
                        </div>


                        <div class="row align-items-start">
                            <label for="validationCustom05" class="form-label"> عنوان العيادة </label>

                            <input id="clincAddress" name="address" value="{{ old('address') }}" class="form-control"
                                id="validationCustom05" required placeholder="العنوان" />
                            @error('address')
                                <span class="error-message">{{ $message }}</span>
                            @enderror

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    </div>


    <script>
        function populateEditModal(id, name, city, address, hospital, logo) {
            document.getElementById('clincNumber').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('clincCity').value = city;
            document.getElementById('clincAddress').value = address;
            document.getElementById('clincHospital').value = hospital;
            document.getElementById('editLogo').src = logo;
            document.getElementById('editLogoFile').src = logo;
        }


        function disabledInputs(data) {
            [_, city, address] = data.options[data.selectedIndex].text.split('-');

            document.getElementById('clincAddress').value = address;
            document.getElementById('clincCity').value = city;
            var inputs = document.querySelectorAll('#clincCity, #clincAddress');
            if (data.value !== '0') {

                inputs.forEach(function(input) {

                    input.disabled = true;
                });
            } else {
                document.getElementById('clincAddress').value = '';
                document.getElementById('clincCity').options[0].text = '';
                inputs.forEach(function(input) {
                    input.disabled = false;
                });
            }
        }




        function disabledInput(data) {
            [_, city, address] = data.options[data.selectedIndex].text.split('-');

            document.getElementById('clincAddAddress').value = address;
            document.getElementById('clincAddCity').options[0].text = city;
            var inputs = document.querySelectorAll('#clincAddCity, #clincAddAddress');
            if (data.value !== '0') {

                inputs.forEach(function(input) {

                    input.disabled = true;
                });
            } else {
                document.getElementById('clincAddAddress').value = '';
                document.getElementById('clincAddCity').options[0].text = '';
                inputs.forEach(function(input) {
                    input.disabled = false;
                });
            }
        }
        document.getElementById('addClinc').addEventListener('submit', function(event) {
            // Enable the fields just before submitting the form
            var inputs = document.querySelectorAll('#clincAddCity, #clincAddAddress');
            inputs.forEach(function(input) {
                input.disabled = false;
            });
        });
        document.getElementById('editclinc').addEventListener('submit', function(event) {
            // Enable the fields just before submitting the form
            var inputs = document.querySelectorAll('#clincCity, #clincAddress');
            inputs.forEach(function(input) {
                input.disabled = false;
            });
        });
    </script>
@endsection
