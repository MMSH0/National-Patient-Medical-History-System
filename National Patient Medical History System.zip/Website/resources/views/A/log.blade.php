@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="All-Rays main_container">

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-7">
                                        <h4 class="card-title"> الأشعة </h4>
                                    </div>

                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم المستخدم</th>
                                                <th>العملية</th>
                                                <th>البيانات قبل التعديل</th>
                                                <th>البيانات بعد التعديل</th>
                                                <th>تاريخ و وقت التعديل</th>
                                            </tr>
                                        </thead>
                                        <tbody>


                                            @foreach ($logs as $log)
                                                <tr>

                                                    <td>{{ ++$index }}</td>
                                                    @foreach ($log as $key => $value)
                                                        @if ($value == null)
                                                            <td style="background-color: #fff3cd;
                                                            color: #000;"> لاتوجد بيانات </td>
                                                        @else
                                                            @if ($key == 'oldValue')
                                                                <td style="    background-color: #f8d7da;
                                                                color: #000;"> {{ $value }}</td>
                                                            @else
                                                                @if ($key == 'newValue')
                                                                    <td style="background-color: #d1e7dd;
                                                                    color: #000;"> {{ $value }}</td>
                                                                @else

                                                                <td> {{ $value }}</td>


                                                                @endif
                                                            @endif
                                                        @endif
                                                    @endforeach

                                                </tr>
                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End section content -->
@endsection

{{-- <ul>
                @foreach ($logs as $log)
                    <li>
                        <ul>

                            @foreach ($log as $key => $value)
                                <li>{{ $key }}: {{ $value }}</li>
                            @endforeach
                        </ul>
                    </li>
                @endforeach
            </ul> --}}
