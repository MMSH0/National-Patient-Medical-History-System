
@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">التخصصات الطبية</h4>
                            <p class="mb-0">اضافة التخصص</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">اضافة تخصص</a>
                            </li>
                        </ol>
                    </div>
                </div>

                {{-- message --}}
                {{-- @if (session('success')) --}}

                {{-- @endif --}}

                @if (session('error'))
                    <div class="container mt-5" id="successAlert">
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <span class="message">{{ session('error') }}</span>
                            <div class="progress" style="height: 2px;">
                                <div class="progress-bar bg-danger flex-row-reverse mr-auto ml-auto" role="progressbar"
                                    style="width:0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"
                                    id="progressBar"></div>
                            </div>
                        </div>

                    </div>
                @endif
                {{-- message --}}


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-7">
                                        <h4 class="card-title">التخصصات</h4>
                                    </div>
                                    <div class="col-3">
                                        <abbr title="استيراد اسماء التخصصات الطبية من ملف خارجي">
                                            <button type="button" class="btn btn-danger float-end" data-bs-toggle="modal"
                                                data-bs-target="#excelModel"> استيراد اسماء التخصصات</button>
                                        </abbr>
                                    </div>
                                    <div class="col-2">
                                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                            data-bs-target="#addSpecialty"> اضافة تخصص</button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>الاسم</th>
                                                <th>الدرجة العلمية</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach ($all_special as $special)
                                                <tr>
                                                    <td>#{{ ++$index }}</td>
                                                    <td> {{ $special->name }} </td>
                                                    <td>{{ $special->degree }}</td>
                                                    <td class="text-start">
                                                        <a data-bs-toggle='modal' data-bs-target='#editSpecialty'
                                                            class='mr-4'
                                                            onclick="populateEditModal('{{ $special->id }}','{{ $special->name }}', '{{ $special->degree }}')">
                                                            <span class='fas fa-pencil-alt tbl-edit'></span>
                                                        </a>

                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->


    <!-- Add Specialty -->
    <div class="modal fade selectRefresh" id="addSpecialty" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة تخصص </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.specialty.store') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        <div class="col">
                            <div class="form-group">
                                <label for="validationCustom05" class="form-label"> اسم التخصص التخصص الطبي </label>
                                <div id="searchContainer">
                                    <input type="text" name="name"
                                        data-route="http://localhost:4321/patientPortal/public/admin/specialtySearch" class="form-control"
                                        placeholder="اسم التخصص" id="name" value="{{ old('name') }}"
                                        id="validationCustom05" required />
                                    <ul id="SearchResults"></ul>
                                    <span id="SpanMessage"></span>

                                </div>
                                @error('name')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror



                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">

                                <label for="validationCustom05" class="form-label"> الدرجة العلمية </label>

                                <input name="degree" type="text" class="form-control" placeholder="الدرجة العلمية"
                                    value="{{ old('degree') }}" id="validationCustom05" required />
                                @error('degree')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>



    <!-- Edit Specialty -->
    <div class="modal fade selectRefresh" id="editSpecialty" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> تعديل بيانات التخصص الطبي</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.specialty.update') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="number" id="specialtyNumber" />
                        <div class="col">
                            <div class="form-group">
                                <label for="validationCustom05" class="form-label"> اسم التخصص التخصص الطبي </label>
                                <div id="searchContainer">
                                    <input type="text" name="name"
                                        data-route="http://localhost:4321/patientPortal/public/admin/specialtySearch" class="form-control"
                                        id="editName" placeholder="اسم التخصص" value="{{ old('name') }}"
                                        id="validationCustom05" required />

                                    <ul id="SearchResult"></ul>
                                </div>
                                @error('name')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                            </div>

                        </div>
                        <div class="col">
                            <div class="form-group">

                                <label for="validationCustom05" class="form-label"> الدرجة العلمية </label>

                                <input name="degree" type="text" id="specialtyDegree" class="form-control"
                                    placeholder="الدرجة العلمية" value="{{ old('degree') }}" id="validationCustom05"
                                    required />
                                @error('degree')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <!-- DELET DIALG -->
    <div class="modal fade selectRefresh" id="deleteSpecialt" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة علاج </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form class="row align-items-start">
                        <div class="col">
                            <h5>هل متاكد من حذف التخصص؟</h5>
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">اغلاق</button>
                    <button type="button" class="btn btn-danger"> حذف البيانات</button>
                </div>
            </div>
        </div>
    </div>

    </div>









    <!-- csv xsxl excel  -->


    <div class="modal fade selectRefresh" id="excelModel" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal">استيراد اسماء التخصصات الطبية من ملف خارجي</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.specialty.csv.store') }}"
                        class="row align-items-center" enctype="multipart/form-data">
                        @csrf
                        <div class="mb-3">
                            <input class="form-control" id="formFile" name="file" type="file">
                            <p class="text-danger">.xslx .cvs</p>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>




    <script>
        function populateEditModal(id, name, degree) {
            document.getElementById('specialtyNumber').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('specialtyDegree').value = degree;
        }
    </script>
@endsection
