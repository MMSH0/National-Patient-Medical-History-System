@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new-patients main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">الاطباء</h4>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active">
                                <a href="#">قسم الاطباء</a>
                            </li>
                        </ol>
                    </div>
                </div>
                <form method="POST" action="{{ route('admin.doctor.store') }}" id="doctorForm" class="needs-validation" novalidate
                    enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">بيانات الطبيب</h4>
                                </div>
                                <div class="card-body">
                                    <div class="basic-form">

                                        @csrf
                                        <div class="row">
                                            <div class="col-xl-4">
                                                <div class="form-group row widget-3">
                                                    <div class="col-lg-10">
                                                        <div class="form-input" id="DProfile">
                                                            <label for="validationCustom05" class="labeltest"
                                                                for="file-ip-1">
                                                                <span>
                                                                    اضغط هنا لاضافة صورة
                                                                </span>
                                                            </label>
                                                            <input id="validationCustom05" name="image" type="file"
                                                                id="file-ip-1" accept="image/*"
                                                                onchange="showPreview(event);" required />


                                                            <div class="preview">
                                                                <img loading="lazy" id="file-ip-1-preview" src="#"
                                                                    alt="img" />
                                                            </div>
                                                            @error('image')
                                                                <span class="error-message">{{ $message }}</span>
                                                            @enderror
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> الاسم الاول </label>

                                                    <input id="validationCustom05" value="{{ old('first_name') }}"
                                                        type="text" name="first_name" class="form-control"
                                                        placeholder="الاسم الاول" required />
                                                    @error('first_name')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> اللقب </label>

                                                    <input value="{{ old('last_name') }}" id="validationCustom05"
                                                        type="text" name="last_name" class="form-control"
                                                        placeholder="اللقب" required />
                                                    @error('last_name')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> البريد الالكتروني
                                                    </label>

                                                    <input id="validationCustom05" type="email"
                                                        value="{{ old('email') }}" name="email" class="form-control"
                                                        placeholder=" example@email.com " required />
                                                    @error('email')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>
                                                <div class="form-group">
                                                    <div class="col-lg-12">
                                                        <label for="validationCustom05" class="form-label"> مكان الميلاد
                                                        </label>

                                                        <select id="validationCustom05" required name="city"
                                                            class="form-control form-select">

                                                            <option>صنعاء</option>
                                                            <option>تعز</option>
                                                            <option>عدن</option>
                                                            <option>ذمار</option>
                                                        </select>
                                                        @error('city')
                                                            <span class="error-message">{{ $message }}</span>
                                                        @enderror

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> الجنس </label>

                                                    <select id="validationCustom05" required name="geneder"
                                                        class="form-control form-select">

                                                        <option value="1">ذكر</option>
                                                        <option value="0">انثى</option>
                                                    </select>
                                                    @error('geneder')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label">رقم الهاتف</label>

                                                    <input name="phone" id="phone" maxlength="9" minlength="8"
                                                        value="{{ old('phone') }}" type="number" class="form-control"
                                                        placeholder="7xxxxxxxx" id="validationCustom05" required />
                                                    <span class="error-message" id="phone_number_error"></span>

                                                    @error('phone')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>
                                                <div class="col form-group">
                                                    <label for="validationCustom05" class="form-label">رقم بطاقة
                                                        الهوية</label>

                                                    <input value="{{ old('identity_card') }}" id="validationCustom05"
                                                        required name="identity_card" type="number" class="form-control"
                                                        placeholder= "xxxxxxxxxxx" />
                                                    @error('identity_card')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>
                                                <div class="md-form md-outline input-with-post-icon datepicker">
                                                    <label for="validationCustom05" class="form-label">تاريخ
                                                        الميلاد</label>

                                                    <input value="{{ old('birthday') }}" name="birthday"
                                                        class="form-control" id="validationCustom05" required
                                                        type="date" data-date-format="yyyy-mm-dd" />
                                                    @error('birthday')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>

                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xl-1"></div>
                                            <div class="col-xl-5">


                                                <div class="row py-2">
                                                    <div class="col-lg-12 mx-auto">

                                                        <!-- Upload image input-->
                                                        <div class="input-group mb-3 px-4 py-4 rounded-pill">
                                                            <input id="upload" id="validationCustom05" required
                                                                name="indentityCardImage_F" type="file"
                                                                onchange="readURL(this);" class="form-control border-0">
                                                            <div class="input-group-append">
                                                                <label for="upload"
                                                                    class="btn btn-light m-0 rounded-pill px-4"> <i
                                                                        class="fa fa-cloud-upload mr-2 text-muted"></i><small
                                                                        class="text-uppercase font-weight-bold text-muted">
                                                                        اضغط هنا لاضافة صورة البطاقة
                                                                        الشخصية(الامامية).</small></label>
                                                            </div>
                                                        </div>

                                                        <div class="image-area mt-4"><img loading="lazy" id="imageResult"
                                                                src="#" alt=""
                                                                class="img-fluid rounded shadow-sm mx-auto d-block"></div>

                                                    </div>
                                                </div>

                                                @error('indentityCardImage_F')
                                                    <span class="error-message">{{ $message }}</span>
                                                @enderror




                                            </div>

                                            <div class="col-xl-5">

                                                <div class="row py-2">

                                                    <div class="col-lg-12 mx-auto">

                                                        <!-- Upload image input-->
                                                        <div class="input-group mb-3 px-4 py-4 rounded-pill">
                                                            <input id="backUpload" type="file" id="validationCustom05"
                                                                required name="indentityCardImage_B"
                                                                onchange="getURL(this);" class="form-control border-0">
                                                            <div class="input-group-append">
                                                                <label for="backUpload"
                                                                    class="btn btn-light m-0 rounded-pill px-4"> <i
                                                                        class="fa fa-cloud-upload mr-2 text-muted"></i><small
                                                                        class="text-uppercase font-weight-bold text-muted">
                                                                        اضغط هنا لاضافة صورة البطاقة
                                                                        الشخصية(الخلفية).</small></label>
                                                            </div>
                                                        </div>

                                                        <div class="image-area mt-4"><img loading="lazy"
                                                                id="backImageResult" src="#" alt=""
                                                                class="img-fluid rounded shadow-sm mx-auto d-block"></div>
                                                        @error('indentityCardImage_B')
                                                            <span class="error-message">{{ $message }}</span>
                                                        @enderror
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">

                                            <div class="col form-input">
                                                <label for="validationCustom05" class="form-label">العنوان</label>
                                                <input class="form-control" value="{{ old('address') }}"
                                                    id="validationCustom05" name="address" placeholder="العنوان "
                                                    required />
                                            </div>
                                            @error('address')
                                                <span class="error-message">{{ $message }}</span>
                                            @enderror

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">معلومات طبيبة</h4>
                                </div>
                                <div class="card-body">
                                    <div class="basic-form">

                                        <div class="row">
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label">التخصص
                                                        الرئيسي</label>
                                                    <select name="specialty_1" id="validationCustom05" required
                                                        class="form-control form-select">
                                                        @foreach ($all_specialty as $specialty)
                                                            <option value="{{ $specialty->id }}">{{ $specialty->name }}
                                                            </option>
                                                        @endforeach

                                                    </select>
                                                    <div class="col-lg-12"></div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label">التخصص آخرى</label>
                                                    <select name="specialty_2" id="validationCustom05" required
                                                        class="form-control form-select">
                                                        <option value="0">لا يوجد تخصص اخرى</option>
                                                        @foreach ($all_specialty as $specialty)
                                                            <option value="{{ $specialty->id }}">{{ $specialty->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label">
                                                        الدرجة الطبية
                                                    </label>
                                                    <select name="degree" id="validationCustom05" required
                                                        class="form-control form-select">
                                                        <option>بكالريوس</option>
                                                        <option> ماجيستير </option>
                                                        <option> بورد </option>
                                                        <option> استشاري </option>
                                                        <option> بروفيسور </option>
                                                    </select>
                                                    @error('degree')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label">
                                                        السيرة الذاتية </label>
                                                    <input id="validationCustom05" required type="file"
                                                        name="exprience" class="form-control" />
                                                    @error('exprience')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label">
                                                        اسم المستشفى</label>
                                                    <select class="form-control form-select" id="selectHospital"
                                                        name="hospitals[]" multiple="multiple"
                                                        aria-expanded="true">
                                                        @foreach ($all_hospital as $hospital)
                                                            <option value="{{ $hospital->id }}">{{ $hospital->name }}
                                                            </option>
                                                        @endforeach

                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label">
                                                        اسم العيادة</label>
                                                    <select class="form-control form-select" id="selectClinc"
                                                        name="clincs[]" multiple="multiple"
                                                        aria-expanded="true">
                                                        @foreach ($all_clinc as $clinc)
                                                            <option value="{{ $clinc->id }}">{{ $clinc->name }}
                                                            </option>
                                                        @endforeach

                                                    </select>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="form-group text-right">
                                            <button type="submit" id="submitButton" name="submit"
                                                class="btn btn-primary float-end">
                                                حفظ
                                            </button>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </form>

            </div>
        </div>
    </div>
    <!-- End section content -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            function validateInput(value) {
                // Ensure the maximum length is 9
                if (value.length > 9) {
                    return value.substring(0, 9);
                }

                if (value.length > 1) {
                    if (!/^[7]([13780])/.test(value)) {
                        return value.substring(0, value.length - 1);
                    }
                } else if (!/^[7]/.test(value)) {
                    return value.substring(0, value.length - 1);
                }

                return value;
            }

            document.getElementById('phone').addEventListener('input', function(event) {
                const inputField = event.target;
                const inputValue = inputField.value;
                const messageSpan = document.getElementById('phone_number_error');

                const newValue = validateInput(inputValue);


                if ((newValue !== inputValue)) {

                    inputField.value = newValue;
                    if (inputValue.length < 9) {
                        messageSpan.textContent = "يجب ادخل الرقم بشكل صحيح";

                    } else {
                        messageSpan.textContent = "";
                    }

                } else {

                    messageSpan.textContent = ""; // Clear the message if input is valid
                }

                // Set the cursor position to the end of the input
                inputField.selectionStart = inputField.selectionEnd = inputField.value.length;
            });

        });
        document.addEventListener('DOMContentLoaded', function() {
            const selectHospital = document.getElementById('selectHospital');
            const selectClinc = document.getElementById('selectClinc');
            const submitButton = document.getElementById('submitButton');
            const form = document.getElementById('doctorForm');

            function checkSelects() {
                const isHospitalSelected = Array.from(selectHospital.options).some(option => option.selected && option.value !== '');
                const isClincSelected = Array.from(selectClinc.options).some(option => option.selected && option.value !== '');

                if (isHospitalSelected || isClincSelected) {
                    selectHospital.required = false;
                    selectClinc.required = false;
                } else {
                    selectHospital.required = true;
                    selectClinc.required = true;
                }
            }

            selectHospital.addEventListener('change', checkSelects);
            selectClinc.addEventListener('change', checkSelects);

            form.addEventListener('submit', function(event) {
                checkSelects(); // Ensure validation before submit
                if (selectHospital.required && selectClinc.required) {
                    event.preventDefault(); // Prevent form submission if both are still required
                    // alert('يرجى اختيار إما مستشفى أو عيادة.');
                }
            });

            checkSelects(); // Initial check in case selects are pre-selected
        });
    </script>
@endsection
