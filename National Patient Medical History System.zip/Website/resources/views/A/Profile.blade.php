@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h4 class="text-primary">الحساب</h4>
                        <p class="mb-0">تعديل البيانات</p>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                        <li class="breadcrumb-item active"><a href="#">الحساب</a></li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="profile-header">
                        <form method="POST" action="{{ route('admin.profile.image') }}" novalidate
                            enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="number" value="{{ Auth::user()->id }}" />
                            <div class="row ">
                                <div class="col-4">
                                    <div class="form-group row widget-3">
                                        <div class="col-lg-10">
                                            <div class="form-input"
                                                style="background-image:
                                                @if (isset(Auth::user()->person->prsonalImage)) url('{{ asset('images/admin/') }}/{{ Auth::user()->person->prsonalImage }}')
                                                @else
                                                url('{{ asset('images/client.jpg') }}') @endif
                                                ;     background-size: cover;
                                                    background-repeat: no-repeat;
                                                ">

                                                <label class="labeltest" for="file-ip-1">
                                                    <span>
                                                        اضغط هنا لاضافة صورة
                                                    </span>
                                                </label>
                                                <input required type="file" id="file-ip-1" accept="image/*"
                                                    id="validationCustom05" onchange="showPreview(event);" name="image" />
                                                <div class="preview">
                                                    <img loading="lazy" id="file-ip-1-preview"
                                                        src="{{ asset('images/admin') }}/{{ Auth::user()->person->prsonalImage }}"
                                                        alt="img" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                                <div class="col ml-md-n2 m-29 profile-user-info">
                                    <h4 class="user-name mb-3">{{ Auth::user()->person->name }} </h4>
                                    @if ($usertype == 'superadmin')
                                        <h6 class="text-muted mt-1">مدير النظام</h6>
                                    @else
                                        <h6 class="text-muted mt-1">مشرف</h6>
                                    @endif
                                    <div class="user-Location mt-1">
                                        <i style="color: #7366ff;" class="fas fa-map-marker-alt"></i>
                                        {{ Auth::user()->person->address }}
                                    </div>
                                    <br />
                                    <br />
                                    <br />
                                    <br />
                                    <br />
                                    <button type="submit" class="btn btn-primary">تحديث الصورة</button>
                                </div>

                            </div>

                        </form>
                        <div class="tab-pane fade show active" id="solid-rounded-justified-tab3">
                            <div class="row">
                                <div class="col">
                                    <div class="card ">
                                        <div class="card-body">
                                            <h5 class="card-title d-flex justify-content-between">
                                                <span>بيانات الحساب</span>
                                                <button
                                                    onclick="populateEditModal('{{ Auth::user()->person->name }}','{{ Auth::user()->person->birthDate }}','{{ Auth::user()->email }}','{{ Auth::user()->phone_number }}','{{ Auth::user()->person->address }}');"
                                                    type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                                    data-bs-target="#edit_personal_details"> تعديل
                                                    البيانات </button>
                                            </h5>
                                            <div class="row mt-5">
                                                <p class="col-sm-3 text-sm-right mb-0 mb-sm-3">
                                                    الاسم
                                                </p>
                                                <p class="col-sm-9"> {{ Auth::user()->person->name }}</p>
                                            </div>
                                            <div class="row">
                                                <p class="col-sm-3 text-sm-right mb-0 mb-sm-3">
                                                    تاريخ الميلاد
                                                </p>
                                                <p class="col-sm-9"> {{ Auth::user()->person->birthDate }} </p>
                                            </div>
                                            <div class="row">
                                                <p class="col-sm-3 text-sm-right mb-0 mb-sm-3">
                                                    البريد الالكتروني
                                                </p>
                                                <p class="col-sm-9">
                                                    {{ Auth::user()->email }}
                                                </p>
                                            </div>
                                            <div class="row">
                                                <p class="col-sm-3 text-sm-right mb-0 mb-sm-3">
                                                    رقم الهاتف
                                                </p>
                                                <p class="col-sm-9">{{ Auth::user()->phone_number }}</p>
                                            </div>
                                            <div class="row">
                                                <p class="col-sm-3 text-sm-right mb-0">العنوان</p>
                                                <p class="col-sm-9 mb-0">
                                                    {{ Auth::user()->person->address }}
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                        <div id="password_tab" class="tab-pane fade show active">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">تغير كلمة السر</h5>
                                    <div class="row">
                                        <div class="col-md-10 col-lg-6">
                                            <form action="{{ route('admin.profile.password') }}" method="POST"
                                                class="row align-items-start needs-validation" novalidate>
                                                @csrf
                                                <input type="hidden" name="number" value="{{ Auth::user()->id }}" />
                                                <div class="form-group">
                                                    <label for="validationCustom01">كلمة السر القديمة</label>
                                                    <input name="oldPassword" id="validationCustom01" type="password"
                                                        class="form-control" autocomplete="current-password" required />
                                                </div>
                                                <div class="form-group">
                                                    <label for="validationCustom02">كلمة السر الجديدة</label>
                                                    <input name="newPassword" class="form-control" id="validationCustom02"
                                                        type="password" autocomplete="new-password" required />
                                                </div>
                                                <div class="form-group">
                                                    <label for="validationCustom03">تاكيد كلمة السر</label>
                                                    <input name="newPassword2" type="password" class="form-control"
                                                        autocomplete="new-password" id="validationCustom03" required />
                                                </div>
                                                <button class="btn btn-primary" type="submit">
                                                    حفظ التعديلات
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- End section content -->


        <!-- start edit model -->
        <div class="modal fade" id="edit_personal_details" aria-hidden="true" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">تعديل البيانات</h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="{{ route('admin.profile.update') }}" method="POST"
                            class="row align-items-start needs-validation" novalidate>
                            @csrf
                            <input name="number" type="hidden" value="{{ Auth::user()->id }}" />
                            <div class="row form-row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="validationCustom05">اسمك</label>
                                        <input name="name" id="userName" id="validationCustom05" type="text"
                                            class="form-control" placeholder="اسم المسؤول" required />
                                        @error('name')
                                            <span class="error-message">{{ $message }}</span>
                                        @enderror
                                    </div>

                                </div>

                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="validationCustom05">تاريخ ميلاد</label>
                                        <div class="cal-icon">
                                            <input name="birthDate" id="userBirthdate" id="validationCustom05"
                                                type="date" data-date-format="yyyy-mm-dd" class="form-control"
                                                placeholder="24-07-1983" required />
                                            @error('birthDate')
                                                <span class="error-message">{{ $message }}</span>
                                            @enderror
                                        </div>

                                    </div>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="validationCustom05">البريد الالكتروني</label>
                                        <input name="email" id="userEmail" id="validationCustom05" type="email"
                                            class="form-control" placeholder="email@example.com" required />
                                        @error('email')
                                            <span class="error-message">{{ $message }}</span>
                                        @enderror
                                    </div>

                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label>رقم الهاتف</label>
                                        <input id="phone" maxlength="9" minlength="9" name="phoneNumber" id="userPhone" id="validationCustom05" type="number"
                                            placeholder="7×××××××××" class="form-control" required />
                                        <span id="phone_number_error" class="error-message"></span>
                                        @error('phoneNumber')
                                            <span class="error-message">{{ $message }}</span>
                                        @enderror
                                    </div>

                                </div>
                                <div class="col-12">
                                    <h5 class="form-title">
                                        <span>العنوان</span>
                                    </h5>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="validationCustom05">العنوان</label>
                                        <input name="address" id="userAddress" id="validationCustom05" type="text"
                                            class="form-control" placeholder="التحرير" required />
                                        @error('address')
                                            <span class="error-message">{{ $message }}</span>
                                        @enderror
                                    </div>

                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="validationCustom05">المدينة</label>
                                        <select name="birthCity" id="validationCustom05" type="text"
                                            class="form-control" required>
                                            <option>صنعاء</option>
                                        </select>
                                        @error('birthCity')
                                            <span class="error-message">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">
                                حفظ التعديلات
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--edit model  -->



        <script>
            function populateEditModal(name, birthdate, email, phone, address) {
                document.getElementById('userName').value = name;
                document.getElementById('userBirthdate').value = birthdate;
                document.getElementById('userAddress').value = address;
                document.getElementById('userEmail').value = email;
                document.getElementById('phone').value = phone;
            }




        document.addEventListener('DOMContentLoaded', function() {
            function validateInput(value) {
                // Ensure the maximum length is 9
                if (value.length > 9) {
                    return value.substring(0, 9);
                }

                if (value.length > 1) {
                    if (!/^[7]([13780])/.test(value)) {
                        return value.substring(0, value.length - 1);
                    }
                } else if (!/^[7]/.test(value)) {
                    return value.substring(0, value.length - 1);
                }

                return value;
            }

            document.getElementById('phone').addEventListener('input', function(event) {
                const inputField = event.target;
                const inputValue = inputField.value;
                const messageSpan = document.getElementById('phone_number_error');

                const newValue = validateInput(inputValue);


                if ((newValue !== inputValue)) {

                    inputField.value = newValue;
                    if (inputValue.length < 9) {
                        messageSpan.textContent = "يجب ادخل الرقم بشكل صحيح";

                    } else {
                        messageSpan.textContent = "";
                    }

                } else {

                    messageSpan.textContent = ""; // Clear the message if input is valid
                }

                // Set the cursor position to the end of the input
                inputField.selectionStart = inputField.selectionEnd = inputField.value.length;
            });
        });



        </script>
    @endsection
