    @extends('layout.admin_layout')
    @section('content')
        <!-- start section content -->
        <div class="content-body">
            <div class="warper container-fluid">
                <div class="new_appointment main_container">
                    <div class="row page-titles mx-0">
                        <div class="col-sm-6 p-md-0">
                            <div class="welcome-text">
                                <h4 class="text-primary">الامراض المزمنة</h4>
                                <p class="mb-0">اضافة امراض مزمنة</p>
                            </div>
                        </div>
                        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                                <li class="breadcrumb-item active"><a href="/add-test.html">الامراض المزمنة</a>
                                </li>
                            </ol>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card shadow">
                                <div class="card-header fix-card">
                                    <div class="row">
                                        <div class="col-7">
                                            <h4 class="card-title">الامراض المزمنة</h4>
                                        </div>
                                        <div class="col-3">
                                            <abbr title="استيراد اسماء الامراض المزمنة من ملف خارجي">
                                                <button type="button" class="btn btn-danger float-end" data-bs-toggle="modal"
                                                    data-bs-target="#excelModel"> استيراد اسماء الامراض المزمنة </button>
                                                <abbr>
                                        </div>
                                        <div class="col-2">
                                            <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                                                data-bs-target="#addIll"> اضافة مرض مزمن </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="example1" class="display nowrap">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>اسم المرض</th>
                                                    <th>الوصف</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            @foreach ($all_Diagnose as $Diagnose)
                                                    <tr>
                                                        <td>#{{ ++$index }}</td>
                                                        <td> {{ $Diagnose->name }} </td>
                                                        <td> {{ $Diagnose->description }} </td>
                                                        <td class="text-start">
                                                            <a data-bs-toggle='modal' data-bs-target='#editIll' class='mr-4'  onclick="populateEditModal('{{ $Diagnose->id }}','{{ $Diagnose->name }}', '{{ $Diagnose->description }}');">
                                                                <span class='fas fa-pencil-alt tbl-edit'></span>
                                                            </a>

                                                        </td>
                                                    </tr>

                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End section content -->


        <!-- Add  ILL -->
        <div class="modal fade selectRefresh" id="addIll" tabindex="-1" role="dialog"
            aria-labelledby="modal-title-addDrug-modal">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة مرض مزمن </h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="{{ route('admin.chronicdisease.store') }}" class="row align-items-start needs-validation" novalidate>
                            @csrf
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05"  class="form-label">  اسم المرضى المزمن   </label>
                                    <div id="searchContainer">
                                    <input id="name" data-route="http://localhost:4321/patientPortal/public/admin/chronicdiseaseSearch" type="text" name="name" value="{{ old('name') }}" class="form-control" placeholder=" اسم المرض" id="validationCustom05"  required />
                                    <ul id="SearchResults"></ul>
    <span id="SpanMessage"></span>
                                </div>
                                    @error('name')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>

                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05"  class="form-label">  وصف المرضى المزمن   </label>

                                    <input  type="text" value="{{ old('description') }}" name="description" class="form-control" placeholder="الوصف" id="validationCustom05"  required />
                                    @error('description')
                                        <span class="error-message">{{ $message }}</span>
                                    @enderror
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                                <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>



        <!-- edit  ILL -->
        <div class="modal fade selectRefresh" id="editIll" tabindex="-1" role="dialog"
            aria-labelledby="modal-title-addDrug-modal">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal-title-addDrug-modal"> اضافة مرض مزمن </h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="{{ route('admin.chronicdisease.update') }}" class="row align-items-start needs-validation" novalidate>
                            @csrf
                            @method('PUT')
                            <input type="hidden" name="number" id="illNumber"/>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05"  class="form-label">  اسم المرضى المزمن   </label>
                                    <div id="searchContainer">
                                    <input data-route="http://localhost:4321/patientPortal/public/admin/chronicdiseaseSearch" value="{{ old('name') }}"  type="text" id="editName" name="name" class="form-control" placeholder=" اسم المرض" id="validationCustom05"  required/>
                                    <ul id="SearchResult"></ul>
                                </div>
                                    @error('name')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror
                                </div>

                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="validationCustom05" class="form-label">  وصف المرضى المزمن   </label>

                                    <input type="text" value="{{ old('description') }}" id="illDescription" name="description" class="form-control" placeholder="الوصف" id="validationCustom05"  required />
                                    @error('description')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                                <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>

        <!-- file input -->
        <div class="modal fade selectRefresh" id="excelModel" tabindex="-1" role="dialog"
            aria-labelledby="modal-title-addDrug-modal">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal-title-addDrug-modal">استيراد اسماء الامراض المزمنة من ملف خارجي</h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="{{ route('admin.chronicdisease.csv.store') }}" class="row align-items-start needs-validation" novalidate enctype="multipart/form-data">
                            @csrf
                            <div class="mb-3">
                                <input class="form-control"  id="validationCustom05"  id="formFile" name="file" type="file" required>
                                <p class="text-danger">.xslx .cvs</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                                <button type="submit" class="btn btn-primary">حفظ البيانات</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>


        </div>



    <script>
        function populateEditModal(id, name, desc) {
            document.getElementById('illNumber').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('illDescription').value = desc;
        }
    </script>
    @endsection
