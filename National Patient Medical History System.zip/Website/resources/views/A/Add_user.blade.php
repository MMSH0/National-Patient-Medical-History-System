@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new-patients main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">اضافة مشرف</h4>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active">
                                <a href="#"> المشرفون </a>
                            </li>
                        </ol>
                    </div>
                </div>

   {{-- message --}}
   @if (session('success'))
   <div class="container mt-5" id="successAlert">
       <div class="alert alert-success alert-dismissible fade show" role="alert">
           <span class="message">{{ session('success') }}</span>
           <div class="progress" style="height: 2px;">
               <div class="progress-bar bg-success flex-row-reverse mr-auto ml-auto" role="progressbar"
                   style="width:0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"
                   id="progressBar"></div>
           </div>
       </div>

   </div>
@endif

@if (session('error'))
   <div class="container mt-5" id="successAlert">
       <div class="alert alert-danger alert-dismissible fade show" role="alert">
           <span class="message">{{ session('error') }}</span>
           <div class="progress" style="height: 2px;">
               <div class="progress-bar bg-danger flex-row-reverse mr-auto ml-auto" role="progressbar"
                   style="width:0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"
                   id="progressBar"></div>
           </div>
       </div>

   </div>
@endif
{{-- message --}}

                <form method="POST" action="{{ route('admin.user.store') }}" class="needs-validation" novalidate
                    enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">بيانات المستخدم الجديد</h4>
                                </div>
                                <div class="card-body">
                                    <div class="basic-form">

                                        @csrf
                                        <div class="row">


                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> الاسم الاول </label>

                                                    <input id="validationCustom05" value="{{ old('first_name') }}"
                                                        type="text" name="first_name" class="form-control"
                                                        placeholder="الاسم الاول" required />
                                                    @error('first_name')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> اللقب </label>

                                                    <input value="{{ old('last_name') }}" id="validationCustom05"
                                                        type="text" name="last_name" class="form-control"
                                                        placeholder="اللقب" required />
                                                    @error('last_name')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> البريد الالكتروني
                                                    </label>

                                                    <input id="validationCustom05" type="email"
                                                        value="{{ old('email') }}" name="email" class="form-control"
                                                        placeholder=" example@email.com " required />
                                                    @error('email')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>
                                                <div class="form-group">
                                                    <div class="col-lg-12">
                                                        <label for="validationCustom05" class="form-label"> مكان الميلاد
                                                        </label>

                                                        <select id="validationCustom05" required name="city"
                                                            class="form-control form-select">

                                                            <option>صنعاء</option>
                                                            <option>تعز</option>
                                                            <option>عدن</option>
                                                            <option>ذمار</option>
                                                        </select>
                                                        @error('city')
                                                            <span class="error-message">{{ $message }}</span>
                                                        @enderror

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label"> الجنس </label>

                                                    <select id="validationCustom05" required name="geneder"
                                                        class="form-control form-select">

                                                        <option value="1">ذكر</option>
                                                        <option value="0">انثى</option>
                                                    </select>
                                                    @error('geneder')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>
                                                <div class="form-group">
                                                    <label for="validationCustom05" class="form-label">رقم الهاتف</label>

                                                    <input name="phone" id="phone" maxlength="9" minlength="8" value="{{ old('phone') }}" type="number"
                                                        class="form-control" placeholder="7xxxxxxxx" id="validationCustom05"
                                                        required />
                                                        <span class="error-message" id="phone_number_error"></span>

                                                    @error('phone')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>
                                                <div class="col form-group">
                                                    <label for="validationCustom05" class="form-label">رقم بطاقة
                                                        الهوية</label>

                                                    <input value="{{ old('identity_card') }}" id="validationCustom05"
                                                        required name="identity_card" type="number" class="form-control"
                                                        placeholder= "xxxxxxxxxxx" />
                                                    @error('identity_card')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>
                                                <div class="md-form md-outline input-with-post-icon datepicker">
                                                    <label for="validationCustom05" class="form-label">تاريخ
                                                        الميلاد</label>

                                                    <input  value="{{ old('birthday') }}" name="birthday"
                                                        class="form-control"  type="date" data-date-format="yyyy-mm-dd"
                                                        id="validationCustom05"  required />
                                                    @error('birthday')
                                                        <span class="error-message">{{ $message }}</span>
                                                    @enderror

                                                </div>

                                            </div>

                                        </div>
                                        <div class="row">

                                            <div class="col form-input">
                                                <label for="validationCustom05" class="form-label">العنوان</label>
                                                <input class="form-control" value="{{ old('address') }}"
                                                    id="validationCustom05" name="address" placeholder="العنوان "
                                                    required />
                                            </div>
                                            @error('address')
                                                <span class="error-message">{{ $message }}</span>
                                            @enderror

                                        </div>

                                    </div>
                                    <br>
                                    <br>

                                    <div class="form-group mb-3">
                                        <button type="submit" name="submit" class="btn btn-primary float-end">
                                            حفظ
                                        </button>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>


                </form>
            </div>
        </div>
    </div>
    <!-- End section content -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            function validateInput(value) {
                // Ensure the maximum length is 9
                if (value.length > 9) {
                    return value.substring(0, 9);
                }

                if (value.length > 1) {
                    if (!/^[7]([13780])/.test(value)) {
                        return value.substring(0, value.length - 1);
                    }
                } else if (!/^[7]/.test(value)) {
                    return value.substring(0, value.length - 1);
                }

                return value;
            }

            document.getElementById('phone').addEventListener('input', function(event) {
                const inputField = event.target;
                const inputValue = inputField.value;
                const messageSpan = document.getElementById('phone_number_error');

                const newValue = validateInput(inputValue);


                if ((newValue !== inputValue)) {

                    inputField.value = newValue;
                    if (inputValue.length < 9) {
                        messageSpan.textContent = "يجب ادخل الرقم بشكل صحيح";

                    } else {
                        messageSpan.textContent = "";
                    }

                } else {

                    messageSpan.textContent = ""; // Clear the message if input is valid
                }

                // Set the cursor position to the end of the input
                inputField.selectionStart = inputField.selectionEnd = inputField.value.length;
            });
        });

    </script>
@endsection
