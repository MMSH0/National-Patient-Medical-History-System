@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="new_appointment main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">اسماء المسوؤلين</h4>

                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="#">المستشفيات</a>
                            </li>
                        </ol>
                    </div>
                </div>




                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم المسوؤل</th>
                                                <th>البريد الالكتروني</th>
                                                <th>رقم الهاتف</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          @if (isset($all_user))
                                          @foreach ($all_user as $user)
                                          <tr>
                                              <td>#{{ ++$index }}</td>

                                              <td> {{ $user->person->name }} </td>
                                              <td>{{ $user->email }}</td>
                                              <td>{{ $user->phone_number }}</td>

                                              <td class="text-start">
                                                  @if ($user->status == 1)
                                                  <a data-bs-toggle='modal' data-bs-target='#blockUser'
                                                      class='mr-4'
                                                      onclick="populateEditModalBlock('{{ $user->id }}','{{ $user->status }}');">
                                                      <button class="btn btn-danger"> ايقاف الحساب</button>

                                                  </a>
                                              @else
                                                  <a data-bs-toggle='modal' data-bs-target='#unblockUser'
                                                      class='mr-4'
                                                      onclick="populateEditModalUnBlock('{{ $user->id }}','{{ $user->status }}');">
                                                      <button class="btn btn-primary">تفعيل الحساب</button>

                                                  </a>
                                              @endif
                                              </td>
                                          </tr>
                                      @endforeach

                                          @endif

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section content -->




    <!-- BLOCK DIALG -->
    <div class="modal fade selectRefresh" id="blockUser" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> ايقاف حساب المسوؤل </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.users.block') }}" method="POST" class="row align-items-start">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="number" id="number" />
                        <input type="hidden" name="block" id="block" />
                        <div class="col">
                            <h5>هل متاكد من ايقاف حساب المسوؤل ؟</h5>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-danger"> ايقاف </button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- END BLOCK DIALG -->

    <!-- UNBLOCK DIALG -->
    <div class="modal fade selectRefresh" id="unblockUser" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> تفعيل حساب المسوؤل </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.users.block') }}" method="POST" class="row align-items-start">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="number" id="unblockNumber" />
                        <input type="hidden" name="block" id="unblock" />
                        <div class="col">
                            <h5>هل متاكد من تفعيل حساب المسوؤل ؟</h5>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-primary"> تفعيل </button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- UNBLOCK DIALG -->






    <script>
          function populateEditModalBlock(id, block) {
            document.getElementById('number').value = id;
            document.getElementById('block').value = block;
        }

        function populateEditModalUnBlock(id, block) {
            document.getElementById('unblockNumber').value = id;
            document.getElementById('unblock').value = block;
        }
    </script>
@endsection
