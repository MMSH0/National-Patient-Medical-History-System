@extends('layout.admin_layout')
@section('content')

 <!-- start section content -->
 <div class="content-body">
    <div class="warper container-fluid">
        <div class="add_Ray main_container">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h4 class="text-primary">الأشعة</h4>
                        <p class="mb-0">اضافة أشعة</p>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('admin.index')}}">الرئيسية</a></li>
                        <li class="breadcrumb-item active"><a href="#">قسم الأشعة</a></li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card shadow mb-4">
                        <div class="card-header">
                            <h4 class="card-title">اضافة أشعة</h4>
                        </div>
                        <div class="card-body">
                            <div class="basic-form">
                                <form action="{{ route('admin.radiology.store') }}"  method="POST" class="needs-validation" novalidate>
                                    @csrf
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="validationCustom05" class="form-label">اسم الأشعة </label>
                                                <div id="searchContainer">
                                                <input  data-route="http://localhost:4321/patientPortal/public/admin/raySearch" value="{{ old('name') }}" id="name" type="text" id="validationCustom05"  class="form-control" name="name"
                                                    placeholder="اسم الأشعة" required/>
                                                    <ul id="SearchResults"></ul>
<span id="SpanMessage"></span>
                                                </div>
                                                    @error('name')
                                                    <span class="error-message">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="validationCustom05" class="form-label"> الوصف </label>
                                                <input value="{{ old('description') }}" type="text" id="validationCustom05"  class="form-control" name="description"
                                                    placeholder="الوصف" required/>
                                                    @error('description')
                                                    <span class="error-message">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <div class="form-group">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary float-end">حفظ</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End section content -->


@endsection

