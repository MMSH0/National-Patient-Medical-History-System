@extends('layout.admin_layout')
@section('content')
    <!-- start section content -->
    <div class="content-body">
        <div class="warper container-fluid">
            <div class="All-Rays main_container">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4 class="text-primary">الأشعة</h4>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                            <li class="breadcrumb-item active"><a href="/add-Ray.html">الأشعة</a>
                            </li>
                        </ol>
                    </div>
                </div>







                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header fix-card">
                                <div class="row">
                                    <div class="col-7">
                                        <h4 class="card-title"> الأشعة </h4>
                                    </div>

                                    <div class="col-3">
                                        <abbr title="استيراد اسماء الاشعات من ملف خارجي">
                                            <button type="button" class="btn btn-danger float-end" data-bs-toggle="modal"
                                                data-bs-target="#excelModel"> استيراد اسماء الاشعات</button>
                                        </abbr>

                                    </div>
                                    <div class="col-2">
                                        <a href="{{ route('admin.radiology.create') }}" class="btn btn-primary float-end">
                                            اضافة أشعة</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example1" class="display nowrap">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>اسم الأشعة</th>
                                                <th>الوصف</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>


                                            @foreach ($all_ray as $ray)
                                                <tr>
                                                    <td>{{ ++$index }}</td>
                                                    <td>{{ $ray->name }}</td>
                                                    <td>{{ $ray->Description }}</td>
                                                    <td>
                                                        <a data-bs-toggle='modal' data-bs-target='#editRadiology'
                                                            class='mr-4'
                                                            onclick="populateEditModal('{{ $ray->id }}','{{ $ray->name }}','{{ $ray->Description }}');">
                                                            <span class='fas fa-pencil-alt tbl-edit'></span>
                                                        </a>

                                                    </td>
                                                </tr>
                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End section content -->



    <!-- edit raydiology -->
    <div class="modal fade selectRefresh" id="editRadiology" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal"> تعديل بيانات الأشعة </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('admin.raydiology.update') }}"
                        class="row align-items-start needs-validation" novalidate>
                        @csrf
                        @method('PUT')
                        <input name="number" id="raydiologyNumber" type="hidden" />
                        <div class="col">
                            <div class="form-group">
                                <label for="validationCustom05" class="form-label"> اسم الأشعة </label>
                                <div id="searchContainer">
                                    <input type="text" name="name" value="{{ old('name') }}" id="editName"
                                        data-route="http://localhost:4321/patientPortal/public/admin/raySearch" class="form-control"
                                        placeholder="اسم الأشعة" id="validationCustom05" required />
                                    <ul id="SearchResult"></ul>
                                </div>
                                @error('name')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror

                            </div>

                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="validationCustom05" class="form-label"> وصف الأشعة </label>

                                <input id="raydiologyDescription" type="text" name="description" class="form-control"
                                    placeholder="الوصف" value="{{ old('description') }}" id="validationCustom05"
                                    required />
                                @error('description')
                                    <span class="error-message">{{ $message }}</span>
                                @enderror

                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                            <button type="submit" name="submit" class="btn btn-primary">حفظ البيانات</button>
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>



    <div class="modal fade selectRefresh" id="excelModel" tabindex="-1" role="dialog"
        aria-labelledby="modal-title-addDrug-modal">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-addDrug-modal">استيراد اسماء الاشعات من ملف خارجي</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form class="row align-items-center">

                        <div class="mb-3">
                            <input class="form-control" id="formFile" type="file">
                            <p class="text-danger">.xslx .cvs</p>

                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
                    <button type="button" class="btn btn-primary">حفظ البيانات</button>
                </div>
            </div>
        </div>
    </div>



    <script>
        function populateEditModal(id, name, desc) {
            document.getElementById('raydiologyNumber').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('raydiologyDescription').value = desc;
        }
    </script>
@endsection
