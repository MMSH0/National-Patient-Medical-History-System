<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('workinghours', function (Blueprint $table) {
            $table->id();
            $table->enum('working_day',['السبت','الاحد','الاثنين','الثلاثاء','الاربعاء','الخميس','الجمعة'])->nullable();
            $table->time('start_time')->nullable();
            $table->time('end_time')->nullable();
            $table->unsignedBigInteger('clinic_id')->default(0);
            $table->unsignedBigInteger('doctor_id');
            $table->unsignedBigInteger('hospital_id')->default(0);
            $table->timestamps();
            $table->softDeletes();

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('workinghour');
    }
};
