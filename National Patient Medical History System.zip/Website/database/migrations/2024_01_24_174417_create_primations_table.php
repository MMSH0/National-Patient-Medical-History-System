<?php

use App\Models\Admin\Person;
use App\Models\Admin\Primation;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('primations', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('role_id');
            $table->timestamps();
            $table->softDeletes();
        });

        User::create([
            'phone_number' => '77777777', 'email' =>'superadmin@admin.com',  'password' => Hash::make("123456789")
        ]);

        $userId = User::where('email','superadmin@admin.com')->first();


        Person::create([
            'name' => 'superAdmin',
            'birthDate' => Carbon::now(),
            'gender' =>'1',
            'birthCity' => 'sanaa',
            'address' => 'sanna',
            'user_Id' => $userId->id,
        ]);

        Primation::create([
            'user_id' => $userId->id,
            'role_id' => 1
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('primations');
    }
};
