<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('roles', function (Blueprint $table) {
            $table->id();
            $table->String('user_type');
            $table->timestamps();
            $table->softDeletes();

        });


        DB::table('roles')->insert([
            ['user_type' => 'superadmin','created_at'=>Carbon::now(),'updated_at'=>Carbon::now()],
            ['user_type' => 'admin','created_at'=>Carbon::now(),'updated_at'=>Carbon::now()],
            ['user_type' => 'doctor','created_at'=>Carbon::now(),'updated_at'=>Carbon::now()],
            ['user_type' => 'lab','created_at'=>Carbon::now(),'updated_at'=>Carbon::now()],
            ['user_type' => 'ray','created_at'=>Carbon::now(),'updated_at'=>Carbon::now()],
            ['user_type' => 'patient','created_at'=>Carbon::now(),'updated_at'=>Carbon::now()],
            ['user_type' => 'labray','created_at'=>Carbon::now(),'updated_at'=>Carbon::now()],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('roles');
    }
};
